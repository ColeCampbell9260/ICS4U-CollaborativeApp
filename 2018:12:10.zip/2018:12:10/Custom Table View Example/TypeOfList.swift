//
//  TypeOfList.swift
//  Custom Table View Example
//
//  Created by Brian Alpaugh on 2018-12-06.
//  Copyright © 2018 Brian Alpaugh inc. All rights reserved.
//

import UIKit

class TypeOfList: NSObject {
    
    var nameOfActivityType : String = ""
    var doesUserWantOnThereList : Bool = false
    var whatUserWillAddToList : [String] = []
    
    init(nameOfActivityType : String, doesUserWantOnThereList : Bool, whatUserWillAddToList : [String]) {
        self.nameOfActivityType = nameOfActivityType
        self.doesUserWantOnThereList = doesUserWantOnThereList
        self.whatUserWillAddToList = whatUserWillAddToList
    }
    
}
