//
//  customTableViewCell.swift
//  Custom Table View Example
//
//  Created by Brian Alpaugh on 2018-11-30.
//  Copyright © 2018 Brian Alpaugh inc. All rights reserved.
//

import UIKit

class customTableViewCell: UITableViewCell {

    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var indicatesIfAddingOrRemoving: UIButton!
    @IBAction func changesName(_ sender: UIButton) {
        
        
        if indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            indicatesIfAddingOrRemoving.setTitle("Remove", for: .normal)
        } else if indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            indicatesIfAddingOrRemoving.setTitle("Add", for: .normal)
        }

        
    }
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
