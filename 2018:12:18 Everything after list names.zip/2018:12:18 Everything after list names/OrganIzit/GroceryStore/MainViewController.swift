//
//  ViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-19.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

var currentStore: String = "none"
let screenSize = UIScreen.main.bounds

var list: [Item] = [allItems[1], allItems[13], allItems[28], allItems[30]] //apples, butter, water, bread
var savedLists = [("Test", list)]




class MainViewController: UIViewController {

    var colour = UIColor.white
    var foodBasics = false
    
    
    override func viewDidLoad() {
        list[0].changeNote(note: "Get the green ones")

        foodBasics = false
        super.viewDidLoad()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    }

    
    @IBAction func FoodBasicsButton(_ sender: Any) {
        currentStore = "Basics"
        colour = .green
    }
    
    @IBAction func FoodLandButton(_ sender: Any) {
        currentStore = "Land"
        colour = .red
    }
    
    @IBAction func ShoppersDrugmartButton(_ sender: Any) {
        currentStore = "Shoppers"
        colour = .blue
    }
}

