//
//  ICS4U Collaborative App
//  OrganIzit
//

import UIKit

class LandingPageViewController: UIViewController {

    var profiles : [Profile] = []
    
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var profilePictureView: UIImageView!
    @IBOutlet weak var createProfileButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var editProfileButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func loginPressed(_ sender: Any) {
        performSegue(withIdentifier: "Login", sender: loginButton)
    }
    
    @IBAction func createProfilePressed(_ sender: Any) {
        print(profiles.count)
        performSegue(withIdentifier: "Profile", sender: createProfileButton)
    }
    
    @IBAction func editProfilePressed(_ sender: Any) {
        performSegue(withIdentifier: "Profile", sender: editProfileButton)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let sender = sender as? UIButton else {return}
        
        switch(sender) {
        case createProfileButton:
            let profileVC = segue.destination as! ProfileViewController
            segue.destination.navigationItem.title = "Create New Profile"
            profileVC.interfaceIndex = 1
            profileVC.profiles = profiles
            break
        case editProfileButton:
            let profileVC = segue.destination as! ProfileViewController
            segue.destination.navigationItem.title = "Edit Existing Profile"
            profileVC.interfaceIndex = 2
            profileVC.profiles = profiles
            break
        case loginButton:
            let loginVC = segue.destination as! LoginViewController
            loginVC.profiles = profiles
            break
        default:
            break
        }
    }
    
    @IBAction func unwindBack(segue: UIStoryboardSegue) { }
    
}

