//
//  BlockType.swift
//  testingSegues
//
//  Created by Lizzy on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import Foundation

enum BlockType {
    case Air, Obstacle, pointA, pointB, Path, ExploredPath, pointProd, pointBak, pointFancMeat, pointDairy, pointSeaf, pointFrozFood, pointFrozSweet, pointMeat, pointPharm, point2, point3, point4, point5, point6, point7, point8
}
