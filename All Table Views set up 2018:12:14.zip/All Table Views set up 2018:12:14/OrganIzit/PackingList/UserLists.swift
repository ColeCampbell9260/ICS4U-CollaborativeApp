//
//  UserListsViewController.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-05.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

var listTitle = ""

class UserLists: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var array : [String] = ["Matt", "Dunn"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "display", for: indexPath) as! UserListViewTableViewCell
        
        cell.itemsOnUsersList?.text = array[indexPath.row]
        
        return cell
    }
    
    
    @IBOutlet weak var userListTableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func onPlusTapped() {
        let alert  = UIAlertController(title: "New List", message: nil, preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "List Title"
        }
        
        let action = UIAlertAction(title: "Start Creating", style: .default, handler: {_ in
            CATransaction.setCompletionBlock({
                if alert.textFields![0].text ?? "" == "" {
                    listTitle = "New List"
                } else {
                    listTitle = alert.textFields![0].text ?? ""
                }
                self.performSegue(withIdentifier: "Segue", sender: nil)
            })
        })
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: {_ in
        })
        
        alert.addAction(cancel)
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func backToUserLists (_ segue: UIStoryboardSegue) {
        
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCell.EditingStyle.delete {
            array.remove(at: indexPath.row)
            userListTableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
