//
//  itemsToAddToList.swift
//  OrganIzit
//
//  Created by Brian Alpaugh on 2018-12-10.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class itemsToAddToList: UITableViewCell {

    @IBOutlet weak var itemsUserCanAddTList: UILabel!
    @IBOutlet weak var indicatesIfAddingOrRemoving: UIButton!
    @IBAction func changesAdingOrRemoving(_ sender: UIButton) {
        
        if indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            indicatesIfAddingOrRemoving.setTitle("Remove", for: .normal)
        } else if indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            indicatesIfAddingOrRemoving.setTitle("Add", for: .normal)
        }
        
        if itemsUserCanAddTList.text == "Lacrosse" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            lacrosse.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Lacrosse" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            lacrosse.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Soccer" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            soccer.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Soccer" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            soccer.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Rugby" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            rugby.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Rugby" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            rugby.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Baseball" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            baseball.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Baseball" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            baseball.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Swimming" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            swimming.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Swimming" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            swimming.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Football" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            football.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Football" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            football.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Field Hockey" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            fieldHockey.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Field Hockey" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            fieldHockey.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Tennis" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            tennis.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Tennis" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            tennis.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Bob Sleigh" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            bobsleigh.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Bob Sleigh" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            bobsleigh.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Hockey" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            hockey.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Hockey" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            hockey.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Skiing" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            skiing.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Skiing" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            skiing.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Ringette" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            ringette.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Ringette" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            ringette.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Speed Skating" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            speedSkating.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Speed Skating" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            speedSkating.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Snowboarding" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            snowboarding.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Snowboarding" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            snowboarding.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Luge" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            luge.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Luge" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            luge.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Curling" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            curling.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Curling" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            curling.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Hot" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            hot.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Hot" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            hot.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Cold" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            cold.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Cold" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            cold.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Overnight" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            overnight.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Overnight" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            overnight.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Plane" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            plane.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Plane" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            plane.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Out of Country" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            outOfCountry.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Out of Country" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            outOfCountry.doesUserWantOnThereList = false
        }
        
        if itemsUserCanAddTList.text == "Car" && indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            car.doesUserWantOnThereList = true
        } else if itemsUserCanAddTList.text == "Car" && indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            car.doesUserWantOnThereList = false
        }

    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
