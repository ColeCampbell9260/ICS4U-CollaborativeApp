//
//  ItemCellViewController.swift
//  OrganIzit
//
//  Created by Nathalie Hilbert on 2018-12-11.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

protocol ItemCellDelegate {
    func changeNumber(cell: ItemLayoutCell, number : Int)
    func addedToList(cell: ItemLayoutCell)
}

class ItemLayoutCell : UITableViewCell {
    var delegate: ItemCellDelegate?
    
    
    var item : Item? {
        didSet {
            itemNameLabel.text = item?.name
            itemTypeLabel.text = "\(item!.type)"
            if item!.quantity != 0 {
                itemQuant.text = "\(item!.quantity)"
            }
        }
    }
    
    //set properties of objects in each cell
    private let itemNameLabel : UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .left
        return label
    }()
    
    
    private let itemTypeLabel : UILabel = {
        let label = UILabel()
        label.textColor = .darkGray
        label.font = UIFont.systemFont(ofSize: 12)
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()
    
    private let decreaseButton : UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "List"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        return button
    }()
    
    private let increaseButton : UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "List"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        
        return button
    }()
    var itemQuant : UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .left
        label.text = ""
        label.textColor = .black
        return label
    }()
    
    //called when the add/remove buttons are clicked, part of the protocol
    @objc func decreaseFunc() {
        changeQuantity(by: -1)
        addToList()
    }
    
    @objc func increaseFunc() {
        changeQuantity(by: 1)
        addToList()
    }
    
    
    func addToList() {
        //item is in the list but must be removed
        if list.contains(item!) && item!.quantity == 0{
            print("\(item!.name) is already in the list")
            for index in 0..<list.count{
                if item == list[index]{
                    print("\(item!.name) is removed")
                    list.remove(at: index)
                    return
                }
            }
        }
            //item was not in the list but needs to be added
        else if list.contains(item!) == false && item!.quantity > 0{
            print("\(item!.name) is not in the list")
            print("\(item!.name) is added")
            list.append(item!)
        }
        delegate?.addedToList(cell: self)
    }
    
    
    func changeQuantity(by amount: Int) {
        //sets item quantity text to be the new quantity
        if itemQuant.text == ""{
            item!.quantity = 0
        }
        else{
            item!.quantity = Int(itemQuant.text!)!
        }
        item!.quantity += amount
        if (item!.quantity) <= 0 {
            item!.quantity = 0
            item!.quantity = 0
            itemQuant.text = ""
        } else {
            itemQuant.text = "\(item!.quantity)"
        }
        delegate?.changeNumber(cell: self, number: (item?.quantity)!)
        
    }
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        //adds objects to cell
        addSubview(itemNameLabel)
        addSubview(itemTypeLabel)
        addSubview(decreaseButton)
        addSubview(itemQuant)
        addSubview(increaseButton)
        
        //constraints for cell
        itemNameLabel.anchor(top: topAnchor, left: leftAnchor, bottom: nil, right: nil, paddingTop: 8, paddingLeft: 15, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 2, height: 0, enableInsets: false)
        itemTypeLabel.anchor(top: itemNameLabel.bottomAnchor, left: leftAnchor, bottom: nil, right: nil, paddingTop: 0, paddingLeft: 15, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 2, height: 0, enableInsets: false)
        
        
        let stackView = UIStackView(arrangedSubviews: [decreaseButton, itemQuant, increaseButton])
        stackView.distribution = .equalSpacing
        stackView.axis = .horizontal
        stackView.spacing = 10
        addSubview(stackView)
        stackView.anchor(top: topAnchor, left: itemNameLabel.rightAnchor, bottom: bottomAnchor, right: rightAnchor, paddingTop: 15, paddingLeft: 5, paddingBottom: 15, paddingRight: 35, width: 0, height: 70, enableInsets: false)
        
        //action recognizers
        increaseButton.addTarget(self, action: #selector(increaseFunc), for: .touchUpInside)
        decreaseButton.addTarget(self, action: #selector(decreaseFunc), for: .touchUpInside)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}

