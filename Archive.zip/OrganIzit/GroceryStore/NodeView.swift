//
//  NodeView.swift
//  testingSegues
//
//  Created by Lizzy on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

let INFINITE = 99999

class NodeView: UIView {
    var counter = 0
    let size: CGFloat = 70 // size of grid
    var nodes: [[Node]] = [] // array of all the nodes (empty at first)
    var myArray: [Node] = []
    var pointEntrance = Node()
    var pointProd = Node()
    var pointBak = Node()
    var pointFancmeat = Node()
    var pointDairy = Node()
    var pointSeaf = Node()
    var pointFrozenFood = Node()
    var pointFrozSweets = Node()
    var pointMeat = Node()
    var pointPharm = Node()
    var point2 = Node()
    var point3 = Node()
    var point4 = Node()
    var point5 = Node()
    var point6 = Node()
    var point7 = Node()
    var point8 = Node()
    var fillp1 = Node()
    var fillp2 = Node()
    
    override func layoutSubviews() {
        makeButton()
    }
    
    override func awakeFromNib() {
        
        // puts all the nodes into the array and makes all dummy nodes of type air
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        setCoordinates()
       
        
        // sets points for all the aisles
        
        pointEntrance = nodes[61][2]
        myArray.append(pointEntrance)
        pointProd = nodes[61][20]
        pointMeat = nodes[61][35]
    
        pointBak = nodes[61][55]
        
        pointFancmeat = nodes[52][55]
        
        pointPharm = nodes[52][37]
        
        point2 = nodes[46][26]
        
        point3 = nodes[38][37]
        
        point4 = nodes[32][34]
        
        pointDairy = nodes[27][55]
        
        point5 = nodes[27][36]
        
        pointFrozSweets = nodes[23][15]
        
        point6 = nodes[21][35]
        
        point7 = nodes[12][39]
        
        pointFrozenFood = nodes[6][20]
        
        point8 = nodes[6][35]
        
        pointSeaf = nodes[6][57]
 
        listTypes()
        for po in myArray {
            po.type = .other
        }
        self.setNeedsDisplay() // refreshes page
        // creates x and y values for each node in the array
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
    }
    // makes the "path" button
    func makeButton() -> UIButton {
        let myButton = UIButton(type: UIButton.ButtonType.system)
        myButton.frame = CGRect(x: 20, y: 350, width: 50, height: 50)
        myButton.backgroundColor = UIColor.clear
        myButton.setTitle("Path", for: .normal)
        myButton.setTitleColor(UIColor.black, for: .normal)
        //myButton.titleLabel.adjustsFontSizeToFitWidth = true
        myButton.addTarget(self, action: #selector(buttonPressed), for: .touchUpInside)
        self.addSubview(myButton)
        return myButton
    }
    // sets obstacles
    func setCoordinates() {
        for m in 7...61 {
            for n in 56...57 {
                nodes[m][n].type = .Obstacle
            }
        }
        //frozen sweets
        for m in 3...42{
            for n in 0...12{
                nodes[m][n].type = .Obstacle
            }
        }
        //frozen food and seafood
        for m in 0...5{
            for n in 0..<70{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //meat and pharm
        for m in 53...60{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //2
        for m in 47...51{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //3
        for m in 39...45{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //4
        for m in 33...37{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //5
        for m in 28...31{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //6
        for m in 22...26{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //7
        for m in 13...20{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //8
        for m in 7...11{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //        dairy and fancy meat
        for m in 0..<70{
            for n in 59..<70{
                nodes[m][n].type = .Obstacle
            }
        }
        for m in 0..<70 {
            for n in 58...59 {
                nodes[m][n].type = .Obstacle
            }
        }
        
        //        produce and bakery
        for m in 62..<70{
            for n in 0..<70{
                nodes[m][n].type = .Obstacle
            }
        }
    }
    
    // Creates the grid we use for coordinates
    func createRect(rect: CGRect, colour: UIColor) {
        let cont = UIGraphicsGetCurrentContext()
        cont!.setFillColor(colour.cgColor)
        cont!.setStrokeColor(UIColor.clear.cgColor)
        cont!.fill(rect)
        cont!.stroke(rect, width: 2)
    }
    
    // looks left right up and down to check the next node
    func getNeighbourForNode(node: Node, start: Node, goal: Node) -> [Node] {
        let nodex = node.x
        let nodey = node.y
        var finalNodes: [Node] = []
        
        if start.x <= goal.x {
            if nodes.checkIndex(num: nodex+1) {
                finalNodes.append(nodes[nodey][nodex+1])
            }
            if nodes.checkIndex(num: nodey-1) {
                finalNodes.append(nodes[nodey-1][nodex])
            }
            if nodes.checkIndex(num: nodex-1) {
                finalNodes.append(nodes[nodey][nodex-1])
            }
            if nodes.checkIndex(num: nodey+1) {
                finalNodes.append(nodes[nodey+1][nodex])
            }
        }
        if start.x >= goal.x {
            if nodes.checkIndex(num: nodex-1) {
                finalNodes.append(nodes[nodey][nodex-1])
            }
            if nodes.checkIndex(num: nodey-1) {
                finalNodes.append(nodes[nodey-1][nodex])
            }
            if nodes.checkIndex(num: nodex+1) {
                finalNodes.append(nodes[nodey][nodex+1])
            }
            if nodes.checkIndex(num: nodey+1) {
                finalNodes.append(nodes[nodey+1][nodex])
            }
            
        }
        
        
        var realFinalNode: [Node] = []
        for i in finalNodes {
            if i.from == nil && i.type != .Obstacle {
                realFinalNode.append(i)
            }
        }
        return realFinalNode
    }
    
    
    // Formula to estimate heuristic cost from one node to another node
    func heuristicCostEstimate(from: Node, to: Node) -> Int {
        return (abs(from.x - to.x) + abs(from.y - to.y)) * 40
    }
    // algorithm so find shortest path
    func a_star(_start: Node, _goal: Node) -> [Node] {
        let start = _start
        let goal = _goal
        var closedSet: [Node] = []
        var openSet: [Node] = [start]
        start.g = 0
        start.h = heuristicCostEstimate(from: start, to: goal)
        while openSet.count != 0 {
            var current = lowestFScore()
            if closedSet.count > 0 && openSet.count > 0 {
                if current == closedSet[closedSet.count-1] {
                    current = openSet[0]
                }
            }
            if current == goal {return reconstructPath(current: current)}
            openSet.removeObjFromArray(object: current)
            closedSet.append(current)
            for neighbour in getNeighbourForNode(node: current, start: start, goal: goal) {
                var shouldExecuteIf = true
                if closedSet.contains(neighbour) {shouldExecuteIf = false}
                if shouldExecuteIf {
                    var tentative_g_score = 0
                    tentative_g_score = current.g + 10
                    if !openSet.contains(neighbour) || tentative_g_score < neighbour.g {
                        neighbour.from = current
                        neighbour.g = tentative_g_score
                        neighbour.h = heuristicCostEstimate(from: neighbour, to: goal)
                        if !openSet.contains(neighbour)  {openSet.append(neighbour)}
                    }
                    //nodes[neighbour.y][neighbour.x].type = .ExploredPath
                    // self.setNeedsDisplay()
                }
            }
        }
        self.setNeedsDisplay()
        return []
    }
    
    @IBAction func buttonPressed(_ sender: UIButton!) {
        print("the button was pressed")
        for n in myArray {
            counter += 1
            if counter < myArray.count {
                let path = a_star(_start: n, _goal: myArray[counter])
                for i in path {
                    nodes[i.y][i.x].type = .Path
                }
                print("start: \(n.y), \(n.x)")
                print("goal: \(myArray[counter].y), \(myArray[counter].x)")
            }
        }
        self.setNeedsDisplay()
    }
    
    
    override func draw(_ rect: CGRect) {
        self.subviews.map({ $0.removeFromSuperview() })
        let width = self.frame.size.width / size
        let height = self.frame.size.height / size
        var x: CGFloat = 0
        var y: CGFloat = 0
        
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                let rect = CGRect(x: x, y: y, width: width, height: height)
                createRect(rect: rect, colour: nodes[i][j].colour)
                x += width
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
            y += height
            x = 0
        }
    }
    func clear() {
        resetAllNodes()
    }
    // resets all nodes
    func resetAllNodes() {
        nodes = []
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        self.setNeedsDisplay()
    }
    // resets ony the nodes in your path
    func resetNodes() {
        var tempNodes = nodes
        nodes = []
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        for i in 0..<tempNodes.count {
            for j in 0..<tempNodes[i].count {
                if tempNodes[i][j].type == .Obstacle {
                    nodes[i][j].type = .Obstacle
                }
            }
        }
        self.setNeedsDisplay()
    }
    // once you reach you goal in a_star function, comes here at reconstructs path you took
    func reconstructPath(current: Node)-> [Node] {
        var totalPath: [Node] = [current]
        while let par = totalPath.first!.from {
            totalPath.insert(par, at: 0)
            par.type = .Path
        }
        return totalPath
    }
    // looks at all the f scores and returns the node with the lowest f score
    func lowestFScore()-> Node {
        var finalNode: Node = Node()
        finalNode.g = INFINITE
        finalNode.h = INFINITE
        for i in nodes {
            for j in i {
                if j.f <= finalNode.f && j.g != -100 {
                    finalNode = j
                }
            }
        }
        return finalNode
    }
    func listTypes() {
        for item in list {
            if item.type == .Produce {
                myArray.append(pointProd)
            }
            if item.type == .Meat{
                myArray.append(pointMeat)
            }
            if item.aisle == .bakery{
                myArray.append(pointBak)
            }
            if item.aisle == .HABA{
                myArray.append(pointPharm)
            }
            if item.aisle == .two{
                myArray.append(point2)
            }
            if item.aisle == .three{
                myArray.append(point3)
            }
            if item.aisle == .four{
                myArray.append(point4)
            }
            if item.type == .Dairy{
                myArray.append(pointDairy)
            }
            if item.aisle == .five{
                myArray.append(point5)
            }
            if item.aisle == .frznSweets{
                myArray.append(pointFrozSweets)
            }
            if item.aisle == .six{
                myArray.append(point6)
            }
            if item.aisle == .seven{
                myArray.append(point7)
            }
            if item.aisle == .frznFood{
                myArray.append(pointFrozenFood)
            }
            if item.aisle == .eight{
                myArray.append(point8)
            }
            if item.aisle == .seafood{
                myArray.append(pointSeaf)
            }
        }
        print(myArray)
    }
   /* func listTypes() {
        for item in list {
            if item.location.0 == .Produce {
                listArray.append(produce)
            }
            if item.location.0 == .Meat{
                listArray.append(meat)
            }
            if item.aisle.0 == .bakery{
                listArray.append(bakery)
            }
            if item.location.0 == .Dairy{
                listArray.append(dairy)
            }
            if item.aisle.0 == .two{
                listArray.append(two)
            }
            if item.aisle.0 == .three{
                listArray.append(three)
            }
            if item.aisle.0 == .four{
                listArray.append(four)
            }
            if item.aisle.0 == .five{
                listArray.append(four)
            }
            if item.aisle.0 == .six{
                listArray.append(five)
            }
            if item.aisle.0 == .seven{
                listArray.append(seven)
            }
            if item.aisle.0 == .eight{
                listArray.append(eight)
            }
            if item.aisle.0 == .frznSweets{
                listArray.append(frznSweets)
            }
            if item.aisle.0 == .frznFood{
                listArray.append(frznFood)
            }
            if item.aisle.0 == .seafood{
                listArray.append(seafood)
            }
        }
        print(listArray)
    }
 
}

pointEntrance = nodes[61][2]
myArray.append(pointEntrance)

pointProd = nodes[61][20]
if listArray.contains(produce) {
    myArray.append(pointProd)
}
pointMeat = nodes[61][35]
if listArray.contains(meat) {
    myArray.append(pointMeat)
}
pointBak = nodes[61][55]
if listArray.contains(bakery) {
    myArray.append(pointBak)
}
pointFancmeat = nodes[52][55]
if listArray.contains(meat) {
    myArray.append(pointFancmeat)
}
pointPharm = nodes[52][37]
if listArray.contains(HABA) {
    myArray.append(pointPharm)
}
point2 = nodes[46][42]
if listArray.contains(two) {
    myArray.append(point2)
}
point3 = nodes[38][47]
if listArray.contains(three){
    myArray.append(point3)
}
point4 = nodes[32][34]
if listArray.contains(four) {
    myArray.append(point4)
}
pointDairy = nodes[27][55]
if listArray.contains(dairy) {
    myArray.append(pointDairy)
}
point5 = nodes[27][36]
if listArray.contains(five) {
    myArray.append(point5)
}
pointFrozSweets = nodes[24][15]
if listArray.contains(frznSweets) {
    myArray.append(pointFrozSweets)
}
point6 = nodes[21][35]
if listArray.contains(six) {
    myArray.append(point6)
}
point7 = nodes[12][40]
if listArray.contains(seven){
    myArray.append(point7)
}
pointFrozenFood = nodes[6][20]
if listArray.contains(frznFood){
    myArray.append(pointFrozenFood)
}
point8 = nodes[6][35]
if listArray.contains(eight){
    myArray.append(point8)
}
pointSeaf = nodes[6][57]
if listArray.contains(seafood) {
    myArray.append(pointSeaf)
}*/
}
