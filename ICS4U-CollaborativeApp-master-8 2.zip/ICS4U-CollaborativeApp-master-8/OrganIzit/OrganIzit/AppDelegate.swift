//
//  AppDelegate.swift
//  OrganIzit
//
//  Created by Cole Campbell on 2018-11-22.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
         //saving allItems - grocery
        let savedName = UserDefaults.standard.stringArray(forKey: "name") ?? [String]()
        let savedQuantity = UserDefaults.standard.object(forKey: "quantity") as? [Int] ?? [Int]()
        
        let savedAisle1 = UserDefaults.standard.stringArray(forKey: "aisle1") ?? [String]()
        let savedAisle2 = UserDefaults.standard.stringArray(forKey: "aisle2") ?? [String]()
        let savedAisle3 = UserDefaults.standard.stringArray(forKey: "aisle3") ?? [String]()
        
        let savedDepartment1 = UserDefaults.standard.stringArray(forKey: "department1") ?? [String]()
        let savedDepartment2 = UserDefaults.standard.stringArray(forKey: "department2") ?? [String]()
        let savedDepartment3 = UserDefaults.standard.stringArray(forKey: "department3") ?? [String]()
        
        var savedItems: [Item] = []
        for (index, name) in savedName.enumerated(){
            var name = savedName[index]
            var quantity = savedQuantity[index]
            print(name, quantity)
            var aisle1: Aisle? = .other
            var aisle2: Aisle? = .other
            var aisle3: Aisle? = .other

            var department1: Department = .Other
            var department2: Department = .Other
            var department3: Department = .Other

            if savedAisle1.count > 0{
                aisle1 = Aisle(rawValue: savedAisle1[index])!
                aisle2 = Aisle(rawValue: savedAisle2[index])!
                aisle3 = Aisle(rawValue: savedAisle3[index])!
                
                department1 = Department(rawValue: savedDepartment1[index])!
                department2 = Department(rawValue: savedDepartment2[index])!
                department3 = Department(rawValue: savedDepartment3[index])!
            }
            else{
                aisle1 = allItems[index].aisle.0
                aisle2 = allItems[index].aisle.1
                aisle3 = allItems[index].aisle.2
                
                department1 = allItems[index].location.0
                department2 = allItems[index].location.1
                department3 = allItems[index].location.2
            }
                print(aisle1, aisle2, aisle3)
                print(department1, department2, department3)
            savedItems.append(Item(name: name, location: (department1, department2, department3), aisle: (aisle1, aisle2, aisle3), quantity: quantity))
        }
        print(savedQuantity, savedName, savedAisle1, savedDepartment1, "reading")
        allItems = savedItems
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        // Saves changes in the application's managed object context before the application terminates.
         // saving allItems - grocery
 var savedName: [String] = []
 var savedQuantity: [Int] = []
 var savedAisle1: [String] = []
 var savedAisle2: [String] = []
 var savedAisle3: [String] = []
 var savedDepartment1: [String] = []
 var savedDepartment2: [String] = []
 var savedDepartment3: [String] = []
 var savedNotes: [String] = []
print(allItems.count)
for (_, item) in allItems.enumerated(){

    var aisle1 = item.aisle.0?.rawValue
    savedAisle1.append(aisle1 ?? "Other")
    var aisle2 = item.aisle.1?.rawValue
    savedAisle2.append(aisle2 ?? "Other")
    var aisle3 = item.aisle.2?.rawValue
    savedAisle3.append(aisle3 ?? "Other")
    
    var department1 = item.location.0.rawValue
    savedDepartment1.append(department1 ?? "Other")
    var department2 = item.location.1.rawValue
    savedDepartment2.append(department2 ?? "Other")
    var department3 = item.location.2.rawValue
    savedDepartment3.append(department3 ?? "Other")
    
    savedName.append(item.name)
    savedQuantity.append(item.quantity)
    savedNotes.append(item.notes)
        }
        print(savedQuantity, savedName, savedAisle1, "Writting")
        UserDefaults.standard.set(savedName, forKey: "name")
        UserDefaults.standard.set(savedQuantity, forKey: "quantity")
        UserDefaults.standard.set(savedAisle1, forKey: "aisle1")
        UserDefaults.standard.set(savedAisle2, forKey: "aisle2")
        UserDefaults.standard.set(savedAisle3, forKey: "aisle3")
        UserDefaults.standard.set(savedDepartment1, forKey: "department1")
        UserDefaults.standard.set(savedDepartment2, forKey: "department2")
        UserDefaults.standard.set(savedDepartment3, forKey: "department3")
        UserDefaults.standard.set(savedNotes, forKey: "notes")

        self.saveContext()
    }

    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
        */
        let container = NSPersistentContainer(name: "OrganIzit")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                 
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Saving support

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

}

