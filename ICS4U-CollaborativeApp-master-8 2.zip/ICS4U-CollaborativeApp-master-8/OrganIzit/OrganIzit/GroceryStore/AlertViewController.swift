import UIKit

protocol CustomAlertViewDelegate: class {
    func doneButtonTapped(selectedDpt: Department, itemName: String)
    func cancelButtonTapped()
}


class CustomAlertView: UIViewController {
    
    //outlets for alert
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var itemField: UITextField!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var doneButton: UIButton!
    
 var delegate: CustomAlertViewDelegate?
    var selectedOption: Department = .Other //in segment control
    
    override func viewDidLoad() {
        super.viewDidLoad()
        itemField.becomeFirstResponder()
        //sets text the the text from the search bar
        itemField.text! = newItemName
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupView()
        animateView()
    }
    
    func setupView() {
        alertView.layer.cornerRadius = 15
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.4)
    }
    
    func animateView() {
    //animation in
        alertView.alpha = 0;
        self.alertView.frame.origin.y = self.alertView.frame.origin.y + 50
        UIView.animate(withDuration: 0.4, animations: { () -> Void in
            self.alertView.alpha = 1.0;
            self.alertView.frame.origin.y = self.alertView.frame.origin.y - 50
        })
    }
    
    @IBAction func doneButtonTapped(_ sender: Any) {
    itemField.resignFirstResponder()
        delegate?.doneButtonTapped(selectedDpt: selectedOption, itemName: itemField.text!) //call to search view controller
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
    itemField.resignFirstResponder()
        delegate?.cancelButtonTapped() //call to search view controller
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func segmentControl(_ sender: UISegmentedControl) {
    //gets department from segmented control
        switch sender.selectedSegmentIndex {
        case 0:
            selectedOption = .Other
        case 1:
            selectedOption = .Dairy
        case 2:
            selectedOption = .Meat
        case 3:
            selectedOption = .Produce
        case 4:
            selectedOption = .Grocery
        default:
            selectedOption = .Other
        }
    }
    
    
    
}
