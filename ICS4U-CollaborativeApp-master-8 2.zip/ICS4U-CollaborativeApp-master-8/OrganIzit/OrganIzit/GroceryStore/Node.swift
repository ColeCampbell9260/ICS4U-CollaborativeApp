//
//  Node.swift
//  testingSegues
//
//  Created by Lizzy on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit
// class coded by Lizzy
class Node: NSObject {
    private var realType: BlockType = .Air
    var x: Int = 0
    var y: Int = 0
    var g: Int = -100
    var h: Int = -100
    var f: Int {
        get {
            return g+h
        }
    }
    var from: Node!
    // gets the colour depending on what type we set the nodes to
    var colour: UIColor {
        get {
            if self.type == .Air {
                return UIColor.white
            } else if self.type == .Obstacle {
                return UIColor.clear
            } else if self.type == .Path {
                return UIColor.red
            }
            return UIColor.black
        }
    }
    
    var type: BlockType {
        get {
            return realType
        }
        set {
            realType = newValue
        }
    }
}
