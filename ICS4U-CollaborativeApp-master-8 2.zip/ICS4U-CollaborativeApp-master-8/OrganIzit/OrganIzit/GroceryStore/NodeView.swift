//
//  NodeView.swift
//  testingSegues
//
//  Created by Lizzy on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

let INFINITE = 99999
var myArray: [Node] = []
    var pointEntrance = Node()
    var pointProd = Node()
    var pointBak = Node()
    var pointFancmeat = Node()
    var pointDairy = Node()
    var pointSeaf = Node()
    var pointFrozenFood = Node()
    var pointFrozSweets = Node()
    var pointMeat = Node()
    var pointPharm = Node()
    var point2 = Node()
    var point3 = Node()
    var point4 = Node()
    var point5 = Node()
    var point6 = Node()
    var point7 = Node()
    var point8 = Node()

class NodeView: UIView {
    var counter = 0
    let size: CGFloat = 70 // size of grid
    var nodes: [[Node]] = [] // array of all the nodes (empty at first)

    override func awakeFromNib() {
        // puts all the nodes into the array and makes all dummy nodes of type air
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }

        // creates x and y values for each node in the array
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        setCoordinates()
        setPoints()
        listTypes()
        drawThePath()
       // self.setNeedsDisplay()  // refreshes the page
    }
// sets points for all the aisles that might be added to our path
// coded by: Lizzy and Kurtis
    func setPoints() {
     pointEntrance = nodes[61][2]
     myArray.append(pointEntrance)
        pointProd = nodes[61][20]
        pointMeat = nodes[61][35]
        pointBak = nodes[61][55]
        pointFancmeat = nodes[52][55]
        pointPharm = nodes[52][37]
        point2 = nodes[46][26]
        point3 = nodes[38][37]
        point4 = nodes[32][34]
        pointDairy = nodes[27][55]
        point5 = nodes[27][36]
        pointFrozSweets = nodes[23][15]
        point6 = nodes[21][35]
        point7 = nodes[12][39]
        pointFrozenFood = nodes[6][20]
        point8 = nodes[6][35]
        pointSeaf = nodes[6][57]
        }
    
    // sets the obstacles of the departments so our path doesn't have you walking through them
    // coded by: Kurtis and Lizzy
    func setCoordinates() {
        for m in 7...61 {
            for n in 56...57 {
                nodes[m][n].type = .Obstacle
            }
        }
        //frozen sweets
        for m in 3...42{
            for n in 0...12{
                nodes[m][n].type = .Obstacle
            }
        }
        //frozen food and seafood
        for m in 0...5{
            for n in 0..<70{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //meat and pharm
        for m in 53...60{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //2
        for m in 47...51{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //3
        for m in 39...45{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //4
        for m in 33...37{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //5
        for m in 28...31{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //6
        for m in 22...26{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //7
        for m in 13...20{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        //8
        for m in 7...11{
            for n in 16...54{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //        dairy and fancy meat
        for m in 0..<70{
            for n in 59..<70{
                nodes[m][n].type = .Obstacle
            }
        }
        for m in 0..<70 {
            for n in 58...59 {
                nodes[m][n].type = .Obstacle
            }
        }
        
        //        produce and bakery
        for m in 62..<70{
            for n in 0..<70{
                nodes[m][n].type = .Obstacle
            }
        }
    }
    
    // Creates the grid we use for our node coordinates
    // coded by: Lizzy
    func createRect(rect: CGRect, colour: UIColor) {
        let cont = UIGraphicsGetCurrentContext()
        cont!.setFillColor(colour.cgColor)
        cont!.setStrokeColor(UIColor.clear.cgColor)
        cont!.fill(rect)
        cont!.stroke(rect, width: 2)
    }
    
    // looks left right up and down to check the next node
    // coded by: Lizzy
    func getNeighbourForNode(node: Node, start: Node, goal: Node) -> [Node] {
        let nodex = node.x
        let nodey = node.y
        var finalNodes: [Node] = []
        
        if start.x <= goal.x {
            if nodes.checkIndex(num: nodex+1) {
                finalNodes.append(nodes[nodey][nodex+1])
            }
            if nodes.checkIndex(num: nodey-1) {
                finalNodes.append(nodes[nodey-1][nodex])
            }
            if nodes.checkIndex(num: nodex-1) {
                finalNodes.append(nodes[nodey][nodex-1])
            }
            if nodes.checkIndex(num: nodey+1) {
                finalNodes.append(nodes[nodey+1][nodex])
            }
        }
        if start.x >= goal.x {
            if nodes.checkIndex(num: nodex-1) {
                finalNodes.append(nodes[nodey][nodex-1])
            }
            if nodes.checkIndex(num: nodey-1) {
                finalNodes.append(nodes[nodey-1][nodex])
            }
            if nodes.checkIndex(num: nodex+1) {
                finalNodes.append(nodes[nodey][nodex+1])
            }
            if nodes.checkIndex(num: nodey+1) {
                finalNodes.append(nodes[nodey+1][nodex])
            }
            
        }
        var realFinalNode: [Node] = []
        for i in finalNodes {
            if i.from == nil && i.type != .Obstacle {
                realFinalNode.append(i)
            }
        }
        return realFinalNode
    }
    
    
    // Formula to estimate heuristic cost from one node to another node
    func heuristicCostEstimate(from: Node, to: Node) -> Int {
        return (abs(from.x - to.x) + abs(from.y - to.y)) * 40
    }
    // algorithm so find shortest path
    func a_star(_start: Node, _goal: Node) -> [Node] {
        let start = _start
        let goal = _goal
        var closedSet: [Node] = []
        var openSet: [Node] = [start]
        start.g = 0
        start.h = heuristicCostEstimate(from: start, to: goal)
        while openSet.count != 0 {
            var current = lowestFScore()
            if closedSet.count > 0 && openSet.count > 0 {
                if current == closedSet[closedSet.count-1] {
                    current = openSet[0]
                }
            }
            if current == goal {return reconstructPath(current: current)}
            openSet.removeObjFromArray(object: current)
            closedSet.append(current)
            for neighbour in getNeighbourForNode(node: current, start: start, goal: goal) {
                var shouldExecuteIf = true
                if closedSet.contains(neighbour) {shouldExecuteIf = false}
                if shouldExecuteIf {
                    var tentative_g_score = 0
                    tentative_g_score = current.g + 10
                    if !openSet.contains(neighbour) || tentative_g_score < neighbour.g {
                        neighbour.from = current
                        neighbour.g = tentative_g_score
                        neighbour.h = heuristicCostEstimate(from: neighbour, to: goal)
                        if !openSet.contains(neighbour)  {openSet.append(neighbour)}
                    }
                }
            }
        }
        self.setNeedsDisplay()
        return []
    }
    // draws the path through the grocery store when the view loads (redraws it each time)
    func drawThePath() {
    counter = 0
        for n in myArray {
            counter += 1
            if counter < myArray.count {
                let path = a_star(_start: n, _goal: myArray[counter])
                for i in path {
                    nodes[i.y][i.x].type = .Path
                }
               // print("start path: \(n.y), \(n.x)")
               // print("goal path: \(myArray[counter].y), \(myArray[counter].x)")
            }
        }
        self.setNeedsDisplay()
        self.layoutIfNeeded()
    }
    // draws over the path you already have but in type .Air (white) so that you don't see it
    func dummy() {
    counter = 0
        for n in myArray {
            counter += 1
            if counter < myArray.count {
                let path = a_star(_start: n, _goal: myArray[counter])
                for i in path {
                    nodes[i.y][i.x].type = .Air
                    
                }
               // print("start air: \(n.y), \(n.x)")
               // print("goal air: \(myArray[counter].y), \(myArray[counter].x)")
            }
        }
        self.setNeedsDisplay()
        self.layoutIfNeeded()
    }
   
    override func draw(_ rect: CGRect) {
        self.subviews.map({ $0.removeFromSuperview() })
        let width = self.frame.size.width / size
        let height = self.frame.size.height / size
        var x: CGFloat = 0
        var y: CGFloat = 0
        
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                let rect = CGRect(x: x, y: y, width: width, height: height)
                createRect(rect: rect, colour: nodes[i][j].colour)
                x += width
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
            y += height
            x = 0
        }
    }
    
// clears the
    func clear() {
        sortedArray.removeAll()
        myArray.removeAll()
       // myArray.insert(pointEntrance, at: 0)
    }
    // resets all nodes
    func resetAllNodes() {
        nodes = []
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        self.setNeedsDisplay()
    }
    // resets ony the nodes in your path
    func resetNodes() {
        var tempNodes = nodes
        nodes = []
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        for i in 0..<tempNodes.count {
            for j in 0..<tempNodes[i].count {
                if tempNodes[i][j].type == .Obstacle {
                    nodes[i][j].type = .Obstacle
                }
            }
        }
        self.setNeedsDisplay()
    }
    // once you reach you goal in a_star function, comes here at reconstructs path you took
    // coded by: lizzy
    func reconstructPath(current: Node)-> [Node] {
        var totalPath: [Node] = [current]
        while let par = totalPath.first!.from {
            totalPath.insert(par, at: 0)
            par.type = .Path
        }
        return totalPath
        self.setNeedsDisplay()
    }
    // looks at all the f scores and returns the node with the lowest f score
    // coded by: Lizzy
    func lowestFScore()-> Node {
        var finalNode: Node = Node()
        finalNode.g = INFINITE
        finalNode.h = INFINITE
        for i in nodes {
            for j in i {
                if j.f <= finalNode.f && j.g != -100 {
                    finalNode = j
                }
            }
        }
        return finalNode
    }
   var sortedArray: [Int] = []
   func listTypes() {
   myArray.insert(pointEntrance, at: 0)
       for item in list {
       print("the item in the list is: \(item.name)")
           if item.location.0 == .Produce {
               sortedArray.append(0)
           }
           if item.location.0 == .Meat{
               sortedArray.append(1)
           }
           if item.aisle.0 == .bakery{
               sortedArray.append(2)
           }
           if item.aisle.0 == .one{
               sortedArray.append(3)
           }
           if item.aisle.0 == .two{
               sortedArray.append(4)
           }
           if item.aisle.0 == .three{
               sortedArray.append(5)
           }
           if item.aisle.0 == .four{
               sortedArray.append(6)
           }
           if item.aisle.0 == .five{
               sortedArray.append(7)
           }
           if item.aisle.0 == .six{
               sortedArray.append(8)
           }
           if item.aisle.0 == .seven{
               sortedArray.append(9)
           }
           if item.aisle.0 == .eight{
               sortedArray.append(10)
           }
           if item.aisle.0 == .frznSweets{
               sortedArray.append(11)
           }
           if item.aisle.0 == .frznFood{
               sortedArray.append(12)
           }
           if item.aisle.0 == .seafood{
               sortedArray.append(13)
           }
           if item.location.0 == .Dairy{
               sortedArray.append(14)
           }
       }
       sortedArray.sort()
       if sortedArray.contains(0){
           myArray.append(pointProd)
           print("\(pointProd) was appended")
       }
       if sortedArray.contains(1){
           myArray.append(pointMeat)
           print("\(pointMeat) was appended")
       }
       if sortedArray.contains(2){
           myArray.append(pointBak)
           print("\(pointBak) was appended")
       }
       if sortedArray.contains(3){
           myArray.append(pointPharm)
           print("\(pointPharm) was appended")
       }
       if sortedArray.contains(4){
           myArray.append(point2)
           print("\(point2) was appended")
       }
       if sortedArray.contains(5){
           myArray.append(point3)
           print("\(point3) was appended")
       }
       if sortedArray.contains(6){
           myArray.append(point4)
           print("\(point4) was appended")
       }
       if sortedArray.contains(7){
           myArray.append(point5)
           print("\(point5) was appended")
       }
       if sortedArray.contains(8){
           myArray.append(point6)
           print("\(point6) was appended")
       }
       if sortedArray.contains(9){
           myArray.append(point7)
           print("\(point7) was appended")
       }
       if sortedArray.contains(10){
           myArray.append(point8)
           print("\(point8) was appended")
       }
       if sortedArray.contains(11){
           myArray.append(pointFrozSweets)
           print("\(pointFrozSweets) was appended")
       }
       if sortedArray.contains(12){
           myArray.append(pointFrozenFood)
           print("\(pointFrozenFood) was appended")
       }
       if sortedArray.contains(13){
           myArray.append(pointSeaf)
           print("\(pointSeaf) was appended")
       }
       if sortedArray.contains(14){
           myArray.append(pointDairy)
           print("\(pointDairy) was appended")
       }
   }
}
