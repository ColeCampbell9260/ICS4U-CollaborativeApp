//
//  ListMaker.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-07.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

var isAdded = [Bool]()
var whatUserWantsForList : [String: Bool] = [:]

class ListMaker: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var listMakerNavBar: UINavigationBar!
    
    var userOptions : [String] = []
    var onlyAddItemsOnce : Bool = false
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if whatUserWantsForList["Lacrosse"] == true {
            lacrosse.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Soccer"] == true {
            soccer.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Rugby"] == true {
            rugby.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Baseball"] == true {
            baseball.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Swimming"] == true {
            swimming.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Football"] == true {
            football.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Field Hockey"] == true {
            fieldHockey.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Tennis"] == true {
            tennis.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Bobsleigh"] == true {
            bobsleigh.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Hockey"] == true {
            hockey.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Skiing"] == true {
            skiing.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Ringette"] == true {
            ringette.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Speed Skating"] == true {
            speedSkating.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Snowboarding"] == true {
            snowboarding.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Luge"] == true {
            luge.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Curling"] == true {
            curling.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Hot"] == true {
            hot.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Cold"] == true {
            cold.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Overnight"] == true {
            overnight.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Plane"] == true {
            plane.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Out of Country"] == true {
            outOfCountry.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Car"] == true {
            car.doesUserWantOnThereList = true
        }
        
        newListCreated = true
        
    }
    
    @IBAction func doneButton(_ sender: UIBarButtonItem) {
        
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if onlyAddItemsOnce == false {
            userOptions.append(car.nameOfActivityType)
            userOptions.append(outOfCountry.nameOfActivityType)
            userOptions.append(plane.nameOfActivityType)
            userOptions.append(overnight.nameOfActivityType)
            userOptions.append(cold.nameOfActivityType)
            userOptions.append(hot.nameOfActivityType)
            userOptions.append(curling.nameOfActivityType)
            userOptions.append(luge.nameOfActivityType)
            userOptions.append(snowboarding.nameOfActivityType)
            userOptions.append(speedSkating.nameOfActivityType)
            userOptions.append(ringette.nameOfActivityType)
            userOptions.append(skiing.nameOfActivityType)
            userOptions.append(hockey.nameOfActivityType)
            userOptions.append(bobsleigh.nameOfActivityType)
            userOptions.append(tennis.nameOfActivityType)
            userOptions.append(fieldHockey.nameOfActivityType)
            userOptions.append(football.nameOfActivityType)
            userOptions.append(rugby.nameOfActivityType)
            userOptions.append(swimming.nameOfActivityType)
            userOptions.append(baseball.nameOfActivityType)
            userOptions.append(soccer.nameOfActivityType)
            userOptions.append(lacrosse.nameOfActivityType)
            onlyAddItemsOnce = true
        }
        
        return userOptions.count
        
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! itemsToAddToList
        
        cell.itemsUserCanAddTList?.text = userOptions[indexPath.row]
        
        isAdded.append(false)
        whatUserWantsForList += [userOptions[indexPath.row]: isAdded[indexPath.row]]
        
        if(isAdded[indexPath.row]) {
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) {
            if cell.accessoryType == .none {
                cell.accessoryType = .checkmark
                isAdded[indexPath.row] = true
                whatUserWantsForList[userOptions[indexPath.row]] = true
            } else if cell.accessoryType == .checkmark {
                cell.accessoryType = .none
                isAdded[indexPath.row] = false
                whatUserWantsForList[userOptions[indexPath.row]] = false
            }
        }
    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        listMakerNavBar.topItem?.title = listTitle

        // Do any additional setup after loading the view.
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
