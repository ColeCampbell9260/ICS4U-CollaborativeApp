//
//  allUsedVariables.swift
//  OrganIzit
//
//  Created by Brian Alpaugh on 2018-12-19.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import Foundation

// Saves the title of the Users List
var listTitle : String = ""


// Creates all the types of packing lists the user may want
let lacrosse = TypeOfList(nameOfActivityType: "Lacrosse", doesUserWantOnThereList: false, whatUserWillAddToList: ["Lacrosse helmet", "Lacrosse mouthguard", "Lacrosse shoulder pads", "Lacrosse elbow pads", "Lacrosse arm pads", "Lacrosse gloves", "Lacrosse cleats", "Lacrosse jersey"])

let soccer = TypeOfList(nameOfActivityType: "Soccer", doesUserWantOnThereList: false, whatUserWillAddToList: ["Soccer cleats", "Soccer shin guards", "Soccer socks", "Soccer jersey", "Soccer shorts"])

let rugby = TypeOfList(nameOfActivityType: "Rugby", doesUserWantOnThereList: false, whatUserWillAddToList: ["Rugby compression wear", "Rugby mouthguard", "Rugby shirt", "Rugby shorts", "Rugby socks", "Rugby scrum cap", "Rugby shin guards"])

let baseball = TypeOfList(nameOfActivityType: "Baseball", doesUserWantOnThereList: false, whatUserWillAddToList: ["Baseball bat", "Baseball helmet", "Baseball glove", "Baseball cleats", "Baseball pants", "Baseball jersey", "Back catcher gear"])

let swimming = TypeOfList(nameOfActivityType: "Swimming", doesUserWantOnThereList: false, whatUserWillAddToList: ["Swimming goggles", "Bathing suit"])

let football = TypeOfList(nameOfActivityType: "Football", doesUserWantOnThereList: false, whatUserWillAddToList: ["Football helmet", "Football neck guard", "Football jock", "Football mouthguard", "Football thigh pads", "Football hip pads", "Football knee pads", "Football tailbone pad", "Football shoulder pads", "Football gloves", "Football jersey", "Football pants", "Football girdle", "Football undergear"])

let fieldHockey = TypeOfList(nameOfActivityType: "Field Hockey", doesUserWantOnThereList: false, whatUserWillAddToList: ["Field Hockey stick", "Field Hockey cleats", "Field Hockey shin guards", "Field Hockey socks", "Field Hockey mouthguard", "Field Hockey uniform"])

let tennis = TypeOfList(nameOfActivityType: "Tennis", doesUserWantOnThereList: false, whatUserWillAddToList: ["Tennis racket", "Tennis shirt", "Tennis shoes", "Tennis shorts"])

let bobsleigh = TypeOfList(nameOfActivityType: "Bob Sleigh", doesUserWantOnThereList: false, whatUserWillAddToList: ["Bobsleigh helmet", "Bobsleigh ", "Bobsleigh shoes"])

let hockey = TypeOfList(nameOfActivityType: "Hockey", doesUserWantOnThereList: false, whatUserWillAddToList: ["Hockey jock", "Hockey shin pads", "Hockey elbow pads", "Hockey socks", "Hockey jersey", "Hockey pants", "Hockey skates", "Hockey shoulder pads", "Hockey neck guard", "Hockey helmet", "Hockey gloves", "Hockey stick", "Extra Hockey undergear"])

let skiing = TypeOfList(nameOfActivityType: "Skiing", doesUserWantOnThereList: false, whatUserWillAddToList: ["Skies", "Ski helmet", "Winter clothes", "Ski poles", "Ski boots", "Balaclava"])

let ringette = TypeOfList(nameOfActivityType: "Ringette", doesUserWantOnThereList: false, whatUserWillAddToList: ["Ringette helmet", "Ringette gloves", "Ringette jersey", "Ringette elbow pads", "Ringette shoulder pads", "Ringette neck guard", "Ringette skates", "Ringette pants", "Ringette socks", "Ringette shin pads", "Ringette jock", "Ringette stick", "Extra ringette undergear"])

let speedSkating = TypeOfList(nameOfActivityType: "Speed Skating", doesUserWantOnThereList: false, whatUserWillAddToList: ["Speed skating skates", "Speed skating helmet", "Speed skating goggles", "Speed skating spandex"])

let snowboarding = TypeOfList(nameOfActivityType: "Snowboarding", doesUserWantOnThereList: false, whatUserWillAddToList: ["Snowboard", "Snowboard boots", "Winter clothing", "Snowboard helmet", "Snowboard goggles", "Balaclava"])

let luge = TypeOfList(nameOfActivityType: "Luge", doesUserWantOnThereList: false, whatUserWillAddToList: ["Luge racing booties", "Spiked Luge gloves", "Luge racing suit", "Luge helmet", "Luge sled", "Luge spandex"])

let curling = TypeOfList(nameOfActivityType: "Curling", doesUserWantOnThereList: false, whatUserWillAddToList: ["Curling shoes", "Curling broom", "Sweater", "Curling pants", "Stop watch"])

let hot = TypeOfList(nameOfActivityType: "Hot", doesUserWantOnThereList: false, whatUserWillAddToList: ["Bathing suit", "Shorts", "T-shirt", "Hat", "Sunscreen", "Towels", "Sandals", "Running shoes", "Sand toys", "Umbrella", "Undergarments", "Sun glasses", "Camera", "Floaties", "Life jacket", "Cooler", "Capris", "Tank tops", "Hoodies", "Long pants", "Long sleves", "Sun screen"])

let cold = TypeOfList(nameOfActivityType: "Cold", doesUserWantOnThereList: false, whatUserWillAddToList: ["Coat", "Snow Pants", "Boots", "Gloves", "Mittens", "Blanket", "Hat", "Sled", "Board games", "Shovel", "Pants", "Shirts", "Kleenex", "Scarf", "Balaclava", "Sweater", "Capris"])

let overnight = TypeOfList(nameOfActivityType: "Overnight", doesUserWantOnThereList: false, whatUserWillAddToList: ["Toiletries", "Pyjamas"])

let plane = TypeOfList(nameOfActivityType: "Plane", doesUserWantOnThereList: false, whatUserWillAddToList: [ "Book", "Electronics", "Charger cords", "Carry on bag", "Gum", "Snacks"])

let outOfCountry = TypeOfList(nameOfActivityType: "Out of Country", doesUserWantOnThereList: false, whatUserWillAddToList: ["Passport", "Foreign Currency"])

let car = TypeOfList(nameOfActivityType: "Car", doesUserWantOnThereList: false, whatUserWillAddToList: ["Book", "Electronics", "Charger cords", "Water bottle", "Snacks"])

// These functions make the checkmarks saved when called
func setsBoolsToInputCheckMarks() {
    isChecked.removeAll()
    
    for (index,key) in itemsOnLists[thePositionInArrays] {
        if isChecked.isEmpty == true {
            isChecked = [key]
        } else {
            isChecked += [key]
        }
    }
}

// This functions sets the names in the right order so the checkmarks save properly
func setsTheNamesOfItemsToBeDisplayed() {
    userList.itemsOnList.removeAll()
    
    for (index, key) in itemsOnLists[thePositionInArrays] {
        if userList.itemsOnList.isEmpty == true {
            userList.itemsOnList = [index]
        } else {
            userList.itemsOnList += [index]
        }
    }
}

// Allows for the deletion of lists
func adjustsVariablesSoYouCanDeleteLists() {
    
}

// Creates all variables for displaying the users list
var namesOfAllLists : [String] = ["You have no lists, click the + to create!"]
var itemsOnLists : [[String : Bool]] = [[:]]
var positionInArraysForList : [String: Int] = [:]

// Tells us if we are coming from a newly created list or displaying an old one
var newListCreated : Bool = false

// Tells what position in the arrays your list is at
var thePositionInArrays : Int = 0

