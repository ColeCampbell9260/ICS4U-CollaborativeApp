//
//  Items.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-27.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit
import Foundation

class Item: Comparable, Equatable {
    
    
    var name: String
    var location: (Department, Department, Department)
    var quantity: Int = 0
    var notes: String = ""
    var aisle: (Aisle?, Aisle?, Aisle?) = (nil, nil, nil)
    
    init(name: String, location: (Department, Department, Department)){
        self.name = name
        self.location = location
    }
    init(name: String, location: (Department, Department, Department), quantity: Int){
        self.name = name
        self.location = location
        self.quantity = quantity
    }
    
    init(name: String, location: (Department, Department, Department), aisle: (Aisle?, Aisle?, Aisle?)){
        self.name = name
        self.location = location
        self.aisle = aisle
    }
    
    func addOne() {
        quantity += 1
    }
    
    func subtractOne() {
        if quantity > 0 {
            quantity -= 1
        }
    }
    
    func changeNote(note: String) {
        notes = note
    }
    
    
    static func < (lhs: Item, rhs: Item) -> Bool {
        return  lhs.name < rhs.name
    }
    
    static func > (lhs: Item, rhs: Item) -> Bool {
        return  lhs.name > rhs.name
    }
    
    static func == (lhs: Item, rhs: Item) -> Bool {
        return  lhs.name == rhs.name
    }
}


enum Department {
    case Produce
    case Meat
    case Dairy
    case Grocery
    case Other
}

enum Aisle {
    case one
    case two
    case three
    case four
    case five
    case six
    case seven
    case eight
    case nine
    case ten
    case bakery
    case frznSweets
    case frznFood
    case fancyMeat
    case seafood
    case other
}




var addItem = [Item(name: "Add Item", location: (.Other, .Other, .Other))]
var allItems: [Item] = [
    /* 0 */         Item(name: "nil", location: (.Other, .Other, .Other)),
                    
                    /* 1 */         Item(name: "Apples", location: (.Produce, .Produce, .Produce)),
                                    /* 2 */         Item(name: "Bannanas", location: (.Produce, .Produce, .Produce)),
                                                    /* 3 */         Item(name: "Blueberries", location: (.Produce, .Produce, .Produce)),
                                                                    /* 4 */         Item(name: "Brocolli", location: (.Produce, .Produce, .Produce)),
                                                                                    /* 5 */         Item(name: "Cabbage", location: (.Produce, .Produce, .Produce)),
                                                                                                    /* 6 */         Item(name: "Cucumber", location: (.Produce, .Produce, .Produce)),
                                                                                                                    /* 7 */         Item(name: "Grapes", location: (.Produce, .Produce, .Produce)),
                                                                                                                                    /* 8 */         Item(name: "Kiwi", location: (.Produce, .Produce, .Produce)),
                                                                                                                                                    /* 9 */         Item(name: "Lettuce", location: (.Produce, .Produce, .Produce)),
                                                                                                                                                                    /* 10 */        Item(name: "Oranges", location: (.Produce, .Produce, .Produce)),
                                                                                                                                                                                    /* 11 */        Item(name: "Potatoes", location: (.Produce, .Produce, .Produce)),
                                                                                                                                                                                                    /* 12 */        Item(name: "Strawberries", location: (.Produce, .Produce, .Produce)),
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    /* 13 */        Item(name: "Butter", location: (.Dairy, .Dairy, .Dairy)),
                                                                                                                                                                                                                                    /* 14 */        Item(name: "Cheese", location: (.Dairy, .Dairy, .Dairy)),
                                                                                                                                                                                                                                                    /* 15 */        Item(name: "Eggs", location: (.Dairy, .Dairy, .Dairy)),
                                                                                                                                                                                                                                                                    /* 16 */        Item(name: "Lemonade", location: (.Dairy, .Dairy, .Dairy)),
                                                                                                                                                                                                                                                                                    /* 17 */        Item(name: "Milk", location: (.Dairy, .Dairy, .Dairy)),
                                                                                                                                                                                                                                                                                                    /* 18 */        Item(name: "Orange Juice", location: (.Dairy, .Dairy, .Dairy)),
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                    /* 19 */        Item(name: "Paper Towels", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .one)),
                                                                                                                                                                                                                                                                                                                                    /* 20 */        Item(name: "Toilet Paper", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .one)),
                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                    /* 21 */        Item(name: "Pet Food", location: (.Grocery, .Grocery, .Grocery), aisle: (.two, .two, .two)),
                                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                                    /* 22 */        Item(name: "Cereal", location: (.Grocery, .Grocery, .Grocery), aisle: (.three, .three, .three)),
                                                                                                                                                                                                                                                                                                                                                                                    /* 23 */        Item(name: "Peanut Butter", location: (.Grocery, .Grocery, .Grocery), aisle: (.three, .three, .three)),
                                                                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                    /* 24 */        Item(name: "Spices", location: (.Grocery, .Grocery, .Grocery), aisle: (.four, .four, .four)),
                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                    /* 25 */        Item(name: "Tacos", location: (.Grocery, .Grocery, .Grocery), aisle: (.six, .six, .six)),
                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                                    /* 26 */        Item(name: "Chips", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .seven)),
                                                                                                                                                                                                                                                                                                                                                                                                                                                    /* 27 */        Item(name: "Pop", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .seven)),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                    /* 28 */        Item(name: "Water", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .seven)),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    /* 29 */        Item(name: "Coffee", location: (.Grocery, .Grocery, .Grocery), aisle: (.eight, .eight, .eight)),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    /* 30 */        Item(name: "Bread", location: (.Grocery, .Grocery, .Grocery), aisle: (.bakery, .bakery, .bakery)),
]





/*
 //Produce
 var apples = Item(name: "Apples", location: (.Produce, .Produce, .Produce))
 var bannanas = Item(name: "Bannanas", location: (.Produce, .Produce, .Produce))
 var blueberries = Item(name: "Blueberries", location: (.Produce, .Produce, .Produce))
 var brocolli = Item(name: "Brocolli", location: (.Produce, .Produce, .Produce))
 var cabbage = Item(name: "Cabbage", location: (.Produce, .Produce, .Produce))
 var cucumber = Item(name: "Cucumber", location: (.Produce, .Produce, .Produce))
 var grapes = Item(name: "Grapes", location: (.Produce, .Produce, .Produce))
 var kiwi = Item(name: "Kiwi", location: (.Produce, .Produce, .Produce))
 var lettuce = Item(name: "Lettuce", location: (.Produce, .Produce, .Produce))
 var oranges = Item(name: "Oranges", location: (.Produce, .Produce, .Produce))
 var potatoes = Item(name: "Potatoes", location: (.Produce, .Produce, .Produce))
 var strawberries = Item(name: "Strawberries", location: (.Produce, .Produce, .Produce))
 
 
 //Dairy
 var butter = Item(name: "Butter", location: (.Dairy, .Dairy, .Dairy))
 var cheese = Item(name: "Cheese", location: (.Dairy, .Dairy, .Dairy))
 var eggs = Item(name: "Eggs", location: (.Dairy, .Dairy, .Dairy))
 var lemonade = Item(name: "Lemonade", location: (.Dairy, .Dairy, .Dairy))
 var milk = Item(name: "Milk", location: (.Dairy, .Dairy, .Dairy))
 var orangejuice = Item(name: "Orange Juice", location: (.Dairy, .Dairy, .Dairy))
 
 //Grocery
 var papertowels = Item(name: "Paper Towels", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .one,)
 var toiletpaper = Item(name: "Toilet Paper", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .one,)
 
 var petfood = Item(name: "Pet Food", location: (.Grocery, .Grocery, .Grocery), aisle: (.two, .two, .two)
 
 var cereal = Item(name: "Cereal", location: (.Grocery, .Grocery, .Grocery), aisle: (.three, .three, .three))
 var peanutbutter = Item(name: "Peanut Butter", location: (.Grocery, .Grocery, .Grocery), aisle: (.three, .three, .three))
 
 var tacos = Item(name: "Tacos", location: (.Grocery, .Grocery, .Grocery), aisle: (.six, .six, .six))
 
 var chips = Item(name: "Chips", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .seven))
 var pop = Item(name: "Pop", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .seven))
 var water = Item(name: "Water", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .seven))
 
 var coffee = Item(name: "Coffee", location: (.Grocery, .Grocery, .Grocery), aisle: (.eight, .eight, .eight))
 
 */


