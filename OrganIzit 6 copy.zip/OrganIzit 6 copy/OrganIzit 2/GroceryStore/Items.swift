//
//  Items.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-27.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit
import Foundation

class Item: Comparable, Equatable {

    
        var name: String
        var type: Department
        var quantity: Int = 0
        var notes: String = ""
        var aisle: Aisle? = nil
        
        init(name: String, type: Department, aisle: Aisle?){
            self.name = name
            self.type = type
            self.aisle = aisle
        }
        
        func addOne() {
            quantity += 1
        }
        
        func subtractOne() {
            if quantity > 0 {
                quantity -= 1
            }
        }
        
        func changeNote(note: String) {
            notes = note
        }
        
        
        static func < (lhs: Item, rhs: Item) -> Bool {
            return  lhs.name < rhs.name
        }
        
        static func > (lhs: Item, rhs: Item) -> Bool {
            return  lhs.name > rhs.name
        }
        
        static func == (lhs: Item, rhs: Item) -> Bool {
            return  lhs.name == rhs.name
        }
    }
    
    
    enum Department {
        case Produce
        case Meat
        case Dairy
        case Grocery
        case Other
        case Pop
    }
    
    enum Aisle {
        case HABA
        case two
        case three
        case four
        case five
        case six
        case seven
        case eight
    }
    
    var allItems: [Item] = [
        Item(name: "nil", type: .Other, aisle: nil),
        
        Item(name: "Apples", type: .Produce, aisle: nil),
        Item(name: "Bannanas", type: .Produce, aisle: nil),
        Item(name: "Blueberries", type: .Produce, aisle: nil),
        Item(name: "Brocolli", type: .Produce, aisle: nil),
        Item(name: "Cabbage", type: .Produce, aisle: nil),
        Item(name: "Cucumber", type: .Produce, aisle: nil),
        Item(name: "Grapes", type: .Produce, aisle: nil),
        Item(name: "Kiwi", type: .Produce, aisle: nil),
        Item(name: "Lettuce", type: .Produce, aisle: nil),
        Item(name: "Oranges", type: .Produce, aisle: nil),
        Item(name: "Potatoes", type: .Produce, aisle: nil),
        Item(name: "Strawberries", type: .Produce, aisle: nil),
        
        
        Item(name: "Butter", type: .Dairy, aisle: nil),
        Item(name: "Cheese", type: .Dairy, aisle: nil),
        Item(name: "Eggs", type: .Dairy, aisle: nil),
        Item(name: "Lemonade", type: .Dairy, aisle: nil),
        Item(name: "Milk", type: .Dairy, aisle: nil),
        Item(name: "Orange Juice", type: .Dairy, aisle: nil),
        
        
        
        Item(name: "Paper Towels", type: .Grocery, aisle: .HABA),
        Item(name: "Toilet Paper", type: .Grocery, aisle: .HABA),
        
        Item(name: "Pet Food", type: .Grocery, aisle: .two),
        
        Item(name: "Cereal", type: .Grocery, aisle: .three),
        Item(name: "Peanut Butter", type: .Grocery, aisle: .three),
        
        Item(name: "Spices", type: .Grocery, aisle: .four),
        
        Item(name: "Tacos", type: .Grocery, aisle: .six),
        
        Item(name: "Chips", type: .Grocery, aisle: .seven),
        Item(name: "Pop", type: .Grocery, aisle: .seven),
        Item(name: "Water", type: .Grocery, aisle: .seven),
        
        Item(name: "Coffee", type: .Grocery, aisle: .eight),
        ]
    
    
    var list: [Item] = [allItems[0]]
    var savedLists = [("nil", list)]
    

    
    
    /*
     //Produce
     var apples = Item(name: "Apples", type: .Produce, aisle: nil)
     var bannanas = Item(name: "Bannanas", type: .Produce, aisle: nil)
     var blueberries = Item(name: "Blueberries", type: .Produce, aisle: nil)
     var brocolli = Item(name: "Brocolli", type: .Produce, aisle: nil)
     var cabbage = Item(name: "Cabbage", type: .Produce, aisle: nil)
     var cucumber = Item(name: "Cucumber", type: .Produce, aisle: nil)
     var grapes = Item(name: "Grapes", type: .Produce, aisle: nil)
     var kiwi = Item(name: "Kiwi", type: .Produce, aisle: nil)
     var lettuce = Item(name: "Lettuce", type: .Produce, aisle: nil)
     var oranges = Item(name: "Oranges", type: .Produce, aisle: nil)
     var potatoes = Item(name: "Potatoes", type: .Produce, aisle: nil)
     var strawberries = Item(name: "Strawberries", type: .Produce, aisle: nil)
     
     
     //Dairy
     var butter = Item(name: "Butter", type: .Dairy, aisle: nil)
     var cheese = Item(name: "Cheese", type: .Dairy, aisle: nil)
     var eggs = Item(name: "Eggs", type: .Dairy, aisle: nil)
     var lemonade = Item(name: "Lemonade", type: .Dairy, aisle: nil)
     var milk = Item(name: "Milk", type: .Dairy, aisle: nil)
     var orangejuice = Item(name: "Orange Juice", type: .Dairy, aisle: nil)
     
     //Grocery
     var papertowels = Item(name: "Paper Towels", type: .Grocery, aisle: .HABA)
     var toiletpaper = Item(name: "Toilet Paper", type: .Grocery, aisle: .HABA)
     
     var petfood = Item(name: "Pet Food", type: .Grocery, aisle: .two)
     
     var cereal = Item(name: "Cereal", type: .Grocery, aisle: .three)
     var peanutbutter = Item(name: "Peanut Butter", type: .Grocery, aisle: .three)
     
     var tacos = Item(name: "Tacos", type: .Grocery, aisle: .six)
     
     var chips = Item(name: "Chips", type: .Grocery, aisle: .seven)
     var pop = Item(name: "Pop", type: .Grocery, aisle: .seven)
     var water = Item(name: "Water", type: .Grocery, aisle: .seven)
     
     var coffee = Item(name: "Coffee", type: .Grocery, aisle: .eight)
     
     */


