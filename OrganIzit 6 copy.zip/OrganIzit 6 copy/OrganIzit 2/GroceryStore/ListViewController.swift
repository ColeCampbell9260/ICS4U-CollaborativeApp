//
//  ListViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-28.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

class ListViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
  

}
