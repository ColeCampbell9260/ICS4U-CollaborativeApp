//
//  itemsToAddToList.swift
//  OrganIzit
//
//  Created by Brian Alpaugh on 2018-12-10.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class itemsToAddToList: UITableViewCell {

    @IBOutlet weak var itemsUserCanAddTList: UILabel!
    @IBOutlet weak var indicatesIfAddingOrRemoving: UIButton!
    @IBAction func changesAdingOrRemoving(_ sender: UIButton) {
        
        if indicatesIfAddingOrRemoving.titleLabel?.text == "Add" {
            indicatesIfAddingOrRemoving.setTitle("Remove", for: .normal)
        } else if indicatesIfAddingOrRemoving.titleLabel?.text == "Remove" {
            indicatesIfAddingOrRemoving.setTitle("Add", for: .normal)
        }
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
