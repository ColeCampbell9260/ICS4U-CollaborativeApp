//
//  allUsedVariables.swift
//  OrganIzit
//
//  Created by Brian Alpaugh on 2018-12-19.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import Foundation

// Saves the title of the Users List
var listTitle : String = ""


// Creates all the types of packing lists the user may want
let lacrosse = TypeOfList(nameOfActivityType: "Lacrosse", doesUserWantOnThereList: false, whatUserWillAddToList: ["Helmet", "Mouthguard", "Shoulder pads", "Elbow pads", "Arm pads", "Gloves", "Cleats", "Jersey"])

let soccer = TypeOfList(nameOfActivityType: "Soccer", doesUserWantOnThereList: false, whatUserWillAddToList: ["Cleats", "Shin guards", "Socks", "Jersey", "Shorts"])

let rugby = TypeOfList(nameOfActivityType: "Rugby", doesUserWantOnThereList: false, whatUserWillAddToList: ["Compression wear", "Mouthguard", "Shirt", "Shorts", "Socks", "Scrum cap", "Shin guards"])

let baseball = TypeOfList(nameOfActivityType: "Baseball", doesUserWantOnThereList: false, whatUserWillAddToList: ["Bat", "Helmet", "Glove", "Cleats", "Pants", "Jersey", "Back catcher gear"])

let swimming = TypeOfList(nameOfActivityType: "Swimming", doesUserWantOnThereList: false, whatUserWillAddToList: ["Goggles", "Bathing suit"])

let football = TypeOfList(nameOfActivityType: "Football", doesUserWantOnThereList: false, whatUserWillAddToList: ["Helmet", "Neck guard", "Jock", "Mouthguard", "Thigh pads", "Hip pads", "Knee pads", "Tailbone pad", "Shoulder pads", "Gloves", "Jersey", "Pants", "Girdle", "Undergear"])

let fieldHockey = TypeOfList(nameOfActivityType: "Field Hockey", doesUserWantOnThereList: false, whatUserWillAddToList: ["Stick", "Cleats", "Shin guards", "Socks", "Mouthguard", "Uniform"])

let tennis = TypeOfList(nameOfActivityType: "Tennis", doesUserWantOnThereList: false, whatUserWillAddToList: ["Racket", "Collared shirt", "Shoes", "Shorts"])

let bobsleigh = TypeOfList(nameOfActivityType: "Bob Sleigh", doesUserWantOnThereList: false, whatUserWillAddToList: ["Helmet", "Sleigh", "Shoes"])

let hockey = TypeOfList(nameOfActivityType: "Hockey", doesUserWantOnThereList: false, whatUserWillAddToList: ["Jock", "Shin pads", "Elbow pads", "Socks", "Jersey", "Pants", "Skates", "Shoulder pads", "Neck guard", "Helmet", "Gloves", "Stick", "Extra undergear"])

let skiing = TypeOfList(nameOfActivityType: "Skiing", doesUserWantOnThereList: false, whatUserWillAddToList: ["Skies", "Helmet", "Winter clothes", "Poles", "Boots", "Balaclava"])

let ringette = TypeOfList(nameOfActivityType: "Ringette", doesUserWantOnThereList: false, whatUserWillAddToList: ["Helmet", "Gloves", "Jersey", "Elbow pads", "Shoulder pads", "Neck guard", "Skates", "Pants", "Socks", "Shin pads", "Jock", "Stick", "Extra undergear"])

let speedSkating = TypeOfList(nameOfActivityType: "Speed Skating", doesUserWantOnThereList: false, whatUserWillAddToList: ["Skates", "Helmet", "Goggles", "Spandex"])

let snowboarding = TypeOfList(nameOfActivityType: "Snowboarding", doesUserWantOnThereList: false, whatUserWillAddToList: ["Snowboard", "Boots", "Winter clothing", "Helmet", "Goggles", "Balaclava"])

let luge = TypeOfList(nameOfActivityType: "Luge", doesUserWantOnThereList: false, whatUserWillAddToList: ["Racing booties", "Spiked gloves", "Racing suit", "Helmet", "Sled", "Spandex"])

let curling = TypeOfList(nameOfActivityType: "Curling", doesUserWantOnThereList: false, whatUserWillAddToList: ["Shoes", "Broom", "Sweater", "Pants", "Stop watch"])

let hot = TypeOfList(nameOfActivityType: "Hot", doesUserWantOnThereList: false, whatUserWillAddToList: ["Bathing suit", "Shorts", "T-shirt", "Hat", "Sunscreen", "Towels", "Sandals", "Running shoes", "Sand toys", "Umbrella", "Undergarments", "Sun glasses", "Camera", "Floaties", "Life jacket", "Cooler", "Capris", "Tank tops", "Hoodies", "Long pants", "Long sleves", "Sun screen"])

let cold = TypeOfList(nameOfActivityType: "Cold", doesUserWantOnThereList: false, whatUserWillAddToList: ["Coat", "Snow Pants", "Boots", "Gloves", "Mittens", "Blanket", "Hat", "Sled", "Board games", "Shovel", "Pants", "Shirts", "Kleenex", "Scarf", "Balaclava", "Sweater", "Capris"])

let overnight = TypeOfList(nameOfActivityType: "Overnight", doesUserWantOnThereList: false, whatUserWillAddToList: ["Toiletries", "Pyjamas"])

let plane = TypeOfList(nameOfActivityType: "Plane", doesUserWantOnThereList: false, whatUserWillAddToList: [ "Book", "Electronics", "Charger cords", "Carry on bag", "Gum", "Snacks"])

let outOfCountry = TypeOfList(nameOfActivityType: "Out of Country", doesUserWantOnThereList: false, whatUserWillAddToList: ["Passport"])

let car = TypeOfList(nameOfActivityType: "Car", doesUserWantOnThereList: false, whatUserWillAddToList: ["Book", "Electronics", "Charger cords", "Water bottle", "Snacks"])


// Creates all variables for displaying the users list
var positionInArrayChanger : Int = 0
var namesOfAllLists : [String] = ["You have no lists, click the + to create"]
var positionInArraysForList : [String : Int] = [:]
var itemsOnLists : [[String : Bool]] = [[:]]
