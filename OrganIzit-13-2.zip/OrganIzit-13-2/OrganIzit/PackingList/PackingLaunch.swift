//
//  PackingLaunch.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-03.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class PackingLaunch: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func viewDidAppear() {
        
    }
}
