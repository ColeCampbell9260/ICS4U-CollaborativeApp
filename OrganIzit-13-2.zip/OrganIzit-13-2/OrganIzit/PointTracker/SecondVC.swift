//
//  SecondVC.swift
//  OrganIzit
//
//  Created by Julia Baxter on 2018-11-29.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

public var selectedScreen:Int = 3 //Choose a number from 1-3 to change what data is being loaded in


class SecondVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var tableArray:[String] = []

    @IBAction func backButton(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    

    @IBOutlet weak var companyImage: UIImageView!
    @IBOutlet weak var pointsLabel: UILabel!
    @IBOutlet weak var storeTable: UITableView!
    
    @IBOutlet weak var barTitle: UINavigationItem!
    override func viewWillAppear(_ animated: Bool) {
        switch  selectedScreen {
        case 1:
            barTitle.title = "Triangle"
            var points = (UserDefaults.standard.object(forKey: "Triangle") ?? 0)
            tableArray = ["Canadian Tire", "Food Basics", "Foodland", "Shopper's Drug Mart", "Total Health Pharmacy", "Tim Horton's", "McDonald's", "Subway", "Harvey's", "Swiss Chalet"]
            
            companyImage.image = UIImage(named: "TriangleLogo")
            pointsLabel.text = "\(points)"
            storeTable.insertRows(at: [NSIndexPath(row: tableArray.count-1, section: 0) as IndexPath], with: .automatic)
            
            UserDefaults.standard.set(points, forKey: "Triangle")
        case 2:
            barTitle.title = "Air Miles"

            var points = (UserDefaults.standard.object(forKey: "AirMiles") ?? 0)
            tableArray = ["BMO", "Shell", "LCBO", "Foodland", "Food Basics"]
            
            companyImage.image = UIImage(named:"AirMilesLogo")
            pointsLabel.text = "\(points)"
            
            UserDefaults.standard.set(points, forKey: "AirMiles")
        case 3:
            barTitle.title = "PC Optimum"

            var points = (UserDefaults.standard.object(forKey: "PC") ?? 0)
            tableArray = ["Esso", "Shopper's Drug Mart"]
            
            companyImage.image = UIImage(named: "PCOptimumLogo")
            pointsLabel.text = "\(points)"
            
            UserDefaults.standard.set(points, forKey: "PC")
        default:
            print("dab")
        }
        storeTable.reloadData()
        
    }
    func openURL(url:String){
        let temp = URL(string:url)!
        UIApplication.shared.open(temp, options: [:], completionHandler: nil)
    }
    func numberOfSections(in testTable: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return tableArray.count
        }else {
            return 0
        }
        
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = storeTable.dequeueReusableCell(withIdentifier: "cellIdentifier", for: indexPath)
        cell.textLabel?.text = tableArray[indexPath.row]
        cell.showsReorderControl = true
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch tableArray[indexPath.row] {
        case "Canadian Tire":
            openURL(url: "https://www.canadiantire.ca/en.html")
        case "Food Basics":
            openURL(url: "https://www.foodbasics.ca/flyer.en.html")
        case "Foodland":
            openURL(url: "https://ontario.foodland.ca/flyer/")
        case "Shopper's Drug Mart":
            openURL(url: "https://www1.shoppersdrugmart.ca/en/flyer")
        case "Total Health Pharmacy":
            openURL(url: "https://www1.shoppersdrugmart.ca/en/flyer")
        case "McDonald's":
            openURL(url: "https://www.mcdonalds.com/ca/en-ca.html")
        case "Tim Horton's":
            openURL(url: "https://timhortons.ca/ca/en/index.php")
        case "Subway":
            openURL(url: "https://www.subway.com/en-CA")
        case "Harvey's":
            openURL(url: "https://www.harveys.ca/eng/")
        case "Swiss Chalet":
            openURL(url: "https://www.swisschalet.com/")
        case "Esso":
            openURL(url: "https://www.esso.ca/en/")
        case "BMO":
            openURL(url: "https://www.bmo.com/main/personal")
        case "Shell":
            openURL(url: "https://www.shell.ca")
        case "LCBO":
            openURL(url: "http://www.lcbo.com/content/lcbo/en.html")
        default:
            print("No link available")
        }
        
        
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        storeTable.dataSource = self
        storeTable.delegate = self
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
