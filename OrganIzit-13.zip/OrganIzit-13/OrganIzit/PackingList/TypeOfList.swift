//
//  TypeOfList.swift
//  OrganIzit
//
//  Created by Brian Alpaugh on 2018-12-10.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import Foundation

class TypeOfList: NSObject {
    
    var nameOfActivityType : String = ""
    var doesUserWantOnThereList : Bool = false
    var whatUserWillAddToList : [String] = []
    
    init(nameOfActivityType : String, doesUserWantOnThereList : Bool, whatUserWillAddToList : [String]) {
        self.nameOfActivityType = nameOfActivityType
        self.doesUserWantOnThereList = doesUserWantOnThereList
        self.whatUserWillAddToList = whatUserWillAddToList
    }
    
}
