//
//  ICS4U Collaborative App
//  OrganIzit
//

import UIKit

class LandingPageViewController: UIViewController {

    var profiles : [Profile] = []
    
    @IBOutlet weak var profilePictureView: UIImageView!
    @IBOutlet weak var createProfileButton: UIButton!
    @IBOutlet weak var editProfileButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func createProfilePressed(_ sender: Any) {
        print(profiles.count)
        performSegue(withIdentifier: "Profile", sender: createProfileButton)
    }
    
    @IBAction func editProfilePressed(_ sender: Any) {
        performSegue(withIdentifier: "Profile", sender: editProfileButton)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let sender = sender as? UIButton else {return}
        switch(sender) {
        case createProfileButton:
            segue.destination.navigationItem.title = "Create New Profile"
            break
        case editProfileButton:
            segue.destination.navigationItem.title = "Edit Existing Profile"
            break
        default:
            break
        }
    }
    
    @IBAction func unwindBack(segue: UIStoryboardSegue) { }
    
}

