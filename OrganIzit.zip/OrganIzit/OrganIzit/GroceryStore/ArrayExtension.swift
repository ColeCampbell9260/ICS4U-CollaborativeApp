//
//  ArrayExtension.swift
//  testingSegues
//
//  Created by Lizzy on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import Darwin

extension Array {
    mutating func removeObjFromArray<U: Equatable> (object: U) {
        var index: Int?
        for (idx, objectToCOmpare) in self.enumerated() {
            if let to = objectToCOmpare as? U {
                if object == to {
                    index = idx
                }
            }
        }
        if ((index) != nil) {
            self.remove(at: index!)
        }
    }
    func get(index: Int) -> Any? {
        if 0 <= index && index < count {
            return self[index]
        } else {
            return nil
        }
    }
    func checkIndex(num: Int) -> Bool {
        if let _ = get(index: num) {
            return true
        } else {
            return false
        }
    }
}
