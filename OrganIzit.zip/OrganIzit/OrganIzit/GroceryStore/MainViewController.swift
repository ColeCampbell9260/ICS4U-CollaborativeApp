//
//  ViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-19.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

var currentStore: String = "none"
let screenSize = UIScreen.main.bounds

var list = [Item]()
var savedLists = [("nil", list)]




class MainViewController: UIViewController {
    
    var colour = UIColor.white
    var foodBasics = false
    @IBOutlet weak var foodBasicsButton: UIButton!
    
    @IBOutlet weak var shoppersButton: UIButton!
    
    @IBOutlet weak var foodlandButton: UIButton!
    override func viewDidLoad() {
        
        foodBasicsButton.layer.borderWidth = 2
        foodBasicsButton.layer.borderColor = UIColor.gray.cgColor
        foodBasicsButton.layer.cornerRadius = 7
        
        
        shoppersButton.layer.borderWidth = 2
        shoppersButton.layer.borderColor = UIColor.gray.cgColor
        shoppersButton.layer.cornerRadius = 7

        
        foodlandButton.layer.borderWidth = 2
        foodlandButton.layer.borderColor = UIColor.gray.cgColor
        foodlandButton.layer.cornerRadius = 7

        
        foodBasics = false
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    }
    
    
    @IBAction func FoodBasicsButton(_ sender: Any) {
        currentStore = "Basics"
        colour = .green
    }
    
    @IBAction func FoodLandButton(_ sender: Any) {
        currentStore = "Land"
        colour = .red
    }
    
    @IBAction func ShoppersDrugmartButton(_ sender: Any) {
        currentStore = "Shoppers"
        colour = .blue
    }
}

