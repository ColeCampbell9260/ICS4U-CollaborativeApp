//
//  NodeView.swift
//  testingSegues
//
//  Created by Lizzy on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

let INFINITE = 99999
class NodeView: UIView {
    let size: CGFloat = 50
    var nodes: [[Node]] = []
    
    override func awakeFromNib() {
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        
        nodes[Int(size)-1][0].type = .pointA
        nodes[0][Int(size)-1].type = .pointB
        self.setNeedsDisplay()
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        setCoordinates()
    }
    
    func setCoordinates() {
        
        //frozen sweets
        for m in 2...21{
            for n in 0...6{
                nodes[m][n].type = .Obstacle
            }
        }
        //frozen food
        for m in 0...1{
            for n in 0...43{
                nodes[m][n].type = .Obstacle
            }
        }
        //seafood
        for m in 46..<50 {
            for n in 0...49 {
                nodes[m][n].type = .Obstacle
            }
        }
        //meat
        for m in 43...44{
            for n in 11...38{
                nodes[m][n].type = .Obstacle
            }
        }
        //Pharm
        for m in 40...41{
            for n in 11...38{
                nodes[m][n].type = .Obstacle
            }
        }
        //2
        for m in 37...38{
            for n in 11...38{
                nodes[m][n].type = .Obstacle
            }
        }
        //3
        for m in 20...35{
            for n in 11...38{
                nodes[m][n].type = .Obstacle
            }
        }
        //4
        for m in 17...18{
            for n in 11...38{
                nodes[m][n].type = .Obstacle
            }
        }
        //5
        for m in 14...15{
            for n in 11...38{
                nodes[m][n].type = .Obstacle
            }
        }
        //6
        for m in 12...12{
            for n in 11...38{
                nodes[m][n].type = .Obstacle
            }
        }
        //7
        for m in 7...10{
            for n in 11...38{
                nodes[m][n].type = .Obstacle
            }
        }
        //8
        for m in 4...5{
            for n in 11...38{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //        dairy and fancy meat
        for m in 0..<50{
            for n in 44..<50{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //        produce and bakery
        for m in 46..<50{
            for n in 0..<50{
                nodes[m][n].type = .Obstacle
            }
        }
        // Set start point
        for m in 45...45 {
            for n in 0...0{
                nodes[m][n].type = .pointA
            }
        }
        // Set end point
        for m in 0..<38{
            for n in 44..<50{
                nodes[m][n].type = .pointB
            }
        }
    }
    
    // Creates the grid we use for coordinates
    func createRect(rect: CGRect, colour: UIColor) {
        let cont = UIGraphicsGetCurrentContext()
        cont!.setFillColor(colour.cgColor)
        cont!.setStrokeColor(UIColor.orange.cgColor)
        cont!.fill(rect)
        cont!.stroke(rect, width: 2)
    }
    
    func getNeighbourForNode(node: Node) -> [Node] {
        let nodex = node.x
        let nodey = node.y
        var finalNodes: [Node] = []
        if nodes.checkIndex(num: nodey-1) {
            finalNodes.append(nodes[nodey-1][nodex])
        }
        if nodes.checkIndex(num: nodey+1) {
            finalNodes.append(nodes[nodey+1][nodex])
        }
        if nodes.checkIndex(num: nodex+1) {
            finalNodes.append(nodes[nodey][nodex+1])
        }
        if nodes.checkIndex(num: nodex-1) {
            finalNodes.append(nodes[nodey][nodex-1])
        }
        var realFinalNode: [Node] = []
        for i in finalNodes {
            if i.from == nil && i.type != .Obstacle {
                realFinalNode.append(i)
            }
        }
        return realFinalNode
    }
    
    // Formula
    func heuristicCostEstimate(from: Node, to: Node) -> Int {
        return (abs(from.x - to.x) + abs(from.y - to.y)) * 40
    }
    
    func a_star(_start: Node, _goal: Node) -> [Node] {
        let start = _start
        let goal = _goal
        var closedSet: [Node] = []
        var openSet: [Node] = [start]
        start.g = 0
        start.h = heuristicCostEstimate(from: start, to: goal)
        while openSet.count != 0 {
            var current = lowestFScore()
            if closedSet.count > 0 && openSet.count > 0 {
                if current == closedSet[closedSet.count-1] {
                    current = openSet[0]
                }
            }
            if current == goal {return reconstructPath(current: current)}
            openSet.removeObjFromArray(object: current)
            closedSet.append(current)
            for neighbour in getNeighbourForNode(node: current) {
                var shouldExecuteIf = true
                if closedSet.contains(neighbour) {shouldExecuteIf = false}
                if shouldExecuteIf {
                    var tentative_g_score = 0
                    tentative_g_score = current.g + 10
                    if !openSet.contains(neighbour) || tentative_g_score < neighbour.g {
                        neighbour.from = current
                        neighbour.g = tentative_g_score
                        neighbour.h = heuristicCostEstimate(from: neighbour, to: goal)
                        if !openSet.contains(neighbour) {openSet.append(neighbour)}
                    }
                    nodes[neighbour.y][neighbour.x].type = .ExploredPath
                    self.setNeedsDisplay()
                }
            }
        }
        self.setNeedsDisplay()
        return []
    }
    
    func solve() {
        resetNodes()
        let path = a_star(_start: nodes[Int(size)-1][0], _goal: nodes[0][Int(size)-1])
        for i in path {
            if nodes[i.y][i.x].type != .pointA && nodes[i.y][i.x].type != .pointB {
                nodes[i.y][i.x].type = .Path
            }
        }
        nodes[0][Int(size)-1].type = .pointB
        nodes[Int(size)-1][0].type = .pointA
        self.setNeedsDisplay()
    }
    override func draw(_ rect: CGRect) {
        self.subviews.map({ $0.removeFromSuperview() })
        let width = self.frame.size.width / size
        let height = self.frame.size.height / size
        var x: CGFloat = 0
        var y: CGFloat = 0
        
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                let rect = CGRect(x: x, y: y, width: width, height: height)
                createRect(rect: rect, colour: nodes[i][j].colour)
                x += width
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
            y += height
            x = 0
        }
    }
    func clear() {
        resetAllNodes()
    }
    
    func resetAllNodes() {
        nodes = []
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        nodes[Int(size)-1][0].type = .pointA
        nodes[0][Int(size)-1].type = .pointB
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        self.setNeedsDisplay()
    }
    func resetNodes() {
        var tempNodes = nodes
        nodes = []
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        nodes[Int(size)-1][0].type = .pointA
        nodes[0][Int(size)-1].type = .pointB
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        for i in 0..<tempNodes.count {
            for j in 0..<tempNodes[i].count {
                if tempNodes[i][j].type == .Obstacle {
                    nodes[i][j].type = .Obstacle
                }
            }
        }
        self.setNeedsDisplay()
    }
    
    func reconstructPath(current: Node)-> [Node] {
        var totalPath: [Node] = [current]
        while let par = totalPath.first!.from {
            totalPath.insert(par, at: 0)
        }
        return totalPath
    }
    
    func lowestFScore()-> Node {
        var finalNode: Node = Node()
        finalNode.g = INFINITE
        finalNode.h = INFINITE
        for i in nodes {
            for j in i {
                if j.f <= finalNode.f && j.g != -100 {
                    finalNode = j
                }
            }
        }
        return finalNode
    }
}

