//
//  NodeViewFoodland.swift
//  OrganIzit
//
//  Created by Nate Maier on 2019-01-16.
//  Copyright © 2019 Cole Campbell. All rights reserved.
//

import UIKit


class NodeViewFoodland: UIView {
    var counter = 0
    let size: CGFloat = 70 // size of grid
    var nodes: [[Node]] = [] // array of all the nodes (empty at first)
    
    var fillp1 = Node()
    var fillp2 = Node()
    
    override func layoutSubviews() {
        //  makeButton()
    }
    
    override func awakeFromNib() {
        
        // puts all the nodes into the array and makes all dummy nodes of type air
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        setCoordinates()
        setPoints()
        listTypes()
        for po in myArray {
            po.type = .other
        }
        self.setNeedsDisplay() // refreshes page
        // creates x and y values for each node in the array
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
       // drawThePath()
    }
    
    
    // makes the "path" button
    /*func makeButton() -> UIButton {
     let myButton = UIButton(type: UIButton.ButtonType.system)
     myButton.frame = CGRect(x: 20, y: 350, width: 50, height: 50)
     myButton.backgroundColor = UIColor.clear
     myButton.setTitle("Path", for: .normal)
     myButton.setTitleColor(UIColor.black, for: .normal)
     //myButton.titleLabel.adjustsFontSizeToFitWidth = true
     myButton.addTarget(self, action: #selector(buttonPressed), for: .touchUpInside)
     self.addSubview(myButton)
     return myButton
     }*/
    
    func setPoints() {
        // sets points for all the aisles
        pointEntrance = nodes[50][2] //done
        myArray.append(pointEntrance)
        pointProd = nodes[57][15]//done
        pointMeat = nodes[57][60]//might be wrong
        pointBak = nodes[57][37]//done
        pointPharm = nodes[57][38] //done
        point2 = nodes[45][38]//done
        point3 = nodes[41][38]//done
        point4 = nodes[36][38]//done
        pointDairy = nodes[42][58]//done
        point5 = nodes[30][38]//dont know because we don't have anything in 5
        pointFrozSweets = nodes[24][18]
        point6 = nodes[24][38]//done
        point7 = nodes[19][38]//done
        pointFrozenFood = nodes[7][38]//can't check
        point8 = nodes[14][38]//done
    }
    
    // sets obstacles
    func setCoordinates() {
        //idk
        for m in 7...61 {
            for n in 61...69{
                nodes[m][n].type = .Obstacle
            }
        }
        //frozen sweets
        for m in 3...42{
            for n in 0...17{
                nodes[m][n].type = .Obstacle
            }
        }
        //frozen food and seafood
        for m in 0...6{
            for n in 0..<70{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //1
        for m in 51...56{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        
       ///2
        for m in 46...49{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //3
        for m in 42...44{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        //4
        for m in 37...40{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }

        //5
        for m in 31...35{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
      

        //6
        for m in 25...29{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        //7
        for m in 20...23{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        

        //8
        
        for m in 15...18{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //9
        for m in 8...13{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        
        
        //dairy
        for m in 0..<70{
            for n in 59..<70{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //Produce in bottom left
        for m in 55..<70{
            for n in 0...12{
                nodes[m][n].type = .Obstacle
            }
        }
        
        
        //produce and bakery
        for m in 62..<70{
            for n in 0..<70{
                nodes[m][n].type = .Obstacle
            }
        }
    }
    
    // Creates the grid we use for coordinates
    func createRect(rect: CGRect, colour: UIColor) {
        let cont = UIGraphicsGetCurrentContext()
        cont!.setFillColor(colour.cgColor)
        cont!.setStrokeColor(UIColor.clear.cgColor)
        cont!.fill(rect)
        cont!.stroke(rect, width: 2)
    }
    
    // looks left right up and down to check the next node
    func getNeighbourForNode(node: Node, start: Node, goal: Node) -> [Node] {
        let nodex = node.x
        let nodey = node.y
        var finalNodes: [Node] = []
        
        if start.x <= goal.x {
            if nodes.checkIndex(num: nodex+1) {
                finalNodes.append(nodes[nodey][nodex+1])
            }
            if nodes.checkIndex(num: nodey-1) {
                finalNodes.append(nodes[nodey-1][nodex])
            }
            if nodes.checkIndex(num: nodex-1) {
                finalNodes.append(nodes[nodey][nodex-1])
            }
            if nodes.checkIndex(num: nodey+1) {
                finalNodes.append(nodes[nodey+1][nodex])
            }
        }
        if start.x >= goal.x {
            if nodes.checkIndex(num: nodex-1) {
                finalNodes.append(nodes[nodey][nodex-1])
            }
            if nodes.checkIndex(num: nodey-1) {
                finalNodes.append(nodes[nodey-1][nodex])
            }
            if nodes.checkIndex(num: nodex+1) {
                finalNodes.append(nodes[nodey][nodex+1])
            }
            if nodes.checkIndex(num: nodey+1) {
                finalNodes.append(nodes[nodey+1][nodex])
            }
            
        }
        
        
        var realFinalNode: [Node] = []
        for i in finalNodes {
            if i.from == nil && i.type != .Obstacle {
                realFinalNode.append(i)
            }
        }
        return realFinalNode
    }
    
    
    // Formula to estimate heuristic cost from one node to another node
    func heuristicCostEstimate(from: Node, to: Node) -> Int {
        return (abs(from.x - to.x) + abs(from.y - to.y)) * 40
    }
    // algorithm so find shortest path
    func a_star(_start: Node, _goal: Node) -> [Node] {
        let start = _start
        let goal = _goal
        var closedSet: [Node] = []
        var openSet: [Node] = [start]
        start.g = 0
        start.h = heuristicCostEstimate(from: start, to: goal)
        while openSet.count != 0 {
            var current = lowestFScore()
            if closedSet.count > 0 && openSet.count > 0 {
                if current == closedSet[closedSet.count-1] {
                    current = openSet[0]
                }
            }
            if current == goal {return reconstructPath(current: current)}
            openSet.removeObjFromArray(object: current)
            closedSet.append(current)
            for neighbour in getNeighbourForNode(node: current, start: start, goal: goal) {
                var shouldExecuteIf = true
                if closedSet.contains(neighbour) {shouldExecuteIf = false}
                if shouldExecuteIf {
                    var tentative_g_score = 0
                    tentative_g_score = current.g + 10
                    if !openSet.contains(neighbour) || tentative_g_score < neighbour.g {
                        neighbour.from = current
                        neighbour.g = tentative_g_score
                        neighbour.h = heuristicCostEstimate(from: neighbour, to: goal)
                        if !openSet.contains(neighbour)  {openSet.append(neighbour)}
                    }
                    //nodes[neighbour.y][neighbour.x].type = .ExploredPath
                    // self.setNeedsDisplay()
                }
            }
        }
        self.setNeedsDisplay()
        return []
    }
    
    /* @IBAction func buttonPressed(_ sender: UIButton!) {
     print("the button was pressed")
     for n in myArray {
     counter += 1
     if counter < myArray.count {
     let path = a_star(_start: n, _goal: myArray[counter])
     for i in path {
     nodes[i.y][i.x].type = .Path
     }
     print("start: \(n.y), \(n.x)")
     print("goal: \(myArray[counter].y), \(myArray[counter].x)")
     }
     }
     self.setNeedsDisplay()
     }*/
    func drawThePath() {
        counter = 0
        print("the button was pressed")
        for n in myArray {
            counter += 1
            if counter < myArray.count {
                let path = a_star(_start: n, _goal: myArray[counter])
                for i in path {
                    nodes[i.y][i.x].type = .Path
                    
                }
                print("start path: \(n.y), \(n.x)")
                print("goal path: \(myArray[counter].y), \(myArray[counter].x)")
            }
        }
        self.setNeedsDisplay()
    }
    
    func dummy() {
        counter = 0
        for n in myArray {
            counter += 1
            if counter < myArray.count {
                let path = a_star(_start: n, _goal: myArray[counter])
                for i in path {
                    nodes[i.y][i.x].type = .Air
                }
                print("start air: \(n.y), \(n.x)")
                print("goal air: \(myArray[counter].y), \(myArray[counter].x)")
            }
        }
        self.setNeedsDisplay()
    }
    
    override func draw(_ rect: CGRect) {
        self.subviews.map({ $0.removeFromSuperview() })
        let width = self.frame.size.width / size
        let height = self.frame.size.height / size
        var x: CGFloat = 0
        var y: CGFloat = 0
        
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                let rect = CGRect(x: x, y: y, width: width, height: height)
                createRect(rect: rect, colour: nodes[i][j].colour)
                x += width
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
            y += height
            x = 0
        }
    }
    func clear() {
        KurtisArray.removeAll()
        myArray.removeAll()
        myArray.insert(pointEntrance, at: 0)
        print("kurtis array has :\(KurtisArray.count)")
        print("my array has :\(myArray.count)")
    }
    // resets all nodes
    func resetAllNodes() {
        nodes = []
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        self.setNeedsDisplay()
    }
    // resets ony the nodes in your path
    func resetNodes() {
        var tempNodes = nodes
        nodes = []
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        for i in 0..<tempNodes.count {
            for j in 0..<tempNodes[i].count {
                if tempNodes[i][j].type == .Obstacle {
                    nodes[i][j].type = .Obstacle
                }
            }
        }
        self.setNeedsDisplay()
    }
    // once you reach you goal in a_star function, comes here at reconstructs path you took
    func reconstructPath(current: Node)-> [Node] {
        var totalPath: [Node] = [current]
        while let par = totalPath.first!.from {
            totalPath.insert(par, at: 0)
            par.type = .Path
        }
        return totalPath
    }
    // looks at all the f scores and returns the node with the lowest f score
    func lowestFScore()-> Node {
        var finalNode: Node = Node()
        finalNode.g = INFINITE
        finalNode.h = INFINITE
        for i in nodes {
            for j in i {
                if j.f <= finalNode.f && j.g != -100 {
                    finalNode = j
                }
            }
        }
        return finalNode
    }
    var KurtisArray: [Int] = []
    func listTypes() {
        //    myArray.removeAll()
        //    KurtisArray.removeAll()
        // myArray.append(pointEntrance)
        for item in list {
            print("the item in the list is: \(item.name)")
            KurtisArray.removeAll()
            if item.location.1 == .Produce {
                KurtisArray.append(0)
            }
            if item.aisle.1 == .bakery{
                KurtisArray.append(1)
            }
            if item.location.1 == .Meat{
                KurtisArray.append(2)
            }
            if item.aisle.1 == .one{
                KurtisArray.append(3)
            }
            if item.aisle.1 == .two{
                KurtisArray.append(4)
            }
            if item.aisle.1 == .three{
                KurtisArray.append(5)
            }
            if item.aisle.1 == .four{
                KurtisArray.append(6)
            }
            if item.aisle.1 == .five{
                KurtisArray.append(7)
            }
            if item.aisle.1 == .six{
                KurtisArray.append(8)
            }
            if item.aisle.1 == .seven{
                KurtisArray.append(9)
            }
            if item.aisle.1 == .eight{
                KurtisArray.append(10)
            }
            if item.aisle.1 == .frznFood{
                KurtisArray.append(11)
            }
            if item.aisle.1 == .frznSweets{
                KurtisArray.append(12)
            }
            /*
            if item.aisle.1 == .seafood{
                KurtisArray.append(13)
            }*/
            if item.location.1 == .Dairy{
                KurtisArray.append(14)
            }
        }
        KurtisArray.sort()
        print("kirtis array: \(KurtisArray)")
        if KurtisArray.contains(0){
            myArray.append(pointProd)
            print("\(pointProd) was appended")
        }
        if KurtisArray.contains(1){
            myArray.append(pointBak)
            print("\(pointBak) was appended")
        }
        if KurtisArray.contains(2){
            myArray.append(pointMeat)
            print("\(pointMeat) was appended")
        }
        if KurtisArray.contains(3){
            myArray.append(pointPharm)
            print("\(pointPharm) was appended")
        }
        if KurtisArray.contains(4){
            myArray.append(point2)
            print("\(point2) was appended")
        }
        if KurtisArray.contains(5){
            myArray.append(point3)
            print("\(point3) was appended")
        }
        if KurtisArray.contains(6){
            myArray.append(point4)
            print("\(point4) was appended")
        }
        if KurtisArray.contains(7){
            myArray.append(point5)
            print("\(point5) was appended")
        }
        if KurtisArray.contains(8){
            myArray.append(point6)
            print("\(point6) was appended")
        }
        if KurtisArray.contains(9){
            myArray.append(point7)
            print("\(point7) was appended")
        }
        if KurtisArray.contains(10){
            myArray.append(point8)
            print("\(point8) was appended")
        }
        if KurtisArray.contains(11){
            myArray.append(pointFrozenFood)
            print("\(pointFrozenFood) was appended")
        }
        if KurtisArray.contains(12){
            myArray.append(pointFrozSweets)
            print("\(pointFrozSweets) was appended")
        }
        if KurtisArray.contains(13){
            myArray.append(pointSeaf)
            print("\(pointSeaf) was appended")
        }
        if KurtisArray.contains(14){
            myArray.append(pointDairy)
            print("\(pointDairy) was appended")
        }
    }
}
