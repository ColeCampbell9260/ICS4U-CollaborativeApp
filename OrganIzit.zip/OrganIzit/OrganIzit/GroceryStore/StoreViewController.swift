//
//  MapViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-20.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit


class StoreViewController: UIViewController {
 
    @IBOutlet weak var TextLabel: UILabel!
    @IBOutlet weak var Logo: UIImageView!
    
    override func viewDidLoad() {
     
        let shape2 = ShapeView2(frame: CGRect(x: 0, y: screenSize.height - 200, width: screenSize.width, height: 200))
        self.view.addSubview(shape2)

        let shape = ShapeView(frame: CGRect(x: 150, y: 64, width: screenSize.width/1.5, height: screenSize.height))
        self.view.addSubview(shape)
        
        if currentStore == "Basics" {
            Logo.image = UIImage(imageLiteralResourceName: "FB_logo.jpg")
            TextLabel.text = "Food Basics \n\nHours:\nMonday(9am-9pm), Tuesday(9am-9pm), Wednesday(9am-9pm), Thursday(9am-9pm), Friday(9am-9pm), Saturday(8am-8pm), Friday(9am-8pm)"
        } else if currentStore == "Land" {
            Logo.image = UIImage(imageLiteralResourceName: "FL_logo")
             TextLabel.text = "Foodland \n\nHours:\nMonday(9am-9pm), Tuesday(9am-9pm), Wednesday(9am-9pm), Thursday(9am-9pm), Friday(9am-9pm), Saturday(8am-8pm), Friday(9am-8pm)"
        } else if currentStore == "Shoppers"{
            Logo.image = UIImage(imageLiteralResourceName: "SDM_logo.jpg")
            TextLabel.text = "Shopper's Drugmart \n\nHours:\nMonday(9am-9pm), Tuesday(9am-9pm), Wednesday(9am-9pm), Thursday(9am-9pm), Friday(9am-9pm), Saturday(8am-8pm), Friday(9am-8pm)"
        }
        
    
        super.viewDidLoad()
    }
}


class ShapeView : UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clear
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        backgroundColor = UIColor.clear
    }
    
    override func draw(_ rect: CGRect) {
        let size = self.bounds.size
        
        // calculate the 5 points of the pentagon
        let p1 = self.bounds.origin
        let p2 = CGPoint(x:p1.x + size.width, y:p1.y)
        let p3 = CGPoint(x:p2.x, y:p2.y + size.height)
        let p4 = CGPoint(x:p1.x, y:p1.y + size.height)
        let p5 = CGPoint(x:p1.x+size.width/3, y:p1.y + size.height/2)

        
        // create the path
        let path = UIBezierPath()
        path.move(to: p1)
        path.addLine(to: p2)
        path.addLine(to: p3)
        path.addLine(to: p4)
        path.addLine(to: p5)

        path.close()
       // path.stroke()
        var colour = UIColor.black

        if currentStore == "Basics" {
            colour = UIColor.init(red: 0.07, green: 0.99, blue: 0.2, alpha: 1)
        } else if currentStore == "Land" {
            colour = UIColor.red
        } else if currentStore == "Shoppers"{
            colour = UIColor.init(red: 0.3, green: 0.87, blue: 0.97, alpha: 1)
        } else {
            colour = UIColor.black
            
        }
        
        colour.setFill()
        UIColor.black.setStroke()
        path.stroke()
        // fill the path
        path.fill()
    }
}



class ShapeView2 : UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clear
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        backgroundColor = UIColor.clear
    }
    
    override func draw(_ rect: CGRect) {
        let size = self.bounds.size
        
        // calculate the 5 points of the pentagon
        let p1 = self.bounds.origin
        let p2 = CGPoint(x:p1.x + size.width, y:p1.y)
        let p3 = CGPoint(x:p2.x, y:p2.y + size.height)
        let p4 = CGPoint(x:p1.x, y:p1.y + size.height)
        
        // create the path
        let path = UIBezierPath()
        path.move(to: p1)
        path.addLine(to: p2)
        path.addLine(to: p3)
        path.addLine(to: p4)
        
        path.close()
        // path.stroke()
        var colour = UIColor.black
        
        if currentStore == "Basics" {
            colour = UIColor.init(red: 1, green: 0.9, blue: 0, alpha: 1)
        } else if currentStore == "Land" {
            colour = UIColor.gray
        } else if currentStore == "Shoppers"{
            colour = UIColor.red
        } else {
            colour = UIColor.black
            
        }
        
        colour.setFill()
        UIColor.black.setStroke()
        path.stroke()
        // fill the path
        path.fill()
    }
}
