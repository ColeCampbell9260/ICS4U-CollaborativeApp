//
//  ICS4U Collaborative App
//  OrganIzit
//

import UIKit

let defaults = UserDefaults.standard

class LandingPageViewController: UIViewController {

    var profiles : [Profile] = []
    
    var currentProfile : Int?
    
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var profilePictureView: UIImageView!
    @IBOutlet weak var createProfileButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var editProfileButton: UIButton!
    
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func loginPressed(_ sender: UIButton) {
        if sender.title(for: .normal) == "Log Out" {
            sender.setTitle("Log In", for: .normal)
            currentProfile = -1
            
            welcomeLabel.text = ""
            profilePictureView.image = UIImage(imageLiteralResourceName: "Default")
            
            if editProfileButton.isEnabled {
                editProfileButton.isEnabled = false
            }
            
        } else {
            performSegue(withIdentifier: "Login", sender: loginButton)
        }
    }
    
    @IBAction func createProfilePressed(_ sender: Any) {
        print(profiles.count)
        performSegue(withIdentifier: "Profile", sender: createProfileButton)
    }
    
    @IBAction func editProfilePressed(_ sender: Any) {
        performSegue(withIdentifier: "Profile", sender: editProfileButton)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let sender = sender as? UIButton else {return}
        
        switch(sender) {
        case createProfileButton:
            let profileVC = segue.destination as! ProfileViewController
            segue.destination.navigationItem.title = "Create New Profile"
            profileVC.interfaceIndex = 1
            profileVC.profiles = profiles
            break
        case editProfileButton:
            let profileVC = segue.destination as! ProfileViewController
            segue.destination.navigationItem.title = "Edit Existing Profile"
            profileVC.interfaceIndex = 2
            profileVC.profiles = profiles
            profileVC.currentProfile = currentProfile
            break
        case loginButton:
            let loginVC = segue.destination as! LoginViewController
            loginVC.profiles = profiles
            break
        default:
            break
        }
    }
    
    @IBAction func openCalendar(_ sender: Any) {
        openURL(url: "https://calendar.woolwich.ca")
    }
    
    @IBAction func openWeather(_ sender: Any) {
        openURL(url: "https://weather.com")
    }
    
    @IBAction func unwindBack(segue: UIStoryboardSegue) { }
    
}

