//
//  LoginViewController.swift
//  OrganIzit
//
//  Created by Cole Campbell on 2018-12-13.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    var profiles : [Profile] = []

    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var warningLabel: UILabel!
    
    let incorrectLogin = "Username or Password Incorrect"
    
    var testIndex = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func loginPressed(_ sender: Any) {
        let loginProfile = Profile(username: usernameField.text!, password: passwordField.text, profilePicture: nil)
        for profile in profiles {
            testIndex = profiles.firstIndex(of: profile)!
            if profile == loginProfile && profile.password == loginProfile.password {
                performSegue(withIdentifier: "unwindBack", sender: sender)
                return
            }
        }
        warningLabel.text = incorrectLogin
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard testIndex >= 0 else { return }
        
        let landingPage = segue.destination as! LandingPageViewController
        let profile = profiles[testIndex]
        
        landingPage.welcomeLabel.text = "Welcome \(profile.username)!"
        landingPage.profilePictureView.image = profile.profilePicture
    }
    
}
