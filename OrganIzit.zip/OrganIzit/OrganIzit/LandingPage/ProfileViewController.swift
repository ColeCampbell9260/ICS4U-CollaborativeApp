//
//  ProfileViewController.swift
//  OrganIzit
//
//  Created by Cole Campbell on 2018-12-04.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    
    var pic : UIImage?
    var interfaceIndex = 0
    
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    @IBOutlet weak var usernameSplashLabel: UILabel!
    @IBOutlet weak var passwordSplashLabel: UILabel!
    
    @IBOutlet weak var usernameLabel: UILabel!
    
    let usernameCreateSplash = "Create Your Username:"
    let usernameEditSplash = "Edit Your Username:"
    let passwordCreateSplash = "Create A Password (Optional):"
    let passwordEditSplash = "Edit Your Password:"
    let usernameWarning = "Please Enter a Username!"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if interfaceIndex == 1 {
            usernameSplashLabel.text = usernameCreateSplash
            passwordSplashLabel.text = passwordCreateSplash
        } else if interfaceIndex == 2 {
            usernameSplashLabel.text = usernameEditSplash
            passwordSplashLabel.text = passwordEditSplash
        }
    }
    
    @IBAction func finishProfile(_ sender: Any) {
        guard usernameField.text!.count > 0 else {
            usernameLabel.text = usernameWarning
            return
        }
        performSegue(withIdentifier: "unwindBack", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if interfaceIndex == 1 {
            createProfile(segue: segue)
        } else if interfaceIndex == 2 {
            editProfile()
        }
    }
    
    func createProfile(segue: UIStoryboardSegue) {
        let username = usernameField.text!
        let password = passwordField.text
        
        let profile = Profile(username: username, password: password, profilePicture: pic)
        
        let landingPage = segue.destination as! LandingPageViewController
        landingPage.profiles.append(profile)
        if !landingPage.editProfileButton.isEnabled {
            landingPage.editProfileButton.isEnabled = true
        }
    }
    
    func editProfile() {
        
    }

}
