//
//  CheckList.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-05.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class CheckList: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var checkListNavBar: UINavigationBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        checkListNavBar.topItem?.title = listTitle
        // Do any additional setup after loading the view.
    }
    
    var array = ["Matt", "Dunn", "Bagel"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let itemsOnList = tableView.dequeueReusableCell(withIdentifier: "itemsOnList", for: indexPath) as! UsersCheckListTableViewCell
        
        itemsOnList.itemsOnUsersList?.text = array[indexPath.row]
        
        return itemsOnList
    }
    
    
    @IBAction func onPlusTapped() {
        let alert  = UIAlertController(title: "Add Item", message: nil, preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "New Item"
        }
        
        let action = UIAlertAction(title: "Add Item", style: .default, handler: {_ in
        })
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: {_ in
        })
        
        alert.addAction(cancel)
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) {
            if cell.accessoryType == .none {
                cell.accessoryType = .checkmark
            } else if cell.accessoryType == .checkmark {
                cell.accessoryType = .none
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
