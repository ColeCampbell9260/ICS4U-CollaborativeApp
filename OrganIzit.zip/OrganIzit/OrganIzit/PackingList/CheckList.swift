//
//  CheckList.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-05.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

var isChecked = [Bool]()

class CheckList: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var checkListNavBar: UINavigationBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        checkListNavBar.topItem?.title = listTitle
        // Do any additional setup after loading the view.
    }
    
    var onlyAddItemsOnce : Bool = false
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        while onlyAddItemsOnce == false {
        
        if lacrosse.doesUserWantOnThereList == true {
            userList.itemsOnList += lacrosse.whatUserWillAddToList
            print("I added to the list")
        }
        
        if soccer.doesUserWantOnThereList == true {
            userList.itemsOnList += soccer.whatUserWillAddToList
        }
        
        if rugby.doesUserWantOnThereList == true {
            userList.itemsOnList += rugby.whatUserWillAddToList
        }
        
        if baseball.doesUserWantOnThereList == true {
            userList.itemsOnList += baseball.whatUserWillAddToList
        }
        
        if swimming.doesUserWantOnThereList == true {
            userList.itemsOnList += swimming.whatUserWillAddToList
        }
        
        if football.doesUserWantOnThereList == true {
            userList.itemsOnList += football.whatUserWillAddToList
        }
        
        if fieldHockey.doesUserWantOnThereList == true {
            userList.itemsOnList += fieldHockey.whatUserWillAddToList
        }
        
        if tennis.doesUserWantOnThereList == true {
            userList.itemsOnList += tennis.whatUserWillAddToList
        }
        
        if bobsleigh.doesUserWantOnThereList == true {
            userList.itemsOnList += bobsleigh.whatUserWillAddToList
        }
        
        if hockey.doesUserWantOnThereList == true {
            userList.itemsOnList += hockey.whatUserWillAddToList
        }
        
        if skiing.doesUserWantOnThereList == true {
            userList.itemsOnList += skiing.whatUserWillAddToList
        }
        
        if ringette.doesUserWantOnThereList == true {
            userList.itemsOnList += ringette.whatUserWillAddToList
        }
        
        if speedSkating.doesUserWantOnThereList == true {
            userList.itemsOnList += speedSkating.whatUserWillAddToList
        }
        
        if snowboarding.doesUserWantOnThereList == true {
            userList.itemsOnList += snowboarding.whatUserWillAddToList
        }
        
        if luge.doesUserWantOnThereList == true {
            userList.itemsOnList += luge.whatUserWillAddToList
        }
        
        if curling.doesUserWantOnThereList == true {
            userList.itemsOnList += curling.whatUserWillAddToList
        }
        
        if hot.doesUserWantOnThereList == true {
            userList.itemsOnList += hot.whatUserWillAddToList
        }
        
        if cold.doesUserWantOnThereList == true {
            userList.itemsOnList += cold.whatUserWillAddToList
        }
        
        if overnight.doesUserWantOnThereList == true {
            userList.itemsOnList += overnight.whatUserWillAddToList
        }
        
        if plane.doesUserWantOnThereList == true {
            userList.itemsOnList += plane.whatUserWillAddToList
        }
        
        if outOfCountry.doesUserWantOnThereList == true {
            userList.itemsOnList += outOfCountry.whatUserWillAddToList
        }
        
        if car.doesUserWantOnThereList == true {
            userList.itemsOnList += car.whatUserWillAddToList
        }
            
            // Need to make it a double array of dictionaries and then maybe I can make it work hopefully I think probably but not sure because doubtful
            
            // Fixes doubles I think
            /*
            var numberOfItemsThatHaveBeenRemoved : Int = 0
            var numberOfTimesThroughTheArray : Int = 0
            
            if userList.itemsOnList.count - 1 > 0 {
                for index in 0 ... userList.itemsOnList.count - 1 {
                    for value in numberOfTimesThroughTheArray ... userList.itemsOnList.count - 1 {
                        if (userList.itemsOnList[index - numberOfItemsThatHaveBeenRemoved] == userList.itemsOnList[value - numberOfItemsThatHaveBeenRemoved]) && index != value {
                            userList.itemsOnList.remove(at: value - numberOfItemsThatHaveBeenRemoved)
                            numberOfItemsThatHaveBeenRemoved += 1
                        }
                    }
                    
                    if (numberOfTimesThroughTheArray + 1) != (userList.itemsOnList.count - 1) {
                        numberOfTimesThroughTheArray += 1
                    }
                    
                }
                
                numberOfItemsThatHaveBeenRemoved = 0
                numberOfTimesThroughTheArray = 0
                /*
                 print(userList.itemsOnList)
                 
                 for clip in 0 ... userList.itemsOnList.count - 1 {
                 print(userList.itemsOnList[clip])
                 itemsOnLists[userList.positionInArrays] = [userList.itemsOnList[clip] : false]
                 }
                 
                 print(itemsOnLists)
                 
             
                 */
            }
         */
            print("Hello")
            print(userList.itemsOnList)
            onlyAddItemsOnce = true
            
        }
        
        return userList.itemsOnList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let itemsOnList = tableView.dequeueReusableCell(withIdentifier: "itemsOnList", for: indexPath) as! UsersCheckListTableViewCell
        
        itemsOnList.itemsOnUsersList?.text = userList.itemsOnList[indexPath.row]
        
        isChecked.append(false)
        
        if(isChecked[indexPath.row]) {
            itemsOnList.accessoryType = .checkmark
        } else {
            itemsOnList.accessoryType = .none
        }
        print(userList.itemsOnList)
        print("Hi")
        return itemsOnList
    }
    
    
    @IBAction func onPlusTapped() {
        let alert  = UIAlertController(title: "Add Item", message: nil, preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "New Item"
        }
        
        let action = UIAlertAction(title: "Add Item", style: .default, handler: {_ in
        })
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: {_ in
        })
        
        alert.addAction(cancel)
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) {
            if cell.accessoryType == .none {
                cell.accessoryType = .checkmark
                isChecked[indexPath.row] = true
            } else if cell.accessoryType == .checkmark {
                cell.accessoryType = .none
                isChecked[indexPath.row] = false
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
