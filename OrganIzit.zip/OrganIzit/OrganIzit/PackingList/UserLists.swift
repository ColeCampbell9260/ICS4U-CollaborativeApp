//
//  UserListsViewController.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-05.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

var listTitle = ""

class UserLists: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func onPlusTapped() {
        let alert  = UIAlertController(title: "New List", message: nil, preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "List Title"
        }
        
        let action = UIAlertAction(title: "Start Creating", style: .default, handler: {_ in
            CATransaction.setCompletionBlock({
                if alert.textFields![0].text ?? "" == "" {
                    listTitle = "New List"
                } else {
                    listTitle = alert.textFields![0].text ?? ""
                }
                self.performSegue(withIdentifier: "Segue", sender: nil)
            })
        })
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: {_ in
        })
        
        alert.addAction(cancel)
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)
    }
    
    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
