//
//  mainVC.swift
//  OrganIzit
//
//  Created by Julia Baxter on 2018-11-29.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//




//Both storyboards were made by Nate

import UIKit
import EventKit

class mainVC: UIViewController {

    let eventStore = EKEventStore()
    var calendarHasBeenCreated = (UserDefaults.standard.object(forKey: "Key") != nil)
    
    
    @IBOutlet weak var triangleButton: UIButton!
    
    
    @IBOutlet weak var pcOptimumButton: UIButton!
    
    @IBOutlet weak var airMilesButton: UIButton!
    
    //the following selects what screen will be loaded in the second screen - Nate
    
    @IBAction func airMilesButtonPressed(_ sender: Any) {
        selectedScreen = 2
    }
    
    @IBAction func triangleButtonPressed(_ sender: Any) {
        selectedScreen = 1
    }
    @IBAction func pcOptimumButtonPressed(_ sender: Any) {
        selectedScreen = 3
        
    }
    // Opens the calendar - Nate
    @IBAction func goToCalendar(_ sender: Any) {
        let url = URL(string:"calshow://")!
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
    
    var calendars: [EKCalendar]?

    
    
    override func viewDidLoad() {
        //The following sets borders for the buttons on the main screen, made by Nate 
        triangleButton.layer.borderColor = UIColor.gray.cgColor
        triangleButton.layer.borderWidth = 2
        triangleButton.layer.cornerRadius = 7
        
        pcOptimumButton.layer.borderColor = UIColor.gray.cgColor
        pcOptimumButton.layer.borderWidth = 2
        pcOptimumButton.layer.cornerRadius = 7
        
        airMilesButton.layer.borderColor = UIColor.gray.cgColor
        airMilesButton.layer.borderWidth = 2
        airMilesButton.layer.cornerRadius = 7
        
        loadCalendars()

        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        checkCalendarAuthorizationStatus()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func checkCalendarAuthorizationStatus() { // Tyler - Checks if the user has enabled access to their phones calendar app
        let status = EKEventStore.authorizationStatus(for: EKEntityType.event)
        
        switch (status) {
        case EKAuthorizationStatus.notDetermined:
            
            requestAccessToCalendar()
            
        case EKAuthorizationStatus.authorized:
            
            loadCalendars()
            if calendarHasBeenCreated != true {
                createCalendar()
            }
            
        case EKAuthorizationStatus.restricted, EKAuthorizationStatus.denied:
            
            requestAccessToCalendar()
            
        }
        
    }

    func requestAccessToCalendar() { // Tyler - asks for permission to access the calendar app
        
        eventStore.requestAccess(to: EKEntityType.event, completion: {
            (accessGranted: Bool, error: Error?) in
            
            if accessGranted == true {
                DispatchQueue.main.async(execute: {
                    self.loadCalendars()
                })
            }
        })
    }
    
    func loadCalendars() {
       // _ = eventStore.calendars(for: EKEntityType.event)
        self.calendars = EKEventStore().calendars(for: EKEntityType.event).sorted() {
            (cal1, cal2) -> Bool in
            return cal1.title < cal2.title
        }
        
    }

    func createCalendar() { // Tyler - Creates a new calendar titled "points"
        
        do {
            let calender = EKCalendar(for: .event, eventStore: eventStore)
            calender.title = "Points"
            let sourcesInEventStore = eventStore.sources
            let filteredEventStores = sourcesInEventStore.filter {
                (source: EKSource) -> Bool in source.sourceType.rawValue == EKSourceType.local.rawValue
            }
            if filteredEventStores.count > 0 {
                calender.source = filteredEventStores.first!
            } else {
                 calender.source = sourcesInEventStore.filter {
                    (source: EKSource) -> Bool in source.sourceType.rawValue == EKSourceType.subscribed.rawValue
                    }.first //this used to be first? but error arose and removed question mark
            }
            try eventStore.saveCalendar(calender, commit: true)
            
            print("Calendar was successfully created")
            calendarHasBeenCreated = true
            UserDefaults.standard.set(true, forKey: "Key")
            
        } catch {
            
            print("Error occured while creating calendar")
            UserDefaults.standard.set(false, forKey: "Key")
            
        }
    }



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
