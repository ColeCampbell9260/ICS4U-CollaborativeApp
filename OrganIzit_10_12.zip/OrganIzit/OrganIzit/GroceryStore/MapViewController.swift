//
//  MapViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

class MapViewController: UIViewController {
    var myTitle: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "produceToPopUp"){
            myTitle = "Produce"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Produce
        } else if(segue.identifier == "bakeryToPopUp"){
            myTitle = "Bakery"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Grocery
            currentAisle = .bakery
        } else if(segue.identifier == "fancyMeatToPopUp"){
            myTitle = "Meat"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Meat
        } else if(segue.identifier == "dairyToPopUp"){
            myTitle = "Dairy"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Dairy
        } else if(segue.identifier == "seafoodToPopUp"){
            myTitle = "Seafood"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Meat
        } else if(segue.identifier == "frozenFoodToPopUp"){
            myTitle = "Frozen Food"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Grocery
            currentAisle = .frznFood
        } else if(segue.identifier == "frozenSweetsToPopUp"){
            myTitle = "Frozen Sweets"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Grocery
            currentAisle = .frznSweets
        } else if(segue.identifier == "meatToPopUp"){
            myTitle = "Meat"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Meat
        } else if(segue.identifier == "pharmToPopUp"){
            myTitle = "Pharmaceuticals"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Grocery
            currentAisle = .HABA
        } else if(segue.identifier == "aisleTwoToPopUp"){
            myTitle = "Aisle 2"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Grocery
            currentAisle = .two
        } else if(segue.identifier == "aisleThreeToPopUp"){
            myTitle = "Aisle Three"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Grocery
            currentAisle = .three
        } else if(segue.identifier == "aisleFourToPopUp"){
            myTitle = "Aisle Four"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Grocery
            currentAisle = .four
        } else if(segue.identifier == "aisleFiveToPopUp"){
            myTitle = "Aisle Five"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Grocery
            currentAisle = .five
        } else if(segue.identifier == "aisleSixToPopUp"){
            myTitle = "Aisle Six"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Grocery
            currentAisle = .six
        } else if(segue.identifier == "aisleSevenToPopUp"){
            myTitle = "Aisle Seven"
            currentDept = .Grocery
            currentAisle = .seven
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
        } else if(segue.identifier == "aisleEightToPopUp"){
            myTitle = "Aisle Eight"
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
            currentDept = .Grocery
            currentAisle = .eight
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
