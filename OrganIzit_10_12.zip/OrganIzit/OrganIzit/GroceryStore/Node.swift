//
//  Node.swift
//  testingSegues
//
//  Created by Lizzy on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

class Node: NSObject {
    private var realType: BlockType = .Air
    var x: Int = 0
    var y: Int = 0
    var g: Int = -100
    var h: Int = -100
    var f: Int {
        get {
            return g+h
        }
    }
    var from: Node!
    var colour: UIColor {
        get {
            if self.type == .Air {
                return UIColor.white
            } else if self.type == .Obstacle {
                return UIColor.black
            } else if self.type == .pointA {
                return UIColor.red
            } else if self.type == .pointB {
                return UIColor.green
            } else if self.type == .Path {
                return UIColor.red
            } else if self.type == .ExploredPath {
                return UIColor.cyan
            }
            return UIColor.black
        }
    }
    
    var type: BlockType {
        get {
            return realType
        }
        set {
            realType = newValue
        }
    }
}
