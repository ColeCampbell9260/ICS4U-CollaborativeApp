//
//  mainVC.swift
//  OrganIzit
//
//  Created by Julia Baxter on 2018-11-29.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit
import EventKit

class mainVC: UIViewController {

    let eventStore = EKEventStore()
    var calendarHasBeenCreated = (UserDefaults.standard.object(forKey: "Key") != nil)
    @IBAction func airMilesButtonPressed(_ sender: Any) {
        
    }
    
    @IBOutlet weak var backButtonMain: UIBarButtonItem!
    
    @IBOutlet weak var TriangleButton: UIButton!
    
    
    @IBOutlet weak var PCOptimumButton: UIButton!
    
    @IBOutlet weak var AirMilesButton: UIButton!
    
    @IBAction func unwindToVC1(segue:UIStoryboardSegue) { }
    
    @IBAction func goBackToVC1(_ sender: Any) {
        performSegue(withIdentifier: "unwindSegueToVC1", sender: self)
    }
    
    var calendars: [EKCalendar]?

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadCalendars()
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        checkCalendarAuthorizationStatus()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func checkCalendarAuthorizationStatus() {
        let status = EKEventStore.authorizationStatus(for: EKEntityType.event)
        
        switch (status) {
        case EKAuthorizationStatus.notDetermined:
            
            requestAccessToCalendar()
            
        case EKAuthorizationStatus.authorized:
            
            loadCalendars()
            if calendarHasBeenCreated != true {
                createCalendar()
            }
            
        case EKAuthorizationStatus.restricted, EKAuthorizationStatus.denied:
            
            requestAccessToCalendar()
            
        }
        
    }

    func requestAccessToCalendar() {
        
        eventStore.requestAccess(to: EKEntityType.event, completion: {
            (accessGranted: Bool, error: Error?) in
            
            if accessGranted == true {
                DispatchQueue.main.async(execute: {
                    self.loadCalendars()
                })
            } else {
                
            }
        })
    }
    
    func loadCalendars() {
        _ = eventStore.calendars(for: EKEntityType.event)
        self.calendars = EKEventStore().calendars(for: EKEntityType.event).sorted() {
            (cal1, cal2) -> Bool in
            return cal1.title < cal2.title
        }
        
    }

    func createCalendar() {
        
        do {
            let calender = EKCalendar(for: .event, eventStore: eventStore)
            calender.title = "Points"
            let sourcesInEventStore = eventStore.sources
            let filteredEventStores = sourcesInEventStore.filter {
                (source: EKSource) -> Bool in source.sourceType.rawValue == EKSourceType.local.rawValue
            }
            if filteredEventStores.count > 0 {
                calender.source = filteredEventStores.first!
            } else {
                calender.source = sourcesInEventStore.filter {
                    (source: EKSource) -> Bool in source.sourceType.rawValue == EKSourceType.subscribed.rawValue
                    }.first!
            }
            try eventStore.saveCalendar(calender, commit: true)
            
            print("Calendar was successfully created")
            calendarHasBeenCreated = true
            UserDefaults.standard.set(true, forKey: "Key")
            
        } catch {
            
            print("Error occured while creating calendar")
            UserDefaults.standard.set(false, forKey: "Key")
            
        }
    }



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
