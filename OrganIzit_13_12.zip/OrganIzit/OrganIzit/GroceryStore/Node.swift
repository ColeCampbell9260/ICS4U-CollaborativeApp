//
//  Node.swift
//  testingSegues
//
//  Created by Lizzy on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

class Node: NSObject {
    private var realType: BlockType = .Air
    var x: Int = 0
    var y: Int = 0
    var g: Int = -100
    var h: Int = -100
    var f: Int {
        get {
            return g+h
        }
    }
    var from: Node!
    var colour: UIColor {
        get {
            if self.type == .Air {
                return UIColor.white
            } else if self.type == .Obstacle {
                return UIColor.clear
            } else if self.type == .pointA {
                return UIColor.red
            } else if self.type == .pointB {
                return UIColor.green
            } else if self.type == .Path {
                return UIColor.red
            } else if self.type == .ExploredPath {
                return UIColor.clear
            } else if self.type == .pointProd {
                return UIColor.orange
            }else if self.type == .pointBak {
                return UIColor.orange
            }else if self.type == .pointFancMeat {
                return UIColor.orange
            }else if self.type == .pointDairy {
                return UIColor.orange
            }else if self.type == .pointSeaf {
                return UIColor.orange
            }else if self.type == .pointFrozFood {
                return UIColor.orange
            }else if self.type == .pointFrozSweet {
                return UIColor.orange
            }else if self.type == .pointMeat {
                return UIColor.orange
            }else if self.type == .pointPharm {
                return UIColor.orange
            }else if self.type == .point2 {
                return UIColor.orange
            }else if self.type == .point3 {
                return UIColor.orange
            }else if self.type == .point4 {
                return UIColor.orange
            }else if self.type == .point4 {
                return UIColor.orange
            }else if self.type == .point5 {
                return UIColor.orange
            }else if self.type == .point6 {
                return UIColor.orange
            }else if self.type == .point7 {
                return UIColor.orange
            }else if self.type == .point8 {
                return UIColor.orange
            }
            return UIColor.black
        }
    }
    
    var type: BlockType {
        get {
            return realType
        }
        set {
            realType = newValue
        }
    }
}
