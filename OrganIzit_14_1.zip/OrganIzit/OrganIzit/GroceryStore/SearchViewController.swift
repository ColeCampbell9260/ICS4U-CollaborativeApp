//
//  SearchViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-29.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit
//global variable for searching
var filteredItems = [Item]()
//global variable for the created item
var newItemName = ""
class SearchViewController: UITableViewController, UISearchResultsUpdating{
    
    let cellID = "ItemCell"
    let addCellID = "addItemCell"
    let searchController = UISearchController(searchResultsController: nil)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(ItemLayoutCell.self, forCellReuseIdentifier: cellID)
        tableView.register(AddItemCell.self, forCellReuseIdentifier: addCellID)
        //update table view
        self.tableView.reloadData()
        
        //setup search controller
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        
        //reset filtered list
        filteredItems = allItems
    }
    //searching
    var itemsFound = true
    func updateSearchResults(for searchController: UISearchController) {
        //currently not searching
        if searchController.searchBar.text! == ""{
            itemsFound = true
            filteredItems = allItems
            
        }
            //currently searching
        else{
            itemsFound = true
            filteredItems = allItems.filter( { $0.name.lowercased().contains(searchController.searchBar.text!.lowercased()) } )
            if filteredItems.count == 0{
                //add new item
                itemsFound = false
                filteredItems = addItem
            }
        }
        self.tableView.reloadData()
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return filteredItems.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        if itemsFound == true{
            //normal item cells
            let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as! ItemLayoutCell
            let item = filteredItems[indexPath.row]
            cell.item = item
            return cell
        }
        else{
            //add a new item cell
            let cell = tableView.dequeueReusableCell(withIdentifier: addCellID, for: indexPath) as! AddItemCell
            let item = filteredItems[indexPath.row]
            cell.item = item
            return cell
        }
        
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if itemsFound == false{
            print("Show alert")
            
            //displays alert when add a new item is clicked
            let customAlert = self.storyboard?.instantiateViewController(withIdentifier: "CustomAlert") as! CustomAlertView
            newItemName = searchController.searchBar.text!
            self.searchController.dismiss(animated: true, completion: nil)
            customAlert.providesPresentationContextTransitionStyle = true
            customAlert.definesPresentationContext = true
            customAlert.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
            customAlert.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
            customAlert.delegate = self
            self.present(customAlert, animated: true, completion: nil)
        }
        else{
            return
        }
    }
}
extension SearchViewController: CustomAlertViewDelegate {
    
    func doneButtonTapped(selectedDpt: Department, itemName: String) {
        let addedItem = Item(name: itemName, location: (selectedDpt, selectedDpt, selectedDpt), quantity: 1)
        allItems.append(addedItem)
        list.append(addedItem)
        }
    func cancelButtonTapped() {
    }
}



