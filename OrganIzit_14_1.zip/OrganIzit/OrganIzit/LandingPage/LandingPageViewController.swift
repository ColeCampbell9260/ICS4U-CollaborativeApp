//
//  ICS4U Collaborative App
//  OrganIzit
//

import UIKit

class LandingPageViewController: UIViewController {
    
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var profilePictureView: UIImageView!
    @IBOutlet weak var createProfileButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var editProfileButton: UIButton!
    
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profileUsernames = defaults.object(forKey: "Usernames") as? [String] ?? []
        profilePasswords = defaults.object(forKey: "Passwords") as? [String] ?? []
        profilePictures = defaults.object(forKey: "Images") as? [Int] ?? []
        
        guard profileUsernames.count == profilePasswords.count && profilePasswords.count == profilePasswords.count else {return}
        for index in 0..<profileUsernames.count {
            profiles.append(Profile(username: profileUsernames[index], password: profilePasswords[index], profilePicture: getProfilePictureFromIndex(index: profilePictures[index])))
        }
        
        if profiles.count > 0 {
            loginButton.isEnabled = true
        }
    }
    
    @IBAction func loginPressed(_ sender: UIButton) {
        if sender.title(for: .normal) == "Log Out" {
            sender.setTitle("Log In", for: .normal)
            currentProfile = -1
            
            welcomeLabel.text = ""
            profilePictureView.image = defaultPicture
            
            if editProfileButton.isEnabled {
                editProfileButton.isEnabled = false
            }
            
        } else {
            performSegue(withIdentifier: "Login", sender: loginButton)
        }
    }
    
    @IBAction func createProfilePressed(_ sender: Any) {
        performSegue(withIdentifier: "Profile", sender: createProfileButton)
    }
    
    @IBAction func editProfilePressed(_ sender: Any) {
        performSegue(withIdentifier: "Profile", sender: editProfileButton)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let sender = sender as? UIButton else {return}
        
        switch(sender) {
        case createProfileButton:
            let profileVC = segue.destination as! ProfileViewController
            segue.destination.navigationItem.title = "Create New Profile"
            profileVC.interfaceIndex = 1
            break
        case editProfileButton:
            let profileVC = segue.destination as! ProfileViewController
            segue.destination.navigationItem.title = "Edit Existing Profile"
            profileVC.interfaceIndex = 2
            break
        default:
            break
        }
    }
    
    @IBAction func openCalendar(_ sender: Any) {
        openURL(url: "https://calendar.woolwich.ca")
    }
    
    @IBAction func openWeather(_ sender: Any) {
        openURL(url: "https://weather.com")
    }
    
    @IBAction func unwindBack(segue: UIStoryboardSegue) { }
    
}

