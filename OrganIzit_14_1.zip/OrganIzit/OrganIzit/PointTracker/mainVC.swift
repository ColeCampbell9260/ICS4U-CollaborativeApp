//
//  mainVC.swift
//  OrganIzit
//
//  Created by Julia Baxter on 2018-11-29.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit
import EventKit

class mainVC: UIViewController {

    let eventStore = EKEventStore()//All calendar stuff is tyler's
    var calendarHasBeenCreated = (UserDefaults.standard.object(forKey: "Key") != nil)
    
    
    @IBOutlet weak var triangleButton: UIButton!
    
    
    @IBOutlet weak var pcOptimumButton: UIButton!
    
    @IBOutlet weak var airMilesButton: UIButton!
    
    @IBAction func airMilesButtonPressed(_ sender: Any) {//Selected Screen was set up by me
        selectedScreen = 2
    }
    
    @IBAction func triangleButtonPressed(_ sender: Any) {
        selectedScreen = 1
    }
    @IBAction func pcOptimumButtonPressed(_ sender: Any) {
        selectedScreen = 3
        
    }
    @IBAction func goToCalendar(_ sender: Any) {
        let url = URL(string:"calshow://")!
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
    
    var calendars: [EKCalendar]?

    
    
    override func viewDidLoad() {
        //The following sets borders for the buttons on the main screen, made by me
        triangleButton.layer.borderColor = UIColor.gray.cgColor
        triangleButton.layer.borderWidth = 1
        triangleButton.layer.cornerRadius = 5
        
        pcOptimumButton.layer.borderColor = UIColor.gray.cgColor
        pcOptimumButton.layer.borderWidth = 1
        pcOptimumButton.layer.cornerRadius = 5
        
        airMilesButton.layer.borderColor = UIColor.gray.cgColor
        airMilesButton.layer.borderWidth = 1
        airMilesButton.layer.cornerRadius = 5
        
        loadCalendars()

        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        checkCalendarAuthorizationStatus()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func checkCalendarAuthorizationStatus() {
        let status = EKEventStore.authorizationStatus(for: EKEntityType.event)
        
        switch (status) {
        case EKAuthorizationStatus.notDetermined:
            
            requestAccessToCalendar()
            
        case EKAuthorizationStatus.authorized:
            
            loadCalendars()
            if calendarHasBeenCreated != true {
                createCalendar()
            }
            
        case EKAuthorizationStatus.restricted, EKAuthorizationStatus.denied:
            
            requestAccessToCalendar()
            
        }
        
    }

    func requestAccessToCalendar() {
        
        eventStore.requestAccess(to: EKEntityType.event, completion: {
            (accessGranted: Bool, error: Error?) in
            
            if accessGranted == true {
                DispatchQueue.main.async(execute: {
                    self.loadCalendars()
                })
            }
        })
    }
    
    func loadCalendars() {
       // _ = eventStore.calendars(for: EKEntityType.event)
        self.calendars = EKEventStore().calendars(for: EKEntityType.event).sorted() {
            (cal1, cal2) -> Bool in
            return cal1.title < cal2.title
        }
        
    }

    func createCalendar() {
        
        do {
            let calender = EKCalendar(for: .event, eventStore: eventStore)
            calender.title = "Points"
            let sourcesInEventStore = eventStore.sources
            let filteredEventStores = sourcesInEventStore.filter {
                (source: EKSource) -> Bool in source.sourceType.rawValue == EKSourceType.local.rawValue
            }
            if filteredEventStores.count > 0 {
                calender.source = filteredEventStores.first!
            } else {
                 calender.source = sourcesInEventStore.filter {
                    (source: EKSource) -> Bool in source.sourceType.rawValue == EKSourceType.subscribed.rawValue
                    }.first //this used to be first? but error arose and removed question mark
            }
            try eventStore.saveCalendar(calender, commit: true)
            
            print("Calendar was successfully created")
            calendarHasBeenCreated = true
            UserDefaults.standard.set(true, forKey: "Key")
            
        } catch {
            
            print("Error occured while creating calendar")
            UserDefaults.standard.set(false, forKey: "Key")
            
        }
    }



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
