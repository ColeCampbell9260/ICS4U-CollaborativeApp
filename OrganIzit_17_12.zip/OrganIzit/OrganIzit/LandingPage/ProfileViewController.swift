//
//  ProfileViewController.swift
//  OrganIzit
//
//  Created by Cole Campbell on 2018-12-04.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    
    var profiles : [Profile] = []
    
    var pic : UIImage?
    var interfaceIndex = 0
    
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    @IBOutlet weak var usernameSplashLabel: UILabel!
    @IBOutlet weak var passwordSplashLabel: UILabel!
    
    @IBOutlet weak var usernameLabel: UILabel!
    
    let usernameCreateSplash = "Create Your Username:"
    let usernameEditSplash = "Edit Your Username:"
    
    let passwordCreateSplash = "Create A Password (Optional):"
    let passwordEditSplash = "Edit Your Password:"
    
    let usernameWarning = "Please Enter a Username!"
    let duplicateWarning = "Username Already Taken!"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if interfaceIndex == 1 {
            usernameSplashLabel.text = usernameCreateSplash
            passwordSplashLabel.text = passwordCreateSplash
        } else if interfaceIndex == 2 {
            usernameSplashLabel.text = usernameEditSplash
            passwordSplashLabel.text = passwordEditSplash
        }
    }
    
    func addImageFromButton(sender: UIButton) {
        pic = sender.currentImage
    }
    
    //ProfileImageButtonActions
    @IBAction func addDefaultOne(_ sender: UIButton) {
        if sender.isSelected {
            sender.setImage(UIImage(imageLiteralResourceName: "Default_1"), for: .normal)
            sender.isSelected = false
        } else {
            sender.setImage(UIImage(imageLiteralResourceName: "Calendar"), for: .selected)
            sender.isSelected = true
        }
        addImageFromButton(sender: sender)
    }
    @IBAction func addDefaultTwo(_ sender: UIButton) {
        addImageFromButton(sender: sender)
    }
    @IBAction func addDefaultThree(_ sender: UIButton) {
        addImageFromButton(sender: sender)
    }
    @IBAction func addDefaultFour(_ sender: UIButton) {
        addImageFromButton(sender: sender)
    }
    @IBAction func addDefaultFive(_ sender: UIButton) {
        addImageFromButton(sender: sender)
    }
    @IBAction func addDefaultSix(_ sender: UIButton) {
        addImageFromButton(sender: sender)
    }
    //End
    
    @IBAction func finishProfile(_ sender: Any) {
        
        guard usernameField.text!.count > 0 else {
            usernameLabel.text = usernameWarning
            return
        }
        
        let testProfile = Profile(username: usernameField.text!, password: passwordField.text, profilePicture: pic)
        
        for profile in profiles {
            guard testProfile != profile else {
                usernameLabel.text = duplicateWarning
                return
            }
        }
        
        performSegue(withIdentifier: "unwindBack", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if interfaceIndex == 1 {
            
            let profile = Profile(username: usernameField.text!, password: passwordField.text, profilePicture: pic)
            let landingPage = segue.destination as! LandingPageViewController
            
            createProfile(profile: profile, landingPage: landingPage)
            
            for testProfile in landingPage.profiles {
                guard testProfile != profile else {
                    usernameLabel.text = duplicateWarning
                    return
                }
            }
            
        } else if interfaceIndex == 2 {
            editProfile()
        }
    }
    
    func createProfile(profile: Profile, landingPage: LandingPageViewController) {
        landingPage.profiles.append(profile)
        if !landingPage.editProfileButton.isEnabled {
            landingPage.editProfileButton.isEnabled = true
        }
        if !landingPage.loginButton.isEnabled {
            landingPage.loginButton.isEnabled = true
        }
    }
    
    func editProfile() {
        
    }

}
