//
//  ListMaker.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-07.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class ListMaker: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var listMakerNavBar: UINavigationBar!
    
    var userOptions : [String] = []
    var onlyAddItemsOnce : Bool = false
    
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if onlyAddItemsOnce == false {
            userOptions.append(car.nameOfActivityType)
            userOptions.append(outOfCountry.nameOfActivityType)
            userOptions.append(plane.nameOfActivityType)
            userOptions.append(overnight.nameOfActivityType)
            userOptions.append(cold.nameOfActivityType)
            userOptions.append(hot.nameOfActivityType)
            userOptions.append(curling.nameOfActivityType)
            userOptions.append(luge.nameOfActivityType)
            userOptions.append(snowboarding.nameOfActivityType)
            userOptions.append(speedSkating.nameOfActivityType)
            userOptions.append(ringette.nameOfActivityType)
            userOptions.append(skiing.nameOfActivityType)
            userOptions.append(hockey.nameOfActivityType)
            userOptions.append(bobsleigh.nameOfActivityType)
            userOptions.append(tennis.nameOfActivityType)
            userOptions.append(fieldHockey.nameOfActivityType)
            userOptions.append(football.nameOfActivityType)
            userOptions.append(rugby.nameOfActivityType)
            userOptions.append(swimming.nameOfActivityType)
            userOptions.append(baseball.nameOfActivityType)
            userOptions.append(soccer.nameOfActivityType)
            userOptions.append(lacrosse.nameOfActivityType)
            onlyAddItemsOnce = true
        }
        
        return userOptions.count
        
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! itemsToAddToList
        
        cell.itemsUserCanAddTList?.text = userOptions[indexPath.row]
        
        return cell
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        listMakerNavBar.topItem?.title = listTitle

        // Do any additional setup after loading the view.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
