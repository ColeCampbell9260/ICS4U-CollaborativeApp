//
//  MapViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

class FoodBasicsMapViewController: UIViewController {
    var myTitle: String = ""
    @IBOutlet weak var myNodeView: NodeView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
    print("the view is appearing")
     //myNodeView.listTypes()
   //  myNodeView.drawThePath()
      
      
       // myNodeView.setCoordinates()
       // myNodeView.setPoints()
    }

    override func viewWillDisappear(_ animated: Bool) {
    print("the view is disappearing")
   //myNodeView.dummy()
      
      //myNodeView.clear()
    }
   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "FoodBasicsSegue"){
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
        }
    
    }
    
    @IBAction func AisleOne(_ sender: Any) {
        myTitle = "Aisle One"
        currentDept = .Grocery
        currentAisle = .one
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleTwo(_ sender: Any) {
        myTitle = "Aisle Two"
        currentDept = .Grocery
        currentAisle = .two
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleThree(_ sender: Any) {
        myTitle = "Aisle Three"
        currentDept = .Grocery
        currentAisle = .three
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleFour(_ sender: Any) {
        myTitle = "Aisle Four"
        currentDept = .Grocery
        currentAisle = .four
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleFive(_ sender: Any) {
        myTitle = "Aisle Five"
        currentDept = .Grocery
        currentAisle = .five
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleSix(_ sender: Any) {
        myTitle = "Aisle Six"
        currentDept = .Grocery
        currentAisle = .six
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleSeven(_ sender: Any) {
        myTitle = "Aisle Seven"
        currentDept = .Grocery
        currentAisle = .seven
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleEight(_ sender: Any) {
        myTitle = "Aisle Eight"
        currentDept = .Grocery
        currentAisle = .eight
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func ProduceButton(_ sender: Any) {
        myTitle = "Produce"
        currentDept = .Produce
        currentAisle = nil
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func BakeryButton(_ sender: Any) {
        myTitle = "Bakery"
        currentDept = .Grocery
        currentAisle = .bakery
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func FancyMeatButton(_ sender: Any) {
        myTitle = "Fancy Meat"
        currentDept = .Meat
        currentAisle = .fancyMeat
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
  
    @IBAction func SeafoodButton(_ sender: Any) {
        myTitle = "Seafood"
        currentDept = .Meat
        currentAisle = .seafood
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func FrozenFoodButton(_ sender: Any) {
        myTitle = "Frozen Food"
        currentDept = .Grocery
        currentAisle = .frznFood
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func FrozenSweetsButton(_ sender: Any) {
        myTitle = "Frozen Sweets"
        currentDept = .Grocery
        currentAisle = .frznSweets
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func MeatButton(_ sender: Any) {
     myTitle = "Meat"
        currentDept = .Meat
        currentAisle = nil
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    
    
    @IBAction func DairyButton(_ sender: Any) {
    myTitle = "Dairy"
        currentDept = .Meat
        currentAisle = nil
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


    


}
