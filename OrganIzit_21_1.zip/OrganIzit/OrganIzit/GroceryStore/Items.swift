//
//  Items.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-27.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit
import Foundation

class Item: Comparable, Equatable {
    
    
    var name: String
    var location: (Department, Department, Department)
    var quantity: Int = 0
    var notes: String = ""
    var aisle: (Aisle?, Aisle?, Aisle?) = (nil, nil, nil)
    var number: Int
    
    init(name: String, location: (Department, Department, Department), number: Int){
        self.name = name
        self.location = location
        self.number = number
    }
    init(name: String, location: (Department, Department, Department), quantity: Int, number: Int){
        self.name = name
        self.location = location
        self.quantity = quantity
        self.number = number
    }
    
    init(name: String, location: (Department, Department, Department), aisle: (Aisle?, Aisle?, Aisle?), number: Int){
        self.name = name
        self.location = location
        self.aisle = aisle
        self.number = number
    }
    init(name: String, location: (Department, Department, Department), aisle: (Aisle?, Aisle?, Aisle?), quantity: Int, number: Int){
        self.name = name
        self.location = location
        self.aisle = aisle
        self.quantity = quantity
        self.number = number
    }
    
    func addOne() {
        quantity += 1
    }
    
    func subtractOne() {
        if quantity > 0 {
            quantity -= 1
        }
    }
    
    func changeNote(note: String) {
        notes = note
    }
    
    
    static func < (lhs: Item, rhs: Item) -> Bool {
        return  lhs.name < rhs.name
    }
    
    static func > (lhs: Item, rhs: Item) -> Bool {
        return  lhs.name > rhs.name
    }
    
    static func == (lhs: Item, rhs: Item) -> Bool {
        return  lhs.name == rhs.name
    }
}


enum Department {
    case Produce
    case Meat
    case Dairy
    case Grocery
    case Other
    case None
}

enum Aisle {
    case one
    case two
    case three
    case four
    case five
    case six
    case seven
    case eight
    case nine
    case ten
    case bakery
    case frznSweets
    case frznFood
    case fancyMeat
    case seafood
    case other
}



var addItem: [Item] = [Item(name: "Add Item", location: (.Other, .Other, .Other), number: 0)]

var allItems: [Item] = [
/* 0 */         Item(name: "nil", location: (.None, .None, .None), number: 0),
        
/* 1 */         Item(name: "Apples", location: (.Produce, .Produce, .None), number: 1),
/* 2 */         Item(name: "Bannanas", location: (.Produce, .Produce, .None), number: 2),
/* 3 */         Item(name: "Blueberries", location: (.Produce, .Produce, .None), number: 3),
/* 4 */         Item(name: "Brocolli", location: (.Produce, .Produce, .None), number: 4),
/* 5 */         Item(name: "Cabbage", location: (.Produce, .Produce, .None), number: 5),
/* 6 */         Item(name: "Cucumber", location: (.Produce, .Produce, .None), number: 6),
/* 7 */         Item(name: "Grapes", location: (.Produce, .Produce, .None), number: 7),
/* 8 */         Item(name: "Kiwi", location: (.Produce, .Produce, .None), number: 8),
/* 9 */         Item(name: "Lettuce", location: (.Produce, .Produce, .None), number: 9),
/* 10 */        Item(name: "Oranges", location: (.Produce, .Produce, .None), number: 10),
/* 11 */        Item(name: "Potatoes", location: (.Produce, .Produce, .None), number: 11),
/* 12 */        Item(name: "Strawberries", location: (.Produce, .Produce, .None), number: 12),
        
        
/* 13 */        Item(name: "Butter", location: (.Dairy, .Dairy, .Grocery), aisle: (nil, nil, .eight), number: 13),
/* 14 */        Item(name: "Cheese", location: (.Dairy, .Dairy, .Grocery), aisle: (nil, nil, .eight), number: 14),
/* 15 */        Item(name: "Eggs", location: (.Dairy, .Dairy, .Grocery), aisle: (nil, nil, .eight), number: 15),
/* 16 */        Item(name: "Lemonade", location: (.Dairy, .Dairy, .Grocery), aisle: (nil, nil, .eight), number: 16),
/* 17 */        Item(name: "Milk", location: (.Dairy, .Dairy, .Grocery), aisle: (nil, nil, .eight), number: 17),
/* 18 */        Item(name: "Orange Juice", location: (.Dairy, .Dairy, .Grocery), aisle: (nil, nil, .eight), number: 18),
        
        
        
/* 19 */        Item(name: "Paper Towels", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, nil), number: 19),
/* 20 */        Item(name: "Toilet Paper", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, nil), number: 20),
        
/* 21 */        Item(name: "Pet Food", location: (.Grocery, .Grocery, .None), aisle: (.two, .two, nil), number: 21),
        
/* 22 */        Item(name: "Cereal", location: (.Grocery, .Grocery, .None), aisle: (.three, .three, nil), number: 22),
/* 23 */        Item(name: "Peanut Butter", location: (.Grocery, .Grocery, .None), aisle: (.three, .three, nil), number: 23),
        
/* 24 */        Item(name: "Spices", location: (.Grocery, .Grocery, .None), aisle: (.four, .four, nil), number: 24),
        
/* 25 */        Item(name: "Tacos", location: (.Grocery, .Grocery, .None), aisle: (.six, .six, nil), number: 25),
        
/* 26 */        Item(name: "Chips", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .eight), number: 26),
/* 27 */        Item(name: "Pop", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .eight), number: 27),
/* 28 */        Item(name: "Water", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .eight), number: 28),
        
/* 29 */        Item(name: "Coffee", location: (.Grocery, .Grocery, .None), aisle: (.eight, .eight, nil), number: 29),
                
                
/* 30 */        Item(name: "Bread", location: (.Grocery, .Grocery, .Grocery), aisle: (.bakery, .bakery, .eight), number: 30),

/* 31 */        Item(name: "Shampoo", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .three), number: 31),
/* 32 */        Item(name: "Body Wash", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .three), number: 32),
/* 33 */        Item(name: "Tooth Brush", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .three), number: 33),
/* 34 */        Item(name: "Tooth Paste", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .three), number: 34),
/* 35 */        Item(name: "Tampons", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .five), number: 35),
/* 36 */        Item(name: "Halmark Cards", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .five), number: 36),
/* 37 */        Item(name: "Advil", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .six), number: 37),
/* 38 */        Item(name: "Reactine", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .six), number: 38),
/* 39 */        Item(name: "Magazine", location: (.Grocery, .Grocery, .Grocery), aisle: (nil, nil, .ten), number: 39),
/* 40 */        Item(name: "Prescription", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .other), number: 40),
/* 41 */        Item(name: "Deodorant", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .three), number: 41),
/* 42 */        Item(name: "Diapers", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .four), number: 42),
/* 43 */        Item(name: "Soup", location: (.Grocery, .Grocery, .None), aisle: (.five, .five, nil), number: 43),
/* 44 */        Item(name: "Carrots", location: (.Produce, .Produce, .None), number: 44),



        ]






/*
 //Produce
 var apples = Item(name: "Apples", location: (.Produce, .Produce, .Produce))
 var bannanas = Item(name: "Bannanas", location: (.Produce, .Produce, .Produce))
 var blueberries = Item(name: "Blueberries", location: (.Produce, .Produce, .Produce))
 var brocolli = Item(name: "Brocolli", location: (.Produce, .Produce, .Produce))
 var cabbage = Item(name: "Cabbage", location: (.Produce, .Produce, .Produce))
 var cucumber = Item(name: "Cucumber", location: (.Produce, .Produce, .Produce))
 var grapes = Item(name: "Grapes", location: (.Produce, .Produce, .Produce))
 var kiwi = Item(name: "Kiwi", location: (.Produce, .Produce, .Produce))
 var lettuce = Item(name: "Lettuce", location: (.Produce, .Produce, .Produce))
 var oranges = Item(name: "Oranges", location: (.Produce, .Produce, .Produce))
 var potatoes = Item(name: "Potatoes", location: (.Produce, .Produce, .Produce))
 var strawberries = Item(name: "Strawberries", location: (.Produce, .Produce, .Produce))
 
 
 //Dairy
 var butter = Item(name: "Butter", location: (.Dairy, .Dairy, .Dairy))
 var cheese = Item(name: "Cheese", location: (.Dairy, .Dairy, .Dairy))
 var eggs = Item(name: "Eggs", location: (.Dairy, .Dairy, .Dairy))
 var lemonade = Item(name: "Lemonade", location: (.Dairy, .Dairy, .Dairy))
 var milk = Item(name: "Milk", location: (.Dairy, .Dairy, .Dairy))
 var orangejuice = Item(name: "Orange Juice", location: (.Dairy, .Dairy, .Dairy))
 
 //Grocery
 var papertowels = Item(name: "Paper Towels", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .one,)
 var toiletpaper = Item(name: "Toilet Paper", location: (.Grocery, .Grocery, .Grocery), aisle: (.one, .one, .one,)
 
 var petfood = Item(name: "Pet Food", location: (.Grocery, .Grocery, .Grocery), aisle: (.two, .two, .two)
 
 var cereal = Item(name: "Cereal", location: (.Grocery, .Grocery, .Grocery), aisle: (.three, .three, .three))
 var peanutbutter = Item(name: "Peanut Butter", location: (.Grocery, .Grocery, .Grocery), aisle: (.three, .three, .three))
 
 var tacos = Item(name: "Tacos", location: (.Grocery, .Grocery, .Grocery), aisle: (.six, .six, .six))
 
 var chips = Item(name: "Chips", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .seven))
 var pop = Item(name: "Pop", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .seven))
 var water = Item(name: "Water", location: (.Grocery, .Grocery, .Grocery), aisle: (.seven, .seven, .seven))
 
 var coffee = Item(name: "Coffee", location: (.Grocery, .Grocery, .Grocery), aisle: (.eight, .eight, .eight))
 
 */


