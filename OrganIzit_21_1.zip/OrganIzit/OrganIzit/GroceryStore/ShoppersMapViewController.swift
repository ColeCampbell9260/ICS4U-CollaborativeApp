//
//  FoodLandMapViewController.swift
//  OrganIzit
//
//  Created by Matt McArdle on 2018-12-18.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class ShoppersMapViewController: UIViewController {
 
    var myTitle: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        

        if(segue.identifier == "ShoppersSegue"){
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
        }
    }
    
    @IBAction func AisleOne(_ sender: Any) {
        myTitle = "Cosmetics"
        currentDept = .Grocery
        currentAisle = .one
        

        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
    @IBAction func AisleTwo(_ sender: Any) {
        myTitle = "Hair Products"
        currentDept = .Grocery
        currentAisle = .two
        

        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
    @IBAction func AisleThree(_ sender: Any) {
        myTitle = "Hygiene"
        currentDept = .Grocery
        currentAisle = .three
        

        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
    @IBAction func AisleFour(_ sender: Any) {
        myTitle = "Baby Products"
        currentDept = .Grocery
        currentAisle = .four
        

        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
    @IBAction func AisleFive(_ sender: Any) {
        myTitle = "Female Hygiene/Cards"
        currentDept = .Grocery
        currentAisle = .five
        

        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
    @IBAction func AisleSix(_ sender: Any) {
        myTitle = "Pharmaceutical Products"
        currentDept = .Grocery
        currentAisle = .six
        

        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
    @IBAction func AisleSeven(_ sender: Any) {
        myTitle = "Vitamins"
        currentDept = .Grocery
        currentAisle = .seven
        
        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
    @IBAction func Grocery(_ sender: Any) {
        myTitle = "Grocery"
        currentDept = .Grocery
        currentAisle = .eight
        

        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
    @IBAction func Tech(_ sender: Any) {
        myTitle = "Tech"
        currentDept = .Grocery
        currentAisle = .nine
        

        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
    @IBAction func Literature(_ sender: Any) {
        myTitle = "Literature"
        currentDept = .Grocery
        currentAisle = .ten
        

        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
    @IBAction func Pharmacy(_ sender: Any) {
        myTitle = "Pharmacy"
        currentDept = .Grocery
        currentAisle = .other
        
        
        performSegue(withIdentifier: "ShoppersSegue", sender: nil)
    }
  
    
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
