//
//  Tabs.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-20.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

class TabBarController: UITabBarController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
}


