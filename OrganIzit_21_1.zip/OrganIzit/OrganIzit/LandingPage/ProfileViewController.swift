//
//  ProfileViewController.swift
//  OrganIzit
//
//  Created by Cole Campbell on 2018-12-04.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    
    var pic : UIImage?
    var interfaceIndex = 0
    
    let defaults = UserDefaults.standard
    
    @IBOutlet weak var usernameField: UITextField! {
        didSet { usernameField?.closeButton() }
    }
    @IBOutlet weak var passwordField: UITextField! {
        didSet { passwordField?.closeButton() }
    }
    
    @IBOutlet weak var usernameSplashLabel: UILabel!
    @IBOutlet weak var passwordSplashLabel: UILabel!
    
    @IBOutlet weak var usernameLabel: UILabel!
    
    @IBOutlet weak var finishButton: UIButton!
    
    let usernameCreateSplash = "Create Your Username:"
    let usernameEditSplash = "Edit Your Username:"
    
    let passwordCreateSplash = "Create A Password (Optional):"
    let passwordEditSplash = "Edit Your Password:"
    
    let usernameWarning = "Please Enter a Username!"
    let duplicateWarning = "Username Already Taken!"
    
    //Image Button Outlets
    @IBOutlet weak var defaultOne: UIButton!
    @IBOutlet weak var defaultTwo: UIButton!
    @IBOutlet weak var defaultThree: UIButton!
    @IBOutlet weak var defaultFour: UIButton!
    @IBOutlet weak var defaultFive: UIButton!
    @IBOutlet weak var defaultSix: UIButton!
    
    var imageButtons : [UIButton] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageButtons = [defaultOne, defaultTwo, defaultThree, defaultFour, defaultFive, defaultSix]
        
        if interfaceIndex == 1 {
            usernameSplashLabel.text = usernameCreateSplash
            passwordSplashLabel.text = passwordCreateSplash
            finishButton.setTitle("Sign Up", for: .normal)
        } else if interfaceIndex == 2 {
            usernameSplashLabel.text = usernameEditSplash
            passwordSplashLabel.text = passwordEditSplash
            finishButton.setTitle("Make Changes", for: .normal)
        }
    }
    
    func addImageFromButton(sender: UIButton) {
        if pic != sender.currentImage {
            pic = sender.currentImage
        } else {
            pic = nil
        }
    }
    
    func swapImage(index: Int) {
        let sender = imageButtons[index - 1]
        if sender.isSelected {
            sender.setImage(defaultPictures[index], for: .normal)
            sender.isSelected = false
        } else {
            sender.setImage(UIImage(imageLiteralResourceName: "Default_\(index)s"), for: .selected)
            sender.isSelected = true
        }
        for button in 0..<imageButtons.count {
            if button != (index - 1) {
                imageButtons[button].setImage(defaultPictures[button + 1], for: .normal)
                imageButtons[button].isSelected = false
            }
        }
        
    }
    
    //ProfileImageButtonActions
    @IBAction func addDefaultOne(_ sender: UIButton) {
        addImageFromButton(sender: sender)
        swapImage(index: 1)
    }
    @IBAction func addDefaultTwo(_ sender: UIButton) {
        addImageFromButton(sender: sender)
        swapImage(index: 2)
    }
    @IBAction func addDefaultThree(_ sender: UIButton) {
        addImageFromButton(sender: sender)
        swapImage(index: 3)
    }
    @IBAction func addDefaultFour(_ sender: UIButton) {
        addImageFromButton(sender: sender)
        swapImage(index: 4)
    }
    @IBAction func addDefaultFive(_ sender: UIButton) {
        addImageFromButton(sender: sender)
        swapImage(index: 5)
    }
    @IBAction func addDefaultSix(_ sender: UIButton) {
        addImageFromButton(sender: sender)
        swapImage(index: 6)
    }
    //End
    
    @IBAction func finishProfile(_ sender: Any) {
        
        if interfaceIndex == 1 {
            guard usernameField.text!.count > 0 else {
                usernameLabel.text = usernameWarning
                return
            }
        }
        
        let testProfile = Profile(username: usernameField.text!, password: passwordField.text, profilePicture: pic)
        
        for profile in profiles {
            guard testProfile != profile else {
                usernameLabel.text = duplicateWarning
                return
            }
        }
        
        performSegue(withIdentifier: "unwindBack", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let landingPage = segue.destination as! LandingPageViewController
        if interfaceIndex == 1 {
            createProfile(landingPage: landingPage)
        } else if interfaceIndex == 2 {
            editProfile(landingPage: landingPage)
        }
    }
    
    func createProfile(landingPage: LandingPageViewController) {
        let profile = Profile(username: usernameField.text!, password: passwordField.text, profilePicture: pic)
        profiles.append(profile)
        if !landingPage.loginButton.isEnabled {
            landingPage.loginButton.isEnabled = true
        }
        
        profileUsernames.append(profile.username)
        profilePasswords.append(profile.password)
        profilePictures.append(getProfilePictureIndex(image: profile.profilePicture))
        
        print(profileUsernames, profilePasswords, profilePictures)
        defaults.set(profileUsernames, forKey: "Usernames")
        defaults.set(profilePasswords, forKey: "Passwords")
        defaults.set(profilePictures, forKey: "Images")
        profilePoints[profile.username] = [0, 0, 0]
        defaults.set(profilePoints, forKey: "ProfilePoints")
        print(profilePoints)
    }
    
    func editProfile(landingPage: LandingPageViewController) {
        var tempUser = usernameField.text!
        var tempPass = passwordField.text!
        var tempPic = pic
        
        let testProfile = profiles[currentProfile]
        
        if tempUser == "" {
            tempUser = testProfile.username
        }
        if tempPass == "" {
            tempPass = testProfile.password
        }
        if tempPic == nil {
            tempPic = testProfile.profilePicture
        }
        let profile = Profile(username: tempUser, password: tempPass, profilePicture: tempPic)
        profilePoints[profile.username] = profilePoints[testProfile.username]
        profiles[currentProfile] = profile
        landingPage.welcomeLabel.text = "Welcome \(profile.username)!"
        landingPage.profilePictureView.image = profile.profilePicture
        
        profileUsernames[currentProfile] = profile.username
        profilePasswords[currentProfile] = profile.password
        profilePictures[currentProfile] = getProfilePictureIndex(image: profile.profilePicture)
        
        defaults.set(profileUsernames, forKey: "Usernames")
        defaults.set(profilePasswords, forKey: "Passwords")
        defaults.set(profilePictures, forKey: "Images")
        
        defaults.set(profilePoints, forKey: "ProfilePoints")
        
    }
    
}
