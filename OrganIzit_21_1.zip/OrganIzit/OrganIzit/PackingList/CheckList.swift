//
//  CheckList.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-05.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

var isChecked : [Bool] = []
var didCheck : [String: Bool] = [:]

class CheckList: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var checkListNavBar: UINavigationBar!
    @IBOutlet weak var checkListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        checkListTableView.reloadInputViews()
        // Do any additional setup after loading the view.
    }
    
    var onlyAddItemsOnce : Bool = false
    
    override func viewWillAppear(_ animated: Bool) {
        userList.resetVariables()

        userList.itemsOnList.removeAll()

        if newListCreated == false {
            listTitle = namesOfAllLists[thePositionInArrays]
        }
        
        checkListNavBar.topItem?.title = listTitle
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
       
        if itemsOnLists[userList.positionInArrays].isEmpty == true {
            itemsOnLists[userList.positionInArrays] = didCheck
            print("I run")
        }
 
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        while onlyAddItemsOnce == false {
        
            if newListCreated == true {
                if lacrosse.doesUserWantOnThereList == true {
                    userList.itemsOnList += lacrosse.whatUserWillAddToList
                }
                
                if soccer.doesUserWantOnThereList == true {
                    userList.itemsOnList += soccer.whatUserWillAddToList
                }
                
                if rugby.doesUserWantOnThereList == true {
                    userList.itemsOnList += rugby.whatUserWillAddToList
                }
                
                if baseball.doesUserWantOnThereList == true {
                    userList.itemsOnList += baseball.whatUserWillAddToList
                }
                
                if swimming.doesUserWantOnThereList == true {
                    userList.itemsOnList += swimming.whatUserWillAddToList
                }
                
                if football.doesUserWantOnThereList == true {
                    userList.itemsOnList += football.whatUserWillAddToList
                }
                
                if fieldHockey.doesUserWantOnThereList == true {
                    userList.itemsOnList += fieldHockey.whatUserWillAddToList
                }
                
                if tennis.doesUserWantOnThereList == true {
                    userList.itemsOnList += tennis.whatUserWillAddToList
                }
                
                if bobsleigh.doesUserWantOnThereList == true {
                    userList.itemsOnList += bobsleigh.whatUserWillAddToList
                }
                
                if hockey.doesUserWantOnThereList == true {
                    userList.itemsOnList += hockey.whatUserWillAddToList
                }
                
                if skiing.doesUserWantOnThereList == true {
                    userList.itemsOnList += skiing.whatUserWillAddToList
                }
                
                if ringette.doesUserWantOnThereList == true {
                    userList.itemsOnList += ringette.whatUserWillAddToList
                }
                
                if speedSkating.doesUserWantOnThereList == true {
                    userList.itemsOnList += speedSkating.whatUserWillAddToList
                }
                
                if snowboarding.doesUserWantOnThereList == true {
                    userList.itemsOnList += snowboarding.whatUserWillAddToList
                }
                
                if luge.doesUserWantOnThereList == true {
                    userList.itemsOnList += luge.whatUserWillAddToList
                }
                
                if curling.doesUserWantOnThereList == true {
                    userList.itemsOnList += curling.whatUserWillAddToList
                }
                
                if hot.doesUserWantOnThereList == true {
                    userList.itemsOnList += hot.whatUserWillAddToList
                }
                
                if cold.doesUserWantOnThereList == true {
                    userList.itemsOnList += cold.whatUserWillAddToList
                }
                
                if overnight.doesUserWantOnThereList == true {
                    userList.itemsOnList += overnight.whatUserWillAddToList
                }
                
                if plane.doesUserWantOnThereList == true {
                    userList.itemsOnList += plane.whatUserWillAddToList
                }
                
                if outOfCountry.doesUserWantOnThereList == true {
                    userList.itemsOnList += outOfCountry.whatUserWillAddToList
                }
                
                if car.doesUserWantOnThereList == true {
                    userList.itemsOnList += car.whatUserWillAddToList
                }
                
            } else {
                setsBoolsToInputCheckMarks()
                setsTheNamesOfItemsToBeDisplayed()
            }

            isAdded.removeAll()
            whatUserWantsForList.removeAll()
            
            onlyAddItemsOnce = true
            
        }
        
        
        
        return userList.itemsOnList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let itemsOnList = tableView.dequeueReusableCell(withIdentifier: "itemsOnList", for: indexPath) as! UsersCheckListTableViewCell
        
        itemsOnList.itemsOnUsersList?.text = userList.itemsOnList[indexPath.row]
        
        isChecked.append(false)
        didCheck += [userList.itemsOnList[indexPath.row]: isChecked[indexPath.row]]
        
        if(isChecked[indexPath.row]) {
            itemsOnList.accessoryType = .checkmark
        } else {
            itemsOnList.accessoryType = .none
        }
        
        return itemsOnList
    }
    
    
    @IBAction func onPlusTapped() {
        let alert  = UIAlertController(title: "Add Item", message: nil, preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "New Item"
        }
        
        let action = UIAlertAction(title: "Add Item", style: .default, handler: {_ in
            CATransaction.setCompletionBlock({
                if alert.textFields![0].text ?? "" == "" {
                    let errorAlert = UIAlertController(title: "ERROR: Input An Item Name", message: nil, preferredStyle: .alert)
                    let dismiss = UIAlertAction(title: "Dismiss", style: .default, handler: {_ in})
                    errorAlert.addAction(dismiss)
                    self.present(errorAlert, animated: true, completion: nil)
                } else {
                    var newItem = alert.textFields![0].text
                    
                    if newListCreated == true {
                        userList.itemsOnList += [newItem!]
                        itemsOnLists[userList.positionInArrays] += [newItem! : false]
                    } else {
                        userList.itemsOnList += [newItem!]
                        itemsOnLists[thePositionInArrays] += [newItem! : false]
                    }
                    
                    self.checkListTableView.reloadData()
                }
            })
        })
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: {_ in
        })
        
        alert.addAction(cancel)
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) {
            if cell.accessoryType == .none {
                cell.accessoryType = .checkmark
                isChecked[indexPath.row] = true
                didCheck[userList.itemsOnList[indexPath.row]] = true
                itemsOnLists[userList.positionInArrays] = didCheck
            } else if cell.accessoryType == .checkmark {
                cell.accessoryType = .none
                isChecked[indexPath.row] = false
                didCheck[userList.itemsOnList[indexPath.row]] = false
                itemsOnLists[userList.positionInArrays] = didCheck
            }
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCell.EditingStyle.delete {
            didCheck.removeValue(forKey: userList.itemsOnList[indexPath.row])
            userList.itemsOnList.remove(at: indexPath.row)
            checkListTableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
            
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
