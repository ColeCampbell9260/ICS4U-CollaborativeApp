//
//  userCreateAList.swift
//  OrganIzit
//
//  Created by Brian Alpaugh on 2018-12-19.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import Foundation

// This is critical because otherwise I cannot add dictionaries together
// Got from : https://stackoverflow.com/questions/24051904/how-do-you-add-a-dictionary-of-items-into-another-dictionary
func += <K, V> (left: inout [K:V], right: [K:V]) {
    for (k, v) in right {
        left[k] = v
    }
}

class UserCreateAList {
    
    var nameOfList : String
    var positionInArrays : Int
    var itemsOnList : [String]
    var doesUserHaveItems : [String : Bool]
    
    init(nameOfList : String, positionInArrays : Int, itemsOnList : [String]) {
        self.nameOfList = nameOfList
        self.positionInArrays = positionInArrays
        self.itemsOnList = itemsOnList
        doesUserHaveItems = [:]
    }
    
    init(){
        nameOfList = ""
        positionInArrays = -1
        itemsOnList = []
        doesUserHaveItems = [:]
    }
    
    func addToBooledDictionary() {
        for index in 0 ... (itemsOnList.count - 1) {
            doesUserHaveItems += [itemsOnList[index] : false]
        }
    }
    
    func resetVariables() {
        nameOfList = ""
        itemsOnList = []
        doesUserHaveItems = [:]
    }
    
}

func addNameToList() {
    namesOfAllLists[userList.positionInArrays] = userList.nameOfList
}

func addItemsOnListAndWhetherUserHasToDictionary() {
    itemsOnLists[userList.positionInArrays] += userList.doesUserHaveItems
}

var userList = UserCreateAList()
    
