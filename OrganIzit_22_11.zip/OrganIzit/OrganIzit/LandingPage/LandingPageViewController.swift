//
//  ICS4U Collaborative App
//  OrganIzit
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }


}

