//
//  ICS4U Collaborative App
//  OrganIzit
//

import UIKit

class LandingPageViewController: UIViewController {

    
    @IBOutlet weak var profilePictureView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }


}

