//
//  ProfileViewController.swift
//  OrganIzit
//
//  Created by Cole Campbell on 2018-12-04.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    
    var pic : UIImage?
    
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func finishProfile(_ sender: Any) {
        performSegue(withIdentifier: "unwindBack", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let username = usernameField.text!
        let password = passwordField.text
        
        let profile = Profile(username: username, password: password, profilePicture: pic)
        
        let landingPage = segue.destination as! LandingPageViewController
        landingPage.profiles.append(profile)
    }

}
