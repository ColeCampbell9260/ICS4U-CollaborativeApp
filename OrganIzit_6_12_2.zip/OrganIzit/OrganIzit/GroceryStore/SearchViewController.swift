//
//  SearchViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-29.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

class SearchViewController: UITableViewController, UISearchResultsUpdating {
    
    let searchController = UISearchController(searchResultsController: nil)
    var filteredItems = [Item]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //update table view
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "ItemCell")
        self.tableView.reloadData()
        
        //setup search controller
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        
        //reset filtered list
        filteredItems = allItems
    }
    //searching
    func updateSearchResults(for searchController: UISearchController) {
        if searchController.searchBar.text! == ""{
            filteredItems = allItems
        }
        else{
            filteredItems = allItems.filter( { $0.name.lowercased().contains(searchController.searchBar.text!.lowercased()) } )
            if filteredItems.count == 0{
                //add new item
            }
        }
        self.tableView.reloadData()
    }
    
    
    //set up table view and add items
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        if section == 0{
            return filteredItems.count
        }
        else{
            return 0
        }
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath)
        let item: Item
        item = filteredItems[indexPath.row]
        cell.textLabel?.text = item.name
        cell.detailTextLabel?.text = "\(item.type)"
        return cell
    }
    
    
    
    
    
}


