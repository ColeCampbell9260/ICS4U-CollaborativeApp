//
//  Profile.swift
//  OrganIzit
//
//  Created by Cole Campbell on 2018-12-04.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class Profile: Equatable {
    
    
    var username : String
    var password : String
    var profilePicture : UIImage
    
    init(username: String, password: String?, profilePicture: UIImage?) {
        self.username = username
        
        if password != nil && password != "" {
            self.password = password!
        } else {
            self.password = ""
        }
        
        if profilePicture != nil {
            self.profilePicture = profilePicture!
        } else {
            self.profilePicture = UIImage(imageLiteralResourceName: "Default")
        }
        
    }
    
    static func == (lhs: Profile, rhs: Profile) -> Bool {
        return lhs.username == rhs.username
    }
    
}
