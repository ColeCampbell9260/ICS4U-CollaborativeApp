//coded by Nathalie

import UIKit

class AddItemCell: UITableViewCell {
    
    //sets the cells with a label
    var item : Item? {
        didSet {
            addLabel.text = item?.name
        }
    }
    //creates objects for cell
    private let addLabel : UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .left
        label.text = "create a new item"
        return label
    }()
    
    //adds objects and sets constraints for cell
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        addSubview(addLabel)
        
        
        addLabel.anchor(top: topAnchor, left: leftAnchor, bottom: nil, right: nil, paddingTop: 8, paddingLeft: 15, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 2, height: 0, enableInsets: false)
        
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
