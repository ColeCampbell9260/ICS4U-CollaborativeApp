//
//  BlockType.swift
//  testingSegues
//
//  Created by Lizzy on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import Foundation
/* the different types that we make the nodes
coded by: Lizzy
*/
enum BlockType {
    case Air, Obstacle, Path
}
