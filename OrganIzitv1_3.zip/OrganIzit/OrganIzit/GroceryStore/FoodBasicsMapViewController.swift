// final copy
//  MapViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-12-03.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit
//var numberListArray : [Int] = []
//var listArray: [String] = []

class FoodBasicsMapViewController: UIViewController {
    //Matt McArdle: Both other views are the same so this will be where comments are
    
    var myTitle: String = ""
    @IBOutlet weak var myNodeView: NodeView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    /* when the view appears, it runs listTypes (which takes everything from the list, sorts it, and puts the corresponding points in myArray) and drawThePath (which draws the path with the points in myArry
        coded by: Lizzy*/
    override func viewWillAppear(_ animated: Bool) {
     myNodeView.listTypes()
     myNodeView.drawThePath()
    }

    /* when the view dissappears it calls dummy which goes over the current path and makes the nodes white instead of red, and runs clear, which removes everything from myArray and the sortedArray, so when the view loads they can start fresh
    coded by: Lizzy*/
    override func viewDidDisappear(_ animated: Bool) {
        myNodeView.dummy()
        myNodeView.clear()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //Matt McArdle: This sends the user to the PopUpFromMapVC which shows all items in the user's list that is in the selected department
        
        if(segue.identifier == "FoodBasicsSegue"){
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
        }
    
    }
    
    @IBAction func AisleOne(_ sender: Any) {
        //Matt McArdle: These buttons dictate what department was clicked on and activates the segue
        myTitle = "Aisle One"
        currentDept = .Grocery
        currentAisle = .one
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleTwo(_ sender: Any) {
        myTitle = "Aisle Two"
        currentDept = .Grocery
        currentAisle = .two
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleThree(_ sender: Any) {
        myTitle = "Aisle Three"
        currentDept = .Grocery
        currentAisle = .three
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleFour(_ sender: Any) {
        myTitle = "Aisle Four"
        currentDept = .Grocery
        currentAisle = .four
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleFive(_ sender: Any) {
        myTitle = "Aisle Five"
        currentDept = .Grocery
        currentAisle = .five
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleSix(_ sender: Any) {
        myTitle = "Aisle Six"
        currentDept = .Grocery
        currentAisle = .six
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleSeven(_ sender: Any) {
        myTitle = "Aisle Seven"
        currentDept = .Grocery
        currentAisle = .seven
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func AisleEight(_ sender: Any) {
        myTitle = "Aisle Eight"
        currentDept = .Grocery
        currentAisle = .eight
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func ProduceButton(_ sender: Any) {
        myTitle = "Produce"
        currentDept = .Produce
        currentAisle = nil
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func BakeryButton(_ sender: Any) {
        myTitle = "Bakery"
        currentDept = .Grocery
        currentAisle = .bakery
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func FancyMeatButton(_ sender: Any) {
        myTitle = "Fancy Meat"
        currentDept = .Meat
        currentAisle = .fancyMeat
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
  
    @IBAction func SeafoodButton(_ sender: Any) {
        myTitle = "Seafood"
        currentDept = .Meat
        currentAisle = .seafood
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func FrozenFoodButton(_ sender: Any) {
        myTitle = "Frozen Food"
        currentDept = .Grocery
        currentAisle = .frznFood
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func FrozenSweetsButton(_ sender: Any) {
        myTitle = "Frozen Sweets"
        currentDept = .Grocery
        currentAisle = .frznSweets
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    @IBAction func MeatButton(_ sender: Any) {
     myTitle = "Meat"
        currentDept = .Meat
        currentAisle = nil
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    
    
    @IBAction func DairyButton(_ sender: Any) {
    myTitle = "Dairy"
        currentDept = .Dairy
        currentAisle = nil
        
        
        performSegue(withIdentifier: "FoodBasicsSegue", sender: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


    


}
