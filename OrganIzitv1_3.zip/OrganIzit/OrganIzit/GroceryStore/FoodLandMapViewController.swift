//
//  FoodLandMapViewController.swift
//  OrganIzit
//
//  Created by Matt McArdle on 2018-12-18.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class FoodLandMapViewController: UIViewController {
    @IBOutlet weak var myFoodLandNodeView: NodeViewFoodland!
    
    var myTitle: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    /* when the view appears, it runs listTypes (which takes everything from the list, sorts it, and puts the corresponding points in myArray) and drawThePath (which draws the path with the points in myArry
        coded by: Lizzy*/
    override func viewWillAppear(_ animated: Bool) {
        print("the view is appearing")
        myFoodLandNodeView.listTypes()
        myFoodLandNodeView.drawThePath()
    }
    /* when the view dissappears it calls dummy which goes over the current path and makes the nodes white instead of red, and runs clear, which removes everything from myArray and the sortedArray, so when the view loads they can start fresh
    coded by: Lizzy*/
    override func viewWillDisappear(_ animated: Bool) {
    print("the view is disappearing")
        myFoodLandNodeView.dummy()
        myFoodLandNodeView.clear()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        

        if(segue.identifier == "FoodLandSegue"){
            let displayTitle = segue.destination as! PopUpFromMapTableViewController
            displayTitle.newTitle = myTitle
        }
    }
    
    @IBAction func AisleOne(_ sender: Any) {
        myTitle = "Aisle One"
        currentDept = .Grocery
        currentAisle = .one
        

        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func AisleTwo(_ sender: Any) {
        myTitle = "Aisle Two"
        currentDept = .Grocery
        currentAisle = .two
        

        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func AisleThree(_ sender: Any) {
        myTitle = "Aisle Three"
        currentDept = .Grocery
        currentAisle = .three
        

        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func AisleFour(_ sender: Any) {
        myTitle = "Aisle Four"
        currentDept = .Grocery
        currentAisle = .four
        

        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func AisleFive(_ sender: Any) {
        myTitle = "Aisle Five"
        currentDept = .Grocery
        currentAisle = .five
        

        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func AisleSix(_ sender: Any) {
        myTitle = "Aisle Six"
        currentDept = .Grocery
        currentAisle = .six
        

        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func AisleSeven(_ sender: Any) {
        myTitle = "Aisle Seven"
        currentDept = .Grocery
        currentAisle = .seven
        
        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func AisleEight(_ sender: Any) {
        myTitle = "Aisle Eight"
        currentDept = .Grocery
        currentAisle = .eight
        

        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func AisleNine(_ sender: Any) {
        myTitle = "Aisle Nine"
        currentDept = .Grocery
        currentAisle = .nine
        

        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func AisleTen(_ sender: Any) {
        myTitle = "Aisle Ten"
        currentDept = .Grocery
        currentAisle = .ten
        

        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func ProduceButton(_ sender: Any) {
        myTitle = "Produce"
        currentDept = .Produce
        currentAisle = nil
        
        
        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func BakeryButton(_ sender: Any) {
        myTitle = "Bakery"
        currentDept = .Grocery
        currentAisle = .bakery
        
        
        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func MeatButton(_ sender: Any) {
        myTitle = "Meat"
        currentDept = .Meat
        currentAisle = nil
        
        
        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func DairyButton(_ sender: Any) {
        myTitle = "Dairy"
        currentDept = .Dairy
        currentAisle = nil
        
        
        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func FrozenFoodButton(_ sender: Any) {
        myTitle = "Frozen Food"
        currentDept = .Grocery
        currentAisle = .frznFood
        
        
        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    @IBAction func FrozenSweetsButton(_ sender: Any) {
        myTitle = "Frozen Sweets"
        currentDept = .Grocery
        currentAisle = .frznSweets
        
        
        performSegue(withIdentifier: "FoodLandSegue", sender: nil)
    }
    
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
