//Coded by Nathalie

import UIKit


class ItemLayoutCell : UITableViewCell {

    
    var item : Item? {
        //sets the properties of each cell
        didSet {
            itemNameLabel.text = item?.name
            itemTypeLabel.text = "\(item!.location.0)"
            if item!.quantity != 0 {
                itemQuant.text = "\(item!.quantity)"
            }
            else{
                itemQuant.text = ""
            }

        }
        
    }

    
    //set properties of objects in each cell
    private let itemNameLabel : UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .left
        return label
    }()
    
    
    private let itemTypeLabel : UILabel = {
        let label = UILabel()
        label.textColor = .darkGray
        label.font = UIFont.systemFont(ofSize: 12)
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()
    
    private let decreaseButton : UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "minus"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        return button
    }()
    
    private let increaseButton : UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "plus"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        
        return button
    }()
    var itemQuant : UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textAlignment = .left
        label.text = ""
        label.textColor = .black
        return label
    }()
    
    //called when the add/remove buttons are clicked
    @objc func decreaseFunc() {
        changeQuantity(by: -1)
        updateList()
    }
    
    @objc func increaseFunc() {
        changeQuantity(by: 1)
        updateList()
    }
    
    
    func updateList() {
        //item is in the list but must be removed
        if list.contains(item!) && item!.quantity == 0{
            for index in 0..<list.count{
                if item == list[index]{
                    list.remove(at: index)
                    return
                }
            }
        }
            //item was not in the list but needs to be added
        else if list.contains(item!) == false && (item!.quantity == 1){
            list.append(item!)
        }

    }

    func changeQuantity(by amount: Int) {
        //sets item quantity text to be the new quantity
        item!.quantity += amount
        if (item!.quantity) <= 0 {
            item!.quantity = 0
            itemQuant.text = ""
        } else {
            itemQuant.text = "\(item!.quantity)"
        }

    }
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        //adds objects to cell
        addSubview(itemNameLabel)
        addSubview(itemTypeLabel)
        addSubview(decreaseButton)
        addSubview(itemQuant)
        addSubview(increaseButton)
        
        //constraints for cell
        itemNameLabel.anchor(top: topAnchor, left: leftAnchor, bottom: nil, right: nil, paddingTop: 8, paddingLeft: 15, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 2, height: 0, enableInsets: false)
        itemTypeLabel.anchor(top: itemNameLabel.bottomAnchor, left: leftAnchor, bottom: nil, right: nil, paddingTop: 0, paddingLeft: 15, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 2, height: 0, enableInsets: false)
        
        
        let stackView = UIStackView(arrangedSubviews: [decreaseButton, itemQuant, increaseButton])
        stackView.distribution = .equalSpacing
        stackView.axis = .horizontal
        stackView.spacing = 10
        addSubview(stackView)
        stackView.anchor(top: topAnchor, left: itemNameLabel.rightAnchor, bottom: bottomAnchor, right: rightAnchor, paddingTop: 15, paddingLeft: 5, paddingBottom: 15, paddingRight: 35, width: 0, height: 70, enableInsets: false)
        
        //action recognizers
        increaseButton.addTarget(self, action: #selector(increaseFunc), for: .touchUpInside)
        decreaseButton.addTarget(self, action: #selector(decreaseFunc), for: .touchUpInside)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}

