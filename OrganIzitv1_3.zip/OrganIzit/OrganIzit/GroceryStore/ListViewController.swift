//
//  ListViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-28.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

var NotFirstRun = UserDefaults.standard.bool(forKey: "NotFirstRun")

class ListViewController: UITableViewController {
    
    
    
    @IBAction func SaveCurrentList(_ sender: Any) {
        if list.count > 0 {
            let alert  = UIAlertController(title: "New List", message: nil, preferredStyle: .alert)
            
            alert.addTextField { (textField) in
                textField.placeholder = "List Title"
            }
            
            let action = UIAlertAction(title: "Save List", style: .default, handler: {_ in
                CATransaction.setCompletionBlock({
                    if alert.textFields![0].text ?? "" == "" {
                      savedLists.append(("New List", list))
                        self.saveList(listName: alert.textFields![0].text ?? "New List", listToSave: list)
//ran = false
                    } else {
                      savedLists.append((alert.textFields![0].text ?? "New List", list))
                      self.saveList(listName: alert.textFields![0].text ?? "New List", listToSave: list)
//ran = false
                    }
                    self.performSegue(withIdentifier: "Segue", sender: nil)
                    
                    
                })
            })
            
            let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: {_ in
            })
            alert.addAction(cancel)
            alert.addAction(action)
            
            
            present(alert, animated: true, completion: nil)
        } else {
            let alert  = UIAlertController(title: "Must Have Item In The List To Save The List", message: nil, preferredStyle: .alert)
            let cancel = UIAlertAction(title: "Close", style: .cancel, handler: {_ in
            })
            alert.addAction(cancel)
            present(alert, animated: true, completion: nil)
            
            
        }
    }
    
    
    
    
    @IBAction func SavedListButton(_ sender: Any) {
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.tableView.reloadData()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        print(allItems.count)

}
    override func viewDidLoad() {
       //saveList()
//       makeList()

if NotFirstRun == false {
      print("first run")
      setSavedLists()
      UserDefaults.standard.set(true, forKey: "NotFirstRun")
   }
        self.tableView.reloadData()
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0 {
            if list.count == 0 {
                return 1
            }
            return list.count
        } else {
            return 0
        }
        
        
        
    }
    
    
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell", for: indexPath)
        if list.count < 1 {
            cell.textLabel?.text = "Nothing in Your List!"
            cell.detailTextLabel?.text = "Go add items by clicking on the \"Search\" tab!"
        } else {
            let item = list[indexPath.row]
            cell.textLabel?.text = item.name
            cell.detailTextLabel?.text = String(item.quantity)
        }
        // Configure the cell...
        
        return cell
    }
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if list.count > 0 {
            if list[indexPath.row].quantity > 1 {
                list[indexPath.row].subtractOne()
            } else {
                list.remove(at: indexPath.row)
            }
            viewDidAppear(false)
            
        }
    }
    
    
func setSavedLists() {
var test = [30, 17, 15, -100]
//print(test)
UserDefaults.standard.set(test, forKey: "SavedLists")
UserDefaults.standard.set(["Bread, Milk & Eggs"], forKey: "SavedNames")

    }

func saveList(listName: String, listToSave: [Item]) {
    var compressedList = UserDefaults.standard.array(forKey: "SavedLists")
    var namesArray = UserDefaults.standard.array(forKey: "SavedNames")
    
    for item in listToSave {
        compressedList!.append(item.number)
    }
    compressedList!.append(-100)
    namesArray?.append(listName)

    print(compressedList!)
    print(namesArray!)
    
    UserDefaults.standard.set(namesArray, forKey: "SavedNames")
    UserDefaults.standard.set(compressedList, forKey: "SavedLists")
}


    
}


