//
//  NodeViewFoodland.swift
//  OrganIzit
//
//  Created by Nate Maier on 2019-01-16.
//  Copyright © 2019 Cole Campbell. All rights reserved.
//

import UIKit


//Grid and obstacles when visible were set up by Nate

class NodeViewFoodland: UIView {
    var counter = 0
    let size: CGFloat = 70 // size of grid
    var nodes: [[Node]] = [] // array of all the nodes (empty at first)

    override func awakeFromNib() {
        
        // puts all the nodes into the array and makes all dummy nodes of type air
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        
        // creates x and y values for each node in the array
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        setCoordinates()
        setPoints()
        listTypes()
        drawThePath()
        //self.setNeedsDisplay()
    }
    
    func setPoints() {
        // sets points for all the aisles
        //all points found by hand by Nate
        pointEntrance = nodes[50][2] //done
        myArray.append(pointEntrance)
        pointProd = nodes[57][15]//done
        pointMeat = nodes[57][60]//might be wrong
        pointBak = nodes[57][37]//done
        pointPharm = nodes[57][38] //done
        point2 = nodes[45][38]//done
        point3 = nodes[41][38]//done
        point4 = nodes[36][38]//done
        pointDairy = nodes[42][58]//done
        point5 = nodes[30][38]//dont know because we don't have anything in 5
        pointFrozSweets = nodes[24][18]
        point6 = nodes[24][38]//done
        point7 = nodes[19][38]//done
        pointFrozenFood = nodes[7][38]//can't check
        point8 = nodes[14][38]//done
    }
    
    // sets obstacles
    //All obstacles made by hand by Nate
    func setCoordinates() {
        //idk
        for m in 7...61 {
            for n in 61...69{
                nodes[m][n].type = .Obstacle
            }
        }
        //frozen sweets
        for m in 3...42{
            for n in 0...17{
                nodes[m][n].type = .Obstacle
            }
        }
        //frozen food and seafood
        for m in 0...6{
            for n in 0..<70{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //1
        for m in 51...56{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        
       ///2
        for m in 46...49{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //3
        for m in 42...44{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        //4
        for m in 37...40{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }

        //5
        for m in 31...35{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
      

        //6
        for m in 25...29{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        //7
        for m in 20...23{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        

        //8
        
        for m in 15...18{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //9
        for m in 8...13{
            for n in 19...57{
                nodes[m][n].type = .Obstacle
            }
        }
        
        
        //dairy
        for m in 0..<70{
            for n in 59..<70{
                nodes[m][n].type = .Obstacle
            }
        }
        
        //Produce in bottom left
        for m in 55..<70{
            for n in 0...12{
                nodes[m][n].type = .Obstacle
            }
        }
        
        
        //produce and bakery
        for m in 62..<70{
            for n in 0..<70{
                nodes[m][n].type = .Obstacle
            }
        }
    }
    
    // Creates the grid we use for coordinates
    func createRect(rect: CGRect, colour: UIColor) {
        let cont = UIGraphicsGetCurrentContext()
        cont!.setFillColor(colour.cgColor)
        cont!.setStrokeColor(UIColor.clear.cgColor)
        cont!.fill(rect)
        cont!.stroke(rect, width: 2)
    }
    
    // looks left right up and down to check the next node
    func getNeighbourForNode(node: Node, start: Node, goal: Node) -> [Node] {
        let nodex = node.x
        let nodey = node.y
        var finalNodes: [Node] = []
        
        if start.x <= goal.x {
            if nodes.checkIndex(num: nodex+1) {
                finalNodes.append(nodes[nodey][nodex+1])
            }
            if nodes.checkIndex(num: nodey-1) {
                finalNodes.append(nodes[nodey-1][nodex])
            }
            if nodes.checkIndex(num: nodex-1) {
                finalNodes.append(nodes[nodey][nodex-1])
            }
            if nodes.checkIndex(num: nodey+1) {
                finalNodes.append(nodes[nodey+1][nodex])
            }
        }
        if start.x >= goal.x {
            if nodes.checkIndex(num: nodex-1) {
                finalNodes.append(nodes[nodey][nodex-1])
            }
            if nodes.checkIndex(num: nodey-1) {
                finalNodes.append(nodes[nodey-1][nodex])
            }
            if nodes.checkIndex(num: nodex+1) {
                finalNodes.append(nodes[nodey][nodex+1])
            }
            if nodes.checkIndex(num: nodey+1) {
                finalNodes.append(nodes[nodey+1][nodex])
            }
            
        }
        
        var realFinalNode: [Node] = []
        for i in finalNodes {
            if i.from == nil && i.type != .Obstacle {
                realFinalNode.append(i)
            }
        }
        return realFinalNode
    }
    
    
    // Formula to estimate heuristic cost from one node to another node
    func heuristicCostEstimate(from: Node, to: Node) -> Int {
        return (abs(from.x - to.x) + abs(from.y - to.y)) * 40
    }
    // algorithm so find shortest path
    func a_star(_start: Node, _goal: Node) -> [Node] {
        let start = _start
        let goal = _goal
        var closedSet: [Node] = []
        var openSet: [Node] = [start]
        start.g = 0
        start.h = heuristicCostEstimate(from: start, to: goal)
        while openSet.count != 0 {
            var current = lowestFScore()
            if closedSet.count > 0 && openSet.count > 0 {
                if current == closedSet[closedSet.count-1] {
                    current = openSet[0]
                }
            }
            if current == goal {return reconstructPath(current: current)}
            openSet.removeObjFromArray(object: current)
            closedSet.append(current)
            for neighbour in getNeighbourForNode(node: current, start: start, goal: goal) {
                var shouldExecuteIf = true
                if closedSet.contains(neighbour) {shouldExecuteIf = false}
                if shouldExecuteIf {
                    var tentative_g_score = 0
                    tentative_g_score = current.g + 10
                    if !openSet.contains(neighbour) || tentative_g_score < neighbour.g {
                        neighbour.from = current
                        neighbour.g = tentative_g_score
                        neighbour.h = heuristicCostEstimate(from: neighbour, to: goal)
                        if !openSet.contains(neighbour)  {openSet.append(neighbour)}
                    }
                    //nodes[neighbour.y][neighbour.x].type = .ExploredPath
                    // self.setNeedsDisplay()
                }
            }
        }
        self.setNeedsDisplay()
        return []
    }
 
    func drawThePath() {
        counter = 0
        for n in myArray {
            counter += 1
            if counter < myArray.count {
                let path = a_star(_start: n, _goal: myArray[counter])
                for i in path {
                    nodes[i.y][i.x].type = .Path
                    
                }
               // print("start path: \(n.y), \(n.x)")
               // print("goal path: \(myArray[counter].y), \(myArray[counter].x)")
            }
        }
        self.setNeedsDisplay()
        self.layoutIfNeeded()
    }
    
    func dummy() {
        counter = 0
        for n in myArray {
            counter += 1
            if counter < myArray.count {
                let path = a_star(_start: n, _goal: myArray[counter])
                for i in path {
                    nodes[i.y][i.x].type = .Air
                }
               // print("start air: \(n.y), \(n.x)")
               // print("goal air: \(myArray[counter].y), \(myArray[counter].x)")
            }
        }
        self.setNeedsDisplay()
        self.layoutIfNeeded()
    }
    
    override func draw(_ rect: CGRect) {
        self.subviews.map({ $0.removeFromSuperview() })
        let width = self.frame.size.width / size
        let height = self.frame.size.height / size
        var x: CGFloat = 0
        var y: CGFloat = 0
        
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                let rect = CGRect(x: x, y: y, width: width, height: height)
                createRect(rect: rect, colour: nodes[i][j].colour)
                x += width
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
            y += height
            x = 0
        }
    }
    func clear() {
        sortedArray.removeAll()
        myArray.removeAll()
     //   myArray.insert(pointEntrance, at: 0)
    }
    // resets all nodes
    func resetAllNodes() {
        nodes = []
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        self.setNeedsDisplay()
    }
    // resets ony the nodes in your path
    func resetNodes() {
        var tempNodes = nodes
        nodes = []
        for _ in 0..<Int(size) {
            var final: [Node] = []
            for _ in 0..<Int(size) {
                let node: Node = Node()
                node.type = .Air
                final.append(node)
            }
            nodes.append(final)
        }
        
        for i in 0..<nodes.count {
            for j in 0..<nodes[i].count {
                nodes[i][j].x = j
                nodes[i][j].y = i
            }
        }
        for i in 0..<tempNodes.count {
            for j in 0..<tempNodes[i].count {
                if tempNodes[i][j].type == .Obstacle {
                    nodes[i][j].type = .Obstacle
                }
            }
        }
        self.setNeedsDisplay()
    }
    // once you reach you goal in a_star function, comes here at reconstructs path you took
    func reconstructPath(current: Node)-> [Node] {
        var totalPath: [Node] = [current]
        while let par = totalPath.first!.from {
            totalPath.insert(par, at: 0)
            par.type = .Path
        }
        return totalPath
    }
    // looks at all the f scores and returns the node with the lowest f score
    func lowestFScore()-> Node {
        var finalNode: Node = Node()
        finalNode.g = INFINITE
        finalNode.h = INFINITE
        for i in nodes {
            for j in i {
                if j.f <= finalNode.f && j.g != -100 {
                    finalNode = j
                }
            }
        }
        return finalNode
    }
    var sortedArray: [Int] = []
   func listTypes() {
    myArray.insert(pointEntrance, at: 0)
       for item in list {
       print("the item in the list is: \(item.name)")
           if item.location.0 == .Produce {
               sortedArray.append(0)
           }
           if item.location.0 == .Meat{
               sortedArray.append(1)
           }
           if item.aisle.0 == .bakery{
               sortedArray.append(2)
           }
           if item.aisle.0 == .one{
               sortedArray.append(3)
           }
           if item.aisle.0 == .two{
               sortedArray.append(4)
           }
           if item.aisle.0 == .three{
               sortedArray.append(5)
           }
           if item.aisle.0 == .four{
               sortedArray.append(6)
           }
           if item.aisle.0 == .five{
               sortedArray.append(7)
           }
           if item.aisle.0 == .six{
               sortedArray.append(8)
           }
           if item.aisle.0 == .seven{
               sortedArray.append(9)
           }
           if item.aisle.0 == .eight{
               sortedArray.append(10)
           }
           if item.aisle.0 == .frznSweets{
               sortedArray.append(11)
           }
           if item.aisle.0 == .frznFood{
               sortedArray.append(12)
           }
           if item.aisle.0 == .seafood{
               sortedArray.append(13)
           }
           if item.location.0 == .Dairy{
               sortedArray.append(14)
           }
       }
       sortedArray.sort()
       if sortedArray.contains(0){
           myArray.append(pointProd)
           print("\(pointProd) was appended")
       }
       if sortedArray.contains(1){
           myArray.append(pointMeat)
           print("\(pointMeat) was appended")
       }
       if sortedArray.contains(2){
           myArray.append(pointBak)
           print("\(pointBak) was appended")
       }
       if sortedArray.contains(3){
           myArray.append(pointPharm)
           print("\(pointPharm) was appended")
       }
       if sortedArray.contains(4){
           myArray.append(point2)
           print("\(point2) was appended")
       }
       if sortedArray.contains(5){
           myArray.append(point3)
           print("\(point3) was appended")
       }
       if sortedArray.contains(6){
           myArray.append(point4)
           print("\(point4) was appended")
       }
       if sortedArray.contains(7){
           myArray.append(point5)
           print("\(point5) was appended")
       }
       if sortedArray.contains(8){
           myArray.append(point6)
           print("\(point6) was appended")
       }
       if sortedArray.contains(9){
           myArray.append(point7)
           print("\(point7) was appended")
       }
       if sortedArray.contains(10){
           myArray.append(point8)
           print("\(point8) was appended")
       }
       if sortedArray.contains(11){
           myArray.append(pointFrozSweets)
           print("\(pointFrozSweets) was appended")
       }
       if sortedArray.contains(12){
           myArray.append(pointFrozenFood)
           print("\(pointFrozenFood) was appended")
       }
       if sortedArray.contains(13){
           myArray.append(pointSeaf)
           print("\(pointSeaf) was appended")
       }
       if sortedArray.contains(14){
           myArray.append(pointDairy)
           print("\(pointDairy) was appended")
       }
   }
}
