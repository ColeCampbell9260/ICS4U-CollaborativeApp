//
//  SavedListsViewController.swift
//  OrganIzit
//
//  Created by Matt McArdle on 2018-12-14.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit


var straightThrough = 0
var ran = false
class SavedListsViewController: UITableViewController {

override func viewWillAppear(_ animated: Bool) {

if ran == false {
makeList()
ran = true
    }

}
    override func viewDidLoad() {
       //saveList()
       // makeList()
       //setSavedLists()
        super.viewDidLoad()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0 {
            return savedLists.count
        } else {
            return 0
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell", for: indexPath)
     
     let list = savedLists[indexPath.row]
     cell.textLabel?.text = list.0
     
      
     // Configure the cell...
     
        
     return cell
    }
    


    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    list = savedLists[indexPath.row].1
      
        if currentStore == "Basics" {
            straightThrough = 1
        } else if currentStore == "Land" {
            straightThrough = 2
        } else {
            straightThrough = 3
        }
    self.performSegue(withIdentifier: "BackToStart", sender: nil)
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    
    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


func makeList() {

    let compressedList = UserDefaults.standard.array(forKey: "SavedLists")
    let savedNames = UserDefaults.standard.array(forKey: "SavedNames")

    var newList: [Item] = [allItems[0]]
    var savedListsData = [[allItems[0]]]
    var savedNamesData = ["nil"]
    
    savedListsData.removeFirst()
    savedNamesData.removeFirst()
    newList.removeFirst()
    
    print(compressedList!)
    
    var index = 0
    for item in compressedList! {
    
    if let tests: Int? = item as! Int {
    
    if tests == -100 {
    savedListsData.append(newList)
    var name = savedNames![index] as! String
    savedLists.append((name, newList))
    index += 1
    newList.removeAll()
    } else {
    print("Tests\(tests!)")
    var newItem = allItems[tests!]
    newItem.quantity = 1
    newList.append(newItem)
    }
    }
    
    }
       // print(savedLists)

//    print(savedListsData)
//    print(savedListsData[0])
    //list = savedListsData[0]
}
}
