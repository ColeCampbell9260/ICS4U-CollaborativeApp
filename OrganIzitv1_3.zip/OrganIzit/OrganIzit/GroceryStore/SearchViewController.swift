//
//  SearchViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-29.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit
//global variable for searching
var filteredItems = [Item]()

//global variable for the created item
var newItemName = ""

class SearchViewController: UITableViewController, UISearchResultsUpdating{
    
    //regular and add cell IDs
    let cellID = "ItemCell"
    let addCellID = "addItemCell"
    let searchController = UISearchController(searchResultsController: nil)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //allows custom cells to be used in table, goes to code insead of storyboard
        tableView.register(ItemLayoutCell.self, forCellReuseIdentifier: cellID)
        tableView.register(AddItemCell.self, forCellReuseIdentifier: addCellID)
       
        //update table view
        self.tableView.reloadData()
        
        //setup search controller
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        
        //reset filtered list
        filteredItems = sortedAllItems
    }
    //searching
    var itemsFound = true
    func updateSearchResults(for searchController: UISearchController) {
        
        //currently not searching
        if searchController.searchBar.text! == ""{
            itemsFound = true
            filteredItems = sortedAllItems
            
        }
        //currently searching
        else{
            itemsFound = true
            filteredItems = sortedAllItems.filter( { $0.name.lowercased().contains(searchController.searchBar.text!.lowercased()) } )
            if filteredItems.count == 0{
                //add new item, no items found
                itemsFound = false
                filteredItems = addItem
            }
        }
        self.tableView.reloadData()
    }
    
    //set up table rows
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 60
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return filteredItems.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        if itemsFound == true{
            //normal item cells
            let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as! ItemLayoutCell
            let item = filteredItems[indexPath.row]
            cell.item = item
            return cell
        }
        else{
            //add a new item cell
            let cell = tableView.dequeueReusableCell(withIdentifier: addCellID, for: indexPath) as! AddItemCell
            let item = filteredItems[indexPath.row]
            cell.item = item
            return cell
        }
        
        
    }
    // any table row was clicked
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //displays alert when add a new item is clicked
        if itemsFound == false{
            let customAlert = self.storyboard?.instantiateViewController(withIdentifier: "CustomAlert") as! CustomAlertView
            //dismisses search and brings up alert
            newItemName = searchController.searchBar.text!
            self.searchController.dismiss(animated: true, completion: nil)
            customAlert.providesPresentationContextTransitionStyle = true
            customAlert.definesPresentationContext = true
            customAlert.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
            customAlert.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
            customAlert.delegate = self
            self.present(customAlert, animated: true, completion: nil)
        }
        else{
            return
        }
    }
}
extension SearchViewController: CustomAlertViewDelegate {
    //alert, done button
    func doneButtonTapped(selectedDpt: Department, itemName: String) {
    var addedItem: Item //from data inputed in alert
    
    //aisle not needed for item to appear in map
    if selectedDpt == .Dairy || selectedDpt == .Produce || selectedDpt == .Meat{
        addedItem = Item(name: itemName, location: (selectedDpt, selectedDpt, selectedDpt), quantity: 1, number: sortedAllItems.count)
        }
    else{ //aisle needed to appear in map
        //assigns a random aisle to the item
        var randomAisle = Int(arc4random_uniform(UInt32(8)))
        var aisle: Aisle
        switch randomAisle{
        case 0:
            aisle = .one
        case 1:
            aisle = .two
        case 2:
            aisle = .three
        case 3:
            aisle = .four
        case 4:
            aisle = .five
        case 5:
            aisle = .six
        case 6:
            aisle = .seven
        case 7:
            aisle = .eight
        case 8:
            aisle = .nine
        default:
            aisle = .other
        }
        print(aisle)
        addedItem = Item(name: itemName, location: (selectedDpt, selectedDpt, selectedDpt), aisle: (aisle, aisle, aisle), quantity: 1, number: sortedAllItems.count)
        }
        //adds the user created item to the list and array of all items
        sortedAllItems.append(addedItem)
        allItems.append(addedItem)

        list.append(addedItem)
        }
    func cancelButtonTapped() {
    }
}



