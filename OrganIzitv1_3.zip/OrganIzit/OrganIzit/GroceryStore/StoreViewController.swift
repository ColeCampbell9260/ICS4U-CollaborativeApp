//
//  MapViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-20.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit


class StoreViewController: UIViewController {
 
    @IBOutlet weak var TextLabel: UILabel!
    @IBOutlet weak var Logo: UIImageView!
    
    @IBAction func WebsiteButton(_ sender: Any) { //Matt McArdle: This sends the user to the corrisponding website of the active store
        if currentStore == "Basics" {
            openURL(url: "https://www.foodbasics.ca/index.en.html")
        } else if currentStore == "Land" {
            openURL(url: "https://ontario.foodland.ca")
        } else if currentStore == "Shoppers" {
            openURL(url: "https://www1.shoppersdrugmart.ca/en/home")
        }
    }
    override func viewDidLoad() {
        // Item(name: "Milk", location: (.Dairy, .Grocery, .Dairy), aisle: (nil, .seven, nil))
        let shape2 = ShapeView2(frame: CGRect(x: 0, y: screenSize.height - 200, width: screenSize.width, height: 200))
        self.view.addSubview(shape2)
        
        let shape = ShapeView(frame: CGRect(x: 150, y: 64, width: screenSize.width/1.5, height: screenSize.height))
        self.view.addSubview(shape)
        
        if currentStore == "Basics" {
            Logo.image = UIImage(imageLiteralResourceName: "FB2_logo.jpg")
            TextLabel.text = "Hours:\nMonday(9am-9pm), \n\nTuesday(9am-9pm), \n\nWednesday(9am-9pm), \n\nThursday(9am-9pm), \n\nFriday(9am-9pm), \n\nSaturday(8am-8pm), \n\nSunday(9am-8pm)"
        } else if currentStore == "Land" {
            Logo.image = UIImage(imageLiteralResourceName: "FL2_logo")
            TextLabel.text = "Hours:\nMonday(7am-12am), \n\nTuesday(7am-12am), \n\nWednesday(7am-12am), \n\nThursday(7am-12am), \n\nFriday(7am-12am), \n\nSaturday(7am-12am), \n\nSunday(7am-12am)"
        } else if currentStore == "Shoppers"{
            Logo.image = UIImage(imageLiteralResourceName: "SDM2_logo.jpg")
            TextLabel.text = "Hours:\nMonday(8am-10pm), \n\nTuesday(8am-10pm), \n\nWednesday(8am-10pm), \n\nThursday(8am-10pm), \n\nFriday(8am-10pm), \n\nSaturday(8am-10pm), \n\nSunday(8am-10pm)"
        }
        
        
        super.viewDidLoad()
    }
}

func openURL(url:String){
    let temp = URL(string:url)!
    UIApplication.shared.open(temp, options: [:], completionHandler: nil)
}

class ShapeView : UIView { //Matt McArdle: Wanted to learn about custom shapes so I added these functions to mess around creating some visual aspects for this view
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clear
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        backgroundColor = UIColor.clear
    }
    
    override func draw(_ rect: CGRect) {
        let size = self.bounds.size
        
        // calculate the 5 points of the pentagon
        let p1 = self.bounds.origin
        let p2 = CGPoint(x:p1.x + size.width, y:p1.y)
        let p3 = CGPoint(x:p2.x, y:p2.y + size.height)
        let p4 = CGPoint(x:p1.x, y:p1.y + size.height)
        let p5 = CGPoint(x:p1.x+size.width/3, y:p1.y + size.height/2)
        
        
        // create the path
        let path = UIBezierPath()
        path.move(to: p1)
        path.addLine(to: p2)
        path.addLine(to: p3)
        path.addLine(to: p4)
        path.addLine(to: p5)
        
        path.close()
        // path.stroke()
        var colour = UIColor.black
        
        if currentStore == "Basics" {
            colour = UIColor.init(red: 0.07, green: 0.99, blue: 0.2, alpha: 1)
        } else if currentStore == "Land" {
            colour = UIColor.red
        } else if currentStore == "Shoppers"{
            colour = UIColor.init(red: 0.3, green: 0.87, blue: 0.97, alpha: 1)
        } else {
            colour = UIColor.black
            
        }
        
        colour.setFill()
        UIColor.black.setStroke()
        path.stroke()
        // fill the path
        path.fill()
    }
}



class ShapeView2 : UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clear
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        backgroundColor = UIColor.clear
    }
    
    override func draw(_ rect: CGRect) {
        let size = self.bounds.size
        
        // calculate the 5 points of the pentagon
        let p1 = self.bounds.origin
        let p2 = CGPoint(x:p1.x + size.width, y:p1.y)
        let p3 = CGPoint(x:p2.x, y:p2.y + size.height)
        let p4 = CGPoint(x:p1.x, y:p1.y + size.height)
        
        // create the path
        let path = UIBezierPath()
        path.move(to: p1)
        path.addLine(to: p2)
        path.addLine(to: p3)
        path.addLine(to: p4)
        
        path.close()
        // path.stroke()
        var colour = UIColor.black
        
        if currentStore == "Basics" {
            colour = UIColor.init(red: 1, green: 0.9, blue: 0, alpha: 1)
        } else if currentStore == "Land" {
            colour = UIColor.gray
        } else if currentStore == "Shoppers"{
            colour = UIColor.red
        } else {
            colour = UIColor.black
            
        }
        
        colour.setFill()
        UIColor.black.setStroke()
        path.stroke()
        // fill the path
        path.fill()
    }
}
