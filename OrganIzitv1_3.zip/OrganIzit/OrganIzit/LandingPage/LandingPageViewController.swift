//
//  ICS4U Collaborative App
//  OrganIzit
//  All Code in the LandingPage Folder was made by Cole
//  Except for the GIF code in CreditsViewController
//

import UIKit

class LandingPageViewController: UIViewController {
    
    //Declaring Variables
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var profilePictureView: UIImageView!
    @IBOutlet weak var createProfileButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var editProfileButton: UIButton!
    
    let defaults = UserDefaults.standard
    //End Declaration
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Loading Variables from User Defaults
        profileUsernames = defaults.object(forKey: "Usernames") as? [String] ?? []
        profilePasswords = defaults.object(forKey: "Passwords") as? [String] ?? []
        profilePictures = defaults.object(forKey: "Images") as? [Int] ?? []
        
        //Guarding against potential error of having arrays of different lengths
        //Unlikely but a precautionary measure
        guard profileUsernames.count == profilePasswords.count && profilePasswords.count == profilePasswords.count else {return}
        for index in 0..<profileUsernames.count {
            //Creating Profiles from array values
            profiles.append(Profile(username: profileUsernames[index], password: profilePasswords[index], profilePicture: getProfilePictureFromIndex(index: profilePictures[index])))
        }
        //If there are profiles, they can log in
        if profiles.count > 0 {
            loginButton.isEnabled = true
        }
    }
    
    @IBAction func loginPressed(_ sender: UIButton) {
        //Switch Between Log In and Log Out
        if sender.title(for: .normal) == "Log Out" {
            sender.setTitle("Log In", for: .normal)
            currentProfile = -1
            
            welcomeLabel.text = ""
            profilePictureView.image = defaultPicture
            
            if editProfileButton.isEnabled {
                editProfileButton.isEnabled = false
            }
            
        } else {
            performSegue(withIdentifier: "Login", sender: loginButton)
        }
    }
    
    @IBAction func createProfilePressed(_ sender: Any) {
        performSegue(withIdentifier: "Profile", sender: createProfileButton)
    }
    
    @IBAction func editProfilePressed(_ sender: Any) {
        performSegue(withIdentifier: "Profile", sender: editProfileButton)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let sender = sender as? UIButton else {return}
        
        switch(sender) {
            //Editing View Controller Data According to Button Input
        case createProfileButton:
            let profileVC = segue.destination as! ProfileViewController
            segue.destination.navigationItem.title = "Create New Profile"
            profileVC.interfaceIndex = 1
            break
        case editProfileButton:
            let profileVC = segue.destination as! ProfileViewController
            segue.destination.navigationItem.title = "Edit Existing Profile"
            profileVC.interfaceIndex = 2
            break
        default:
            break
        }
    }
    
    //External Links
    @IBAction func openCalendar(_ sender: Any) {
        openURL(url: "https://calendar.woolwich.ca")
    }
    
    @IBAction func openWeather(_ sender: Any) {
        openURL(url: "https://weather.com")
    }
    
    @IBAction func unwindBack(segue: UIStoryboardSegue) { }
    
}

