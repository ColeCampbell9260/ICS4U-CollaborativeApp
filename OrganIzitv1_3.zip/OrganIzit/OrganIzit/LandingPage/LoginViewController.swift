//
//  LoginViewController.swift
//  OrganIzit
//
//  Created by Cole Campbell on 2018-12-13.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    // Declare Variables
    @IBOutlet weak var usernameField: UITextField! {
        //Tyler
        didSet { usernameField?.closeButton() }
    }
    @IBOutlet weak var passwordField: UITextField! {
        //Tyler
        didSet { passwordField?.closeButton() }
    }
    @IBOutlet weak var warningLabel: UILabel!
    
    let incorrectLogin = "Username or Password Incorrect"
    
    var testIndex = -1
    //End Declaration
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //User Presses Login
    @IBAction func loginPressed(_ sender: Any) {
        //temporary profile to compare
        let loginProfile = Profile(username: usernameField.text!, password: passwordField.text, profilePicture: nil)
        //comparing profile loop
        for profile in profiles {
            testIndex = profiles.firstIndex(of: profile)!
            if profile == loginProfile && profile.password == loginProfile.password {
                performSegue(withIdentifier: "unwindBack", sender: sender)
                return
            }
        }
        warningLabel.text = incorrectLogin
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard testIndex >= 0 else { return }
        
        //accessing landing page view controller data
        let landingPage = segue.destination as! LandingPageViewController
        let profile = profiles[testIndex]
        
        currentProfile = testIndex
        landingPage.loginButton.setTitle("Log Out", for: .normal)
        
        landingPage.welcomeLabel.text = "Welcome \(profile.username)!"
        landingPage.profilePictureView.image = profile.profilePicture
        
        if !landingPage.editProfileButton.isEnabled {
            landingPage.editProfileButton.isEnabled = true
        }
        
    }
    
}
