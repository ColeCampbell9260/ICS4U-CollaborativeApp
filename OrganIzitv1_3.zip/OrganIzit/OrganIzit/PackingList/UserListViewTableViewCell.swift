//
//  UserListViewTableViewCell.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-13.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

class UserListViewTableViewCell: UITableViewCell {
    
    @IBOutlet weak var itemsOnUsersList: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
