//
//  UserListsViewController.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-05.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

var newListNumber: Int = 1
var launchCounter: Int = 0
var firstLaunch: Bool = true
var saveInt: Int = 0

class UserLists: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    override func viewWillAppear(_ animated: Bool) {
        
        if firstLaunch == true {
            launchCounter = UserDefaults.standard.integer(forKey: "launchCounter")
            if launchCounter == 0 {
                newListNumber = 1
                saveInt = -1
                userList.positionInArrays = saveInt
                namesOfAllLists[0] = "You have no lists, click the + to create"
                positionInArraysForList = [:]
                itemsOnLists = [[:]]
            } else {
                saveInt = UserDefaults.standard.integer(forKey: "saveInt")
                userList.positionInArrays = saveInt
                newListNumber = UserDefaults.standard.integer(forKey: "newListNumber")
                namesOfAllLists = UserDefaults.standard.stringArray(forKey: "namesOfAllLists") ?? [String]()
                positionInArraysForList = UserDefaults.standard.dictionary(forKey: "positionInArrayForList") as? [String: Int] ?? [:]
                itemsOnLists = UserDefaults.standard.array(forKey: "itemsOnLists") as? [[String: Bool]] ?? [[:]]
                print(userList.positionInArrays)
            }
            firstLaunch = false
            launchCounter += 1
            
            UserDefaults.standard.set(launchCounter, forKey: "launchCounter")
            
            print(itemsOnLists)
            print(namesOfAllLists)
            print(userList.positionInArrays)
            print(positionInArraysForList)
            
        }
        
        // This is where array saving needs to happen
        didCheck.removeAll()
        isChecked.removeAll()
        
        // This resets the variable telling us whether or not a new list has been created
        newListCreated = false
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return namesOfAllLists.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "display", for: indexPath) as! UserListViewTableViewCell
        
        cell.itemsOnUsersList?.text = namesOfAllLists[indexPath.row]
        
        return cell
    }
    
    @IBOutlet weak var userListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //tableView(UITableView[UsersCheckListTableViewCell], cellForRowAt: IndexPath)
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onPlusTapped() {
        let alert  = UIAlertController(title: "New List", message: nil, preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "List Title"
        }
        
        let action = UIAlertAction(title: "Start Creating", style: .default, handler: {_ in
            CATransaction.setCompletionBlock({
                if alert.textFields![0].text ?? "" == "" {
                    if newListNumber == 1 {
                        listTitle = "New List"
                    } else {
                        listTitle = "New List \(newListNumber)"
                    }
                    newListNumber += 1
                    UserDefaults.standard.set(newListNumber, forKey: "newListNumber")
                } else {
                    listTitle = alert.textFields![0].text ?? ""
                }
                
                userList.nameOfList = listTitle
                
                if userList.positionInArrays < 0 {
                    userList.positionInArrays += 1
                    namesOfAllLists[userList.positionInArrays] = userList.nameOfList
                    UserDefaults.standard.set(namesOfAllLists, forKey: "namesOfAllLists")
                    positionInArraysForList = [userList.nameOfList: userList.positionInArrays]
                    UserDefaults.standard.set(positionInArraysForList, forKey: "positionInArrayForList")
                } else {
                    userList.positionInArrays += 1
                    namesOfAllLists += [userList.nameOfList]
                    UserDefaults.standard.set(namesOfAllLists, forKey: "namesOfAllLists")
                    positionInArraysForList += [userList.nameOfList: userList.positionInArrays]
                    UserDefaults.standard.set(positionInArraysForList, forKey: "positionInArrayForList")
                }
                
                saveInt = userList.positionInArrays
                UserDefaults.standard.set(saveInt, forKey: "saveInt")
                
                // These lines add the positions in these arrays so we can put information into them
                itemsOnLists += [[:]]
                UserDefaults.standard.set(itemsOnLists, forKey: "itemsOnLists")
                
                userList.resetVariables()
                
                outOfCountry.resetVariables()
                plane.resetVariables()
                overnight.resetVariables()
                cold.resetVariables()
                hot.resetVariables()
                curling.resetVariables()
                luge.resetVariables()
                snowboarding.resetVariables()
                speedSkating.resetVariables()
                ringette.resetVariables()
                skiing.resetVariables()
                hockey.resetVariables()
                bobsleigh.resetVariables()
                tennis.resetVariables()
                fieldHockey.resetVariables()
                football.resetVariables()
                rugby.resetVariables()
                swimming.resetVariables()
                baseball.resetVariables()
                soccer.resetVariables()
                lacrosse.resetVariables()
                car.resetVariables()
                
                positionInArraysForList += [userList.nameOfList:userList.positionInArrays]
                UserDefaults.standard.set(positionInArraysForList, forKey: "positionInArrayForList")
                
                self.performSegue(withIdentifier: "Segue", sender: nil)
            })
        })
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: {_ in
        })
        
        alert.addAction(cancel)
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func backToUserLists (_ segue: UIStoryboardSegue) {
        self.userListTableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    /*
     func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == UITableViewCell.EditingStyle.delete {
     namesOfAllLists.remove(at: indexPath.row)
     userListTableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
     }
     }
     */
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // This tells us what position in all the arrays the desired user list is stored at
        for (index, key) in positionInArraysForList {
            if namesOfAllLists[indexPath.row] == index {
                thePositionInArrays = key
            }
        }
        
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
