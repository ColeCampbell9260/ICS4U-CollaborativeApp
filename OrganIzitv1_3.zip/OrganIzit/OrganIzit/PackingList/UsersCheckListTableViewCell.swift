//
//  UsersCheckListTableViewCell.swift
//  OrganIzit
//
//  Created by Brian Alpaugh on 2018-12-14.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

// This is a file for the table view cell only so we can display items in it. - Brian
class UsersCheckListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var itemsOnUsersList: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
