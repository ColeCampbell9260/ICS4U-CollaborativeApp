//
//  SecondVC.swift
//  OrganIzit
//
//  Created by Julia Baxter on 2018-11-29.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

public var selectedScreen:Int = 3 //Default will load in PC Optimum

public var profilePoints : [String : [Int]] = ["":[0, 0, 0]]

class SecondVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    //has the properties of a table view for the stores table view
    var tableArray:[String] = []
    var points:Int = 0
    var trianglePoints = 0
    var airPoints = 0
    var pcPoints = 0
    
    @IBAction func backButton(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    

    @IBOutlet weak var companyImage: UIImageView!
    @IBOutlet weak var pointsLabel: UILabel!
    @IBOutlet weak var storeTable: UITableView!
    
    @IBOutlet weak var barTitle: UINavigationItem!
    
    @IBAction func addPointsButton(_ sender: UIButton) { //This entire function is mine(Nate) but Matt started me on how to make popups, same with subtract button function
        //Creates pop up
        print(trianglePoints)
        let alert  = UIAlertController(title: "Add Points", message: nil, preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "Points"
            textField.keyboardType = UIKeyboardType.numberPad
        }
        
        // Following is the action of pressing the confirm button, a lot happens here, it is checking if the points addded in are admissable and creates a few alerts if they aren't, same thing happens in subtract button as well - Nate
        let action = UIAlertAction(title: "Confirm", style: .default, handler: {_ in
            let num = alert.textFields![0].text
            if let addedPoints = (Int(num!)){
                guard addedPoints > 0 else {
                    let errorAlert = UIAlertController(title: "Error, input must be greater than 0", message: nil, preferredStyle: .alert)
                    let dismiss = UIAlertAction(title: "Dismiss", style: .cancel, handler: {_ in})
                    errorAlert.addAction(dismiss)
                    self.present(errorAlert, animated: true, completion: nil)
                    return
                }
                self.points += addedPoints
                print("Points \(self.points)")
                self.refreshPoints()
                
            }else if num != nil, num != ""{
                let errorAlert = UIAlertController(title: "Error, unexpected input", message: nil, preferredStyle: .alert)
                let dismiss = UIAlertAction(title: "Dismiss", style: .cancel, handler: {_ in})
                errorAlert.addAction(dismiss)
                self.present(errorAlert, animated: true, completion: nil
                )
            }
            switch selectedScreen { // Tyler  - Saves point values
            case 1:
                if currentProfile >= 0 && profiles.count > 0 {
                    profilePoints[profiles[currentProfile].username]?[0] = self.trianglePoints
                } else {
                    profilePoints[""]?[0] = self.trianglePoints
                }
                UserDefaults.standard.set(profilePoints, forKey: "ProfilePoints")
            case 2:
                if currentProfile >= 0 && profiles.count > 0 {
                    profilePoints[profiles[currentProfile].username]?[1] = self.airPoints
                } else {
                    profilePoints[""]?[1] = self.airPoints
                }
                UserDefaults.standard.set(profilePoints, forKey: "ProfilePoints")
            case 3:
                if currentProfile >= 0 && profiles.count > 0 {
                    profilePoints[profiles[currentProfile].username]?[2] = self.pcPoints
                } else {
                    profilePoints[""]?[2] = self.pcPoints
                }
                UserDefaults.standard.set(profilePoints, forKey: "ProfilePoints")
            default:
                print("dab 3.5")
                
            }
        })
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: {_ in})
        
        alert.addAction(cancel)
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func subPointsButton(_ sender: UIButton) {//Virtually the same as add points but again tyler did anything relating to data persistence - Nate
        print(trianglePoints)
        let alert  = UIAlertController(title: "Subtract Points", message: nil, preferredStyle: .alert)
        
        alert.addTextField { (textField) in
            textField.placeholder = "Points"
            textField.keyboardType = UIKeyboardType.numberPad // Coded by Julia
        }
        
        let action = UIAlertAction(title: "Confirm", style: .default, handler: {_ in
            let num = alert.textFields![0].text
            if let subtractedPoints = (Int(num!)){
                guard subtractedPoints > 0 else {
                    let errorAlert = UIAlertController(title: "Error, input must be greater than 0", message: nil, preferredStyle: .alert)
                    let dismiss = UIAlertAction(title: "Dismiss", style: .cancel, handler: {_ in})
                    errorAlert.addAction(dismiss)
                    self.present(errorAlert, animated: true, completion: nil)
                    return
                }
                if self.points - subtractedPoints < 0{
                    let errorAlert = UIAlertController(title: "Points subtracted are greater than total points", message: nil, preferredStyle: .alert)
                    let dismiss = UIAlertAction(title: "Dismiss", style: .cancel, handler: {_ in})
                    errorAlert.addAction(dismiss)
                    self.present(errorAlert, animated: true, completion: nil)
                }else{
                    self.points -= subtractedPoints
                    self.refreshPoints()
                }
            }else if num != nil, num != ""{
                let errorAlert = UIAlertController(title: "Error, unexpected input", message: nil, preferredStyle: .alert)
                let dismiss = UIAlertAction(title: "Dismiss", style: .cancel, handler: {_ in})
                errorAlert.addAction(dismiss)
                self.present(errorAlert, animated: true, completion: nil)
                
            }
            switch selectedScreen { // Tyler - also saves point values
            case 1:
                if currentProfile >= 0 && profiles.count > 0 {
                    print(profiles[currentProfile].username)
                    profilePoints[profiles[currentProfile].username]?[0] = self.trianglePoints
                } else {
                    profilePoints[""]?[0] = self.trianglePoints
                }
                UserDefaults.standard.set(profilePoints, forKey: "ProfilePoints")
            case 2:
                if currentProfile >= 0 && profiles.count > 0 {
                    profilePoints[profiles[currentProfile].username]?[1] = self.airPoints
                } else {
                    profilePoints[""]?[1] = self.airPoints
                }
                UserDefaults.standard.set(profilePoints, forKey: "ProfilePoints")
            case 3:
                if currentProfile >= 0 && profiles.count > 0 {
                    profilePoints[profiles[currentProfile].username]?[2] = self.pcPoints
                } else {
                    profilePoints[""]?[2] = self.pcPoints
                }
                UserDefaults.standard.set(profilePoints, forKey: "ProfilePoints")
            default:
                print("dab 3.5")
                
            }
            print(profilePoints)
        })
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: {_ in})
        
        alert.addAction(cancel)
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)

    }
    func refreshPoints(){ // Nate
        switch selectedScreen {
        case 1:
            trianglePoints = points
            pointsLabel.text =  "\(trianglePoints)"
        case 2:
            airPoints = points
            pointsLabel.text = "\(airPoints)"
        case 3:
            pcPoints = points
            pointsLabel.text = "\(pcPoints)"
        default:
            print("dab 2.0")
        }
    }

    
    override func viewWillDisappear(_ animated: Bool) {// Tyler - saves point values (when current view disappears)
        print(trianglePoints)
        switch selectedScreen { //Ty's data persistence
        case 1:
            if currentProfile >= 0 && profiles.count > 0 {
                profilePoints[profiles[currentProfile].username]?[0] = self.trianglePoints
            } else {
                profilePoints[""]?[0] = self.trianglePoints
            }
            print(profilePoints)
            UserDefaults.standard.set(profilePoints, forKey: "ProfilePoints")
        case 2:
            if currentProfile >= 0 && profiles.count > 0 {
                profilePoints[profiles[currentProfile].username]?[1] = self.airPoints
            } else {
                profilePoints[""]?[1] = self.airPoints
            }
            print(profilePoints)
            UserDefaults.standard.set(profilePoints, forKey: "ProfilePoints")
        case 3:
            if currentProfile >= 0 && profiles.count > 0 {
                profilePoints[profiles[currentProfile].username]?[2] = self.pcPoints
            } else {
                profilePoints[""]?[2] = self.pcPoints
            }
            print(profilePoints)
            UserDefaults.standard.set(profilePoints, forKey: "ProfilePoints")
        default:
            print("dab 3.5")
            
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        print("View Appears")
        
        profilePoints = UserDefaults.standard.object(forKey: "ProfilePoints") as? [String:[Int]] ?? ["":[0,0,0]] // Tyler - Loads in the point value to be displayed
        
        var profile : String
        
        if currentProfile >= 0 && profiles.count > 0 {
            profile = profiles[currentProfile].username
        } else {
            profile = ""
        }
        
        print(profilePoints[profile])
        // The following loads in all relevant data to create the corresponding screen, anything without points was done by Nate
        switch  selectedScreen {
        case 1:
            barTitle.title = "Triangle"

            points = profilePoints[profile]?[0] ?? 0
            trianglePoints = points

            tableArray = ["Canadian Tire", "Food Basics", "Foodland", "Shopper's Drug Mart", "Total Health Pharmacy", "Tim Horton's", "McDonald's", "Subway", "Harvey's", "Swiss Chalet"]
            
            companyImage.image = UIImage(named: "SecondTriangleLogo")
            pointsLabel.text = "\(trianglePoints)"
            
            
        case 2:
            barTitle.title = "Air Miles"

            points = profilePoints[profile]?[1] ?? 0
            airPoints = points
            
            tableArray = ["BMO", "Shell", "LCBO", "Foodland", "Food Basics"]
            
            companyImage.image = UIImage(named:"SecondAirMilesLogo")
            pointsLabel.text = "\(airPoints)"
            
        case 3:
            barTitle.title = "PC Optimum"

            points = profilePoints[profile]?[2] ?? 0
            pcPoints = points
            
            tableArray = ["Esso", "Shopper's Drug Mart"]
            
            companyImage.image = UIImage(named: "SecondPCOptimumLogo")
            pointsLabel.text = "\(pcPoints)"
            
        default:
            print("dab")
        }
        storeTable.reloadData()
        
    }
    func openURL(url:String){ //Natae
        let temp = URL(string:url)!
        UIApplication.shared.open(temp, options: [:], completionHandler: nil)
    }
    func numberOfSections(in testTable: UITableView) -> Int {// Setting up table view, all table view related things are done by Nate
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return tableArray.count
        }else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{ //loads text into table - Nate
        let cell = storeTable.dequeueReusableCell(withIdentifier: "cellIdentifier", for: indexPath)
        cell.textLabel?.text = tableArray[indexPath.row]
        cell.showsReorderControl = true
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) { //the "function" of pressing the cell and opening a link - Nate
        switch tableArray[indexPath.row] {
        case "Canadian Tire":
            openURL(url: "https://www.canadiantire.ca/en.html")
        case "Food Basics":
            openURL(url: "https://www.foodbasics.ca/flyer.en.html")
        case "Foodland":
            openURL(url: "https://ontario.foodland.ca/flyer/")
        case "Shopper's Drug Mart":
            openURL(url: "https://www1.shoppersdrugmart.ca/en/flyer")
        case "Total Health Pharmacy":
            openURL(url: "https://www1.shoppersdrugmart.ca/en/flyer")
        case "McDonald's":
            openURL(url: "https://www.mcdonalds.com/ca/en-ca.html")
        case "Tim Horton's":
            openURL(url: "https://timhortons.ca/ca/en/index.php")
        case "Subway":
            openURL(url: "https://www.subway.com/en-CA")
        case "Harvey's":
            openURL(url: "https://www.harveys.ca/eng/")
        case "Swiss Chalet":
            openURL(url: "https://www.swisschalet.com/")
        case "Esso":
            openURL(url: "https://www.esso.ca/en/")
        case "BMO":
            openURL(url: "https://www.bmo.com/main/personal")
        case "Shell":
            openURL(url: "https://www.shell.ca")
        case "LCBO":
            openURL(url: "http://www.lcbo.com/content/lcbo/en.html")
        default:
            print("No link available")
        }
    }

    override func viewDidLoad() { //Nate
        super.viewDidLoad()
        storeTable.dataSource = self
        storeTable.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIViewController { //Julia
    func hideKeyboard() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

// Tyler and Julia -  Adds a "close" button to a keyboard (this is only used on Cole's profile section)
extension UITextField {
    func closeButton(onDone: (target: Any, action: Selector)? = nil, onCancel: (target: Any, action: Selector)? = nil) {
        let onClose = onDone ?? (target: self, action: #selector(closeButtonTapped))
        
        let toolbar: UIToolbar = UIToolbar()
        toolbar.barStyle = .default
        toolbar.items = [
            UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: onClose.action),
            UIBarButtonItem(title: "Close", style: .done, target: onClose.target, action: onClose.action)
        ]
        toolbar.sizeToFit()
        
        self.inputAccessoryView = toolbar
    }
    
    @objc func closeButtonTapped() {
        self.resignFirstResponder()
    }
}
