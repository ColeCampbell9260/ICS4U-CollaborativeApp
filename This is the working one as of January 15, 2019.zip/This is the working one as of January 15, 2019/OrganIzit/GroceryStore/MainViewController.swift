//
//  ViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-19.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

var currentStore: String = "none"
let screenSize = UIScreen.main.bounds

var list = [allItems[0]]
var savedLists = [("TacoTime", [allItems[25]])]




class MainViewController: UIViewController {
    
    @IBOutlet weak var foodBasicsButton: UIButton!
    
    @IBOutlet weak var shoppersButton: UIButton!
    
    @IBOutlet weak var foodlandButton: UIButton!
    
    
    override func viewDidLoad() {
        
        if list[0] == allItems[0] {
            list.removeFirst()
        }
        if straightThrough == 1 {
            self.performSegue(withIdentifier: "Basics", sender: nil)
        } else if straightThrough == 2 {
            self.performSegue(withIdentifier: "Land", sender: nil)
        } else if straightThrough == 3 {
            self.performSegue(withIdentifier: "Shoppers", sender: nil)
        }
        
        
        foodBasicsButton.layer.borderWidth = 2
        foodBasicsButton.layer.borderColor = UIColor.gray.cgColor
        foodBasicsButton.layer.cornerRadius = 7
        
        shoppersButton.layer.borderWidth = 2
        shoppersButton.layer.borderColor = UIColor.gray.cgColor
        shoppersButton.layer.cornerRadius = 7
        
        foodlandButton.layer.borderWidth = 2
        foodlandButton.layer.borderColor = UIColor.gray.cgColor
        foodlandButton.layer.cornerRadius = 7
        
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    }
    
    
    @IBAction func FoodBasicsButton(_ sender: Any) {
        currentStore = "Basics"
    }
    
    @IBAction func FoodLandButton(_ sender: Any) {
        currentStore = "Land"
    }
    
    @IBAction func ShoppersDrugmartButton(_ sender: Any) {
        currentStore = "Shoppers"
    }
}

