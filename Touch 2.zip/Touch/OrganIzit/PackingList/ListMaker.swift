//
//  ListMaker.swift
//  OrganIzit
//
//  Created by Matthew Dunn on 2018-12-07.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

// All of the data persistence and UI was done by Matt Dunn.
// All of our work with lists was done by Brian.

import UIKit

var isAdded = [Bool]()
var whatUserWantsForList : [String: Bool] = [:]

class ListMaker: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
// Declares the navigation bar where title is shown - Matt D.
    @IBOutlet weak var listMakerNavBar: UINavigationBar!
    
// userOptions is a list of the names of all the default lists the user can add to their lists. onlyAddItemsOnce makes sure that we are not running any functions twice as this was a problem. - Brian
    var userOptions : [String] = []
    var onlyAddItemsOnce : Bool = false

// This sets a variable that is used to add items to the list right before seguing. - Brian
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if whatUserWantsForList["Lacrosse"] == true {
            lacrosse.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Soccer"] == true {
            soccer.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Rugby"] == true {
            rugby.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Baseball"] == true {
            baseball.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Swimming"] == true {
            swimming.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Football"] == true {
            football.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Field Hockey"] == true {
            fieldHockey.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Tennis"] == true {
            tennis.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Bobsleigh"] == true {
            bobsleigh.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Hockey"] == true {
            hockey.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Skiing"] == true {
            skiing.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Ringette"] == true {
            ringette.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Speed Skating"] == true {
            speedSkating.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Snowboarding"] == true {
            snowboarding.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Luge"] == true {
            luge.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Curling"] == true {
            curling.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Hot"] == true {
            hot.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Cold"] == true {
            cold.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Overnight"] == true {
            overnight.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Plane"] == true {
            plane.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Out of Country"] == true {
            outOfCountry.doesUserWantOnThereList = true
        }
        
        if whatUserWantsForList["Car"] == true {
            car.doesUserWantOnThereList = true
        }
        
        newListCreated = true
        
    }
    
    @IBAction func doneButton(_ sender: UIBarButtonItem) {
        
    }
    
// Adds the names of lists that could be added to the users list to be displayed in the table view. - Brian
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if onlyAddItemsOnce == false {
            userOptions.append(car.nameOfActivityType)
            userOptions.append(outOfCountry.nameOfActivityType)
            userOptions.append(plane.nameOfActivityType)
            userOptions.append(overnight.nameOfActivityType)
            userOptions.append(cold.nameOfActivityType)
            userOptions.append(hot.nameOfActivityType)
            userOptions.append(curling.nameOfActivityType)
            userOptions.append(luge.nameOfActivityType)
            userOptions.append(snowboarding.nameOfActivityType)
            userOptions.append(speedSkating.nameOfActivityType)
            userOptions.append(ringette.nameOfActivityType)
            userOptions.append(skiing.nameOfActivityType)
            userOptions.append(hockey.nameOfActivityType)
            userOptions.append(bobsleigh.nameOfActivityType)
            userOptions.append(tennis.nameOfActivityType)
            userOptions.append(fieldHockey.nameOfActivityType)
            userOptions.append(football.nameOfActivityType)
            userOptions.append(rugby.nameOfActivityType)
            userOptions.append(swimming.nameOfActivityType)
            userOptions.append(baseball.nameOfActivityType)
            userOptions.append(soccer.nameOfActivityType)
            userOptions.append(lacrosse.nameOfActivityType)
            onlyAddItemsOnce = true
        }
        
        return userOptions.count
        
    }
    
// Displays the table view with the items the user wants and sets the check mark if the user wants the item to start. - Brian
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! itemsToAddToList
        
        cell.itemsUserCanAddTList?.text = userOptions[indexPath.row]
        
        isAdded.append(false)
        whatUserWantsForList += [userOptions[indexPath.row]: isAdded[indexPath.row]]
        
        // Check marks are all done by Matt Dunn
        if(isAdded[indexPath.row]) {
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }
        
        return cell
        
    }
    
// Sets the check marks once items are tapped. - Matt Dunn
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) {
            if cell.accessoryType == .none {
                cell.accessoryType = .checkmark
                isAdded[indexPath.row] = true
                whatUserWantsForList[userOptions[indexPath.row]] = true
            } else if cell.accessoryType == .checkmark {
                cell.accessoryType = .none
                isAdded[indexPath.row] = false
                whatUserWantsForList[userOptions[indexPath.row]] = false
            }
        }
    }
    
    
// Sets the title of the navigation bar. - Matt Dunn
    override func viewDidLoad() {
        super.viewDidLoad()
        listMakerNavBar.topItem?.title = listTitle
        
        // Do any additional setup after loading the view.
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
