//
//  Profile.swift
//  OrganIzit
//
//  Created by Cole Campbell on 2018-12-04.
//  Copyright © 2018 Cole Campbell. All rights reserved.
//

import UIKit

var currentProfile = -1

let defaultPicture = UIImage(imageLiteralResourceName: "Default")
let profilePicture1 = UIImage(imageLiteralResourceName: "Default_1")
let profilePicture2 = UIImage(imageLiteralResourceName: "Default_2")
let profilePicture3 = UIImage(imageLiteralResourceName: "Default_3")
let profilePicture4 = UIImage(imageLiteralResourceName: "Default_4")
let profilePicture5 = UIImage(imageLiteralResourceName: "Default_5")
let profilePicture6 = UIImage(imageLiteralResourceName: "Default_6")

let defaultPictures = [defaultPicture, profilePicture1, profilePicture2, profilePicture3, profilePicture4, profilePicture5, profilePicture6]

var profileUsernames : [String] = []
var profilePasswords : [String] = []
var profilePictures : [Int] = []

var profiles : [Profile] = []

class Profile: Equatable {
    
    var username : String
    var password : String
    var profilePicture : UIImage
    
    init(username: String, password: String?, profilePicture: UIImage?) {
        self.username = username
        
        if password != nil && password != "" {
            self.password = password!
        } else {
            self.password = ""
        }
        
        if profilePicture != nil {
            self.profilePicture = profilePicture!
        } else {
            self.profilePicture = defaultPicture
        }
        
    }
    
    static func == (lhs: Profile, rhs: Profile) -> Bool {
        return lhs.username == rhs.username
    }
    
}

func getProfilePictureIndex(image: UIImage) -> Int {
    switch(image) {
    case defaultPicture:
        return 0
    case profilePicture1:
        return 1
    case profilePicture2:
        return 2
    case profilePicture3:
        return 3
    case profilePicture4:
        return 4
    case profilePicture5:
        return 5
    case profilePicture6:
        return 6
    default:
        return 0
    }
}

func getProfilePictureFromIndex(index: Int) -> UIImage {
    switch(index) {
    case 0:
        return defaultPicture
    case 1:
        return profilePicture1
    case 2:
        return profilePicture2
    case 3:
        return profilePicture3
    case 4:
        return profilePicture4
    case 5:
        return profilePicture5
    case 6:
        return profilePicture6
    default:
        return defaultPicture
    }
}
