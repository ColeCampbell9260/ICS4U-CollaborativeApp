//
//  MapViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-20.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit


class MapViewController: UIViewController {
 
    
    override func viewDidLoad() {
        
        
        if currentStore == "Basics" {
            view.backgroundColor = .green
        } else if currentStore == "Land" {
            view.backgroundColor = .red
        } else if currentStore == "Shoppers"{
            view.backgroundColor = .blue
        } else {
            view.backgroundColor = .white
        }
        super.viewDidLoad()
    }
}

