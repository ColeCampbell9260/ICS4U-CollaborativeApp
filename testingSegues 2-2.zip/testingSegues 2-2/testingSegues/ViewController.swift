//
//  ViewController.swift
//  testingSegues
//
//  Created by Matt McArdle on 2018-11-19.
//  Copyright © 2018 Matt McArdle. All rights reserved.
//

import UIKit

var currentStore: String = "none"

class ViewController: UIViewController {

    var colour = UIColor.white
    var foodBasics = false
    
    
    override func viewDidLoad() {
        foodBasics = false
        super.viewDidLoad()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    }

    
    @IBAction func FoodBasicsButton(_ sender: Any) {
        currentStore = "Basics"
        colour = .green
    }
    
    @IBAction func FoodLandButton(_ sender: Any) {
        currentStore = "Land"
        colour = .red
    }
    
    @IBAction func ShoppersDrugmartButton(_ sender: Any) {
        currentStore = "Shoppers"
        colour = .blue
    }
}

